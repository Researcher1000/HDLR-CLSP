import numpy as np
import torch


# ============================================================
# =============== Utility: discount_cumsum ===================
# ============================================================
def discount_cumsum(x, discount):
    """
    Compute the discounted cumulative sum of a time sequence.

    This operation is commonly used to compute discounted returns or
    generalized advantage estimates (GAE), by accumulating future values
    weighted by the discount factor γ.

    Formula
    -------
        y[t] = x[t] + γ * x[t+1] + γ^2 * x[t+2] + ...

    :param x: Time sequence of values (e.g., rewards, deltas, or advantages).
    :type x: array-like or numpy.ndarray
    :param discount: Discount factor γ in (0, 1].
    :type discount: float

    :return: Discounted cumulative sums with the same shape as ``x``.
    :rtype: numpy.ndarray
    """
    x = np.asarray(x, dtype=np.float32)
    y = np.empty_like(x)
    acc = 0.0

    # Traverse backwards and accumulate discounted future values
    for t in range(len(x) - 1, -1, -1):
        acc = x[t] + discount * acc
        y[t] = acc

    return y

# ============================================================
# ===================== HighLevelBuffer ======================
# ============================================================
class HighLevelBuffer:
    """
    PPO trajectory buffer for the HIGH-level agent.

    This buffer stores rollouts and prepares training targets for the high-level
    actor-critic, including discounted returns and GAE(λ) advantages.

    Stored per time step
    --------------------
    - observations
    - MultiBinary actions
    - rewards
    - critic values V(s)
    - old log-probabilities
    - eligibility masks (action feasibility)

    Computed at trajectory boundaries
    ---------------------------------
    - advantages via GAE(λ)
    - discounted returns

    Optional normalization
    ----------------------
    - reward normalization via an exponential moving average (EMA) of mean/std
    - advantage normalization per batch (zero mean, unit variance)

    :param obs_dim: Dimension of the HIGH-level observation vector.
    :type obs_dim: int
    :param act_dim: Dimension of the MultiBinary action (number of products).
    :type act_dim: int
    :param size: Maximum number of time steps stored in the buffer.
    :type size: int
    :param gamma: Discount factor γ.
    :type gamma: float
    :param lam: GAE parameter λ.
    :type lam: float
    :param device: Target device for returned tensors (e.g., "cpu" or "cuda").
    :type device: str
    :param normalize_rewards: If ``True``, apply EMA-based reward normalization.
    :type normalize_rewards: bool
    :param normalize_advantages: If ``True``, normalize advantages when calling :meth:`get`.
    :type normalize_advantages: bool
    :param reward_norm_momentum: EMA momentum for reward mean/std updates.
                                Typical values are in [0.9, 0.99].
    :type reward_norm_momentum: float
    """

    def __init__(self, obs_dim, act_dim, size, gamma=0.99, lam=0.95, device="cpu", normalize_rewards=False, 
                 normalize_advantages=True, reward_norm_momentum=0.99):
        # Data buffers
        self.obs_buf = np.zeros((size, obs_dim), dtype=np.float32)
        self.act_buf = np.zeros((size, act_dim), dtype=np.float32)
        self.adv_buf = np.zeros(size, dtype=np.float32)
        self.rew_buf = np.zeros(size, dtype=np.float32)
        self.ret_buf = np.zeros(size, dtype=np.float32)
        self.val_buf = np.zeros(size, dtype=np.float32)
        self.logp_buf = np.zeros(size, dtype=np.float32)
        self.mask_buf = np.zeros((size, act_dim), dtype=np.float32)

        # Hyperparameters and internal state
        self.gamma = gamma
        self.lam = lam
        self.ptr = 0
        self.path_start_idx = 0
        self.max_size = size
        self.device = device

        # Normalization options
        self.normalize_rewards = normalize_rewards
        self.normalize_advantages = normalize_advantages
        self.reward_norm_momentum = reward_norm_momentum

        # Running reward statistics (EMA)
        self.r_mean = 0.0
        self.r_std = 1.0
        self._initialized_stats = False

    # --------------------------------------------------------
    # Store one transition
    # --------------------------------------------------------
    def store(self, obs, act, rew, val, logp, mask):
        """
        Store a single transition in the buffer.

        The tuple (obs, act, rew, val, logp, mask) is written at the current pointer.

        :param obs: Observation at the current time step.
        :type obs: numpy.ndarray
        :param act: MultiBinary action taken at the current time step.
        :type act: numpy.ndarray
        :param rew: Immediate reward.
        :type rew: float
        :param val: Critic estimate V(s) for the current state.
        :type val: float
        :param logp: Log-probability of the action under the behavior (old) policy.
        :type logp: float
        :param mask: Eligibility/feasibility mask associated with the action.
        :type mask: numpy.ndarray

        :return: None.
        :rtype: None
        """
        assert self.ptr < self.max_size, "Buffer is full; call get() before storing more."

        self.obs_buf[self.ptr] = obs
        self.act_buf[self.ptr] = act
        self.rew_buf[self.ptr] = rew
        self.val_buf[self.ptr] = val
        self.logp_buf[self.ptr] = logp
        self.mask_buf[self.ptr] = mask

        self.ptr += 1

    # --------------------------------------------------------
    # Running reward statistics (EMA)
    # --------------------------------------------------------
    def _update_running_reward_stats(self, batch_mean, batch_std):
        """
        Update running reward mean and standard deviation using an EMA.

        This is conceptually similar to reward normalization strategies such as
        VecNormalize in Stable-Baselines3.

        :param batch_mean: Mean reward over the current segment/batch.
        :type batch_mean: float
        :param batch_std: Standard deviation of rewards over the current segment/batch.
        :type batch_std: float

        :return: None.
        :rtype: None
        """
        batch_mean = float(batch_mean)
        batch_std = float(batch_std)
    
        # Prevent degenerate std
        batch_std = max(batch_std, 1e-8)
    
        if not self._initialized_stats:
            # Initialize from the first batch
            self.r_mean = np.float32(batch_mean)
            self.r_std = np.float32(batch_std)
            self._initialized_stats = True
            return
    
        m = self.reward_norm_momentum  

        self.r_mean = np.float32(m * self.r_mean + (1.0 - m) * batch_mean)
        self.r_std  = np.float32(m * self.r_std  + (1.0 - m) * batch_std)

        
    # --------------------------------------------------------
    # Finish a trajectory segment: compute GAE and returns
    # --------------------------------------------------------
    def finish_path(self, last_val=0.0):
        """
        Close the current trajectory segment and compute GAE(λ) advantages and returns.

        This method operates on the slice ``[path_start_idx : ptr)``. It should be called
        at episode termination or whenever a trajectory is cut.

        If ``normalize_rewards=True``, rewards within the segment are normalized using
        the running EMA statistics before computing advantages/returns.

        :param last_val: Bootstrap value estimate for the state following the final step
                         of the segment.
        :type last_val: float

        :return: None.
        :rtype: None
        """
        ps = slice(self.path_start_idx, self.ptr)
    
        rews = self.rew_buf[ps].astype(np.float32, copy=False)
        vals = self.val_buf[ps].astype(np.float32, copy=False)
    
        # Optional reward normalization (EMA)
        if self.normalize_rewards and rews.size > 0:
            batch_mean = float(rews.mean())
            batch_std  = float(rews.std())
            self._update_running_reward_stats(batch_mean, batch_std)
    
            rews = (rews - self.r_mean) / (self.r_std + 1e-8)
            self.rew_buf[ps] = rews  # keep buffer consistent
    
        # Compute GAE(λ) advantages and discounted returns
        if rews.size > 0:
            next_vals = np.concatenate(
                [vals[1:], np.array([last_val], dtype=np.float32)]
            )
    
            deltas = rews + self.gamma * next_vals - vals
            adv = discount_cumsum(deltas, self.gamma * self.lam)
            ret = adv + vals
    
            self.adv_buf[ps] = adv.astype(np.float32)
            self.ret_buf[ps] = ret.astype(np.float32)
    
        self.path_start_idx = self.ptr

    
    # --------------------------------------------------------
    # Retrieve training batch for PPO and reset buffer pointers
    # --------------------------------------------------------
    def get(self):
        """
        Return the buffer contents as PyTorch tensors ready for PPO training,
        then reset internal pointers for the next rollout collection.

        If ``normalize_advantages=True``, advantages are normalized across the batch.

        :return: Dictionary containing:
                 - ``obs``: observations
                 - ``act``: actions
                 - ``ret``: discounted returns
                 - ``adv``: advantages (normalized if enabled)
                 - ``logp``: old log-probabilities
                 - ``val``: critic values V(s)
                 - ``mask``: eligibility masks
        :rtype: dict
        """
        assert self.ptr == self.max_size, "Buffer is not full yet."

        adv = self.adv_buf
        if self.normalize_advantages and adv.size > 0:
            std = adv.std()
            if std > 1e-8:
                adv_norm = (adv - adv.mean()) / (std + 1e-8)
            else:
                adv_norm = adv - adv.mean()
        else:
            adv_norm = adv

        data = dict(
            obs=torch.as_tensor(self.obs_buf, device=self.device),
            act=torch.as_tensor(self.act_buf, device=self.device),
            ret=torch.as_tensor(self.ret_buf, device=self.device),
            adv=torch.as_tensor(adv_norm, device=self.device),
            logp=torch.as_tensor(self.logp_buf, device=self.device),
            val=torch.as_tensor(self.val_buf, device=self.device),
            mask=torch.as_tensor(self.mask_buf, device=self.device),
        )

        self.ptr = 0
        self.path_start_idx = 0

        return data



# ============================================================
# ====================== LowLevelBuffer ======================
# ============================================================
class LowLevelBuffer:
    """
    Trajectory buffer for the LOW-level agent in the hierarchical PPO scheme.

    Within a given period, the LOW level takes a sequence of sub-steps (one per
    product visited). Each sub-step receives the same global period reward
    (r_t = -cost_t), consistent with the HIGH-level reward signal.
    GAE(λ) advantages and discounted returns are computed over the resulting
    linear sequence of sub-steps.

    Typical usage pattern
    ---------------------
    - start_period()
    - store_substep(...)
    - end_period_assign_global_reward(r_period)
    - finish_episode_and_collect(last_val)
    - is_batch_ready(target_periods) / get()

    This buffer may accumulate multiple episodes before producing a training batch.

    :param obs_dim: Dimension of the LOW-level observation vector.
    :type obs_dim: int
    :param device: Device where returned tensors will be allocated ("cpu" or "cuda").
    :type device: str
    :param gamma: Discount factor γ.
    :type gamma: float
    :param lam: GAE parameter λ.
    :type lam: float
    :param normalize_rewards: If ``True``, apply EMA-based reward normalization.
    :type normalize_rewards: bool
    :param normalize_advantages: If ``True``, normalize advantages when building the batch.
    :type normalize_advantages: bool
    :param reward_norm_momentum: EMA momentum for reward mean/std updates.
                                Typical values are in [0.9, 0.99].
    :type reward_norm_momentum: float
    """

    def __init__(self, obs_dim, device="cpu", gamma=0.99, lam=0.95, normalize_rewards=False, 
                 normalize_advantages=True, reward_norm_momentum=0.99):
        
        self.device = device
        self.gamma = gamma
        self.lam = lam

        # Current episode (linear sequence of LOW sub-steps)
        self._obs = []
        self._act = []
        self._val = []
        self._logp = []
        self._mask = []
        self._rew = []               # reward per sub-step (global period reward replicated)
        self._period_ranges = []     # list of (start_idx, end_idx) for each period in the episode
        self._period_start = 0
        self.periods_in_batch = 0

        # Global batch accumulator (may contain multiple episodes)
        self._batch = dict(obs=[], act=[], val=[], logp=[], mask=[], adv=[], ret=[])

        # Normalization toggles
        self.normalize_rewards = normalize_rewards
        self.normalize_advantages = normalize_advantages
        self.reward_norm_momentum = reward_norm_momentum

        # EMA reward statistics
        self.r_mean = 0.0
        self.r_std = 1.0
        self._initialized_stats = False
            
    # ---------- Running reward statistics (EMA) ----------
    def _update_running_reward_stats(self, batch_mean, batch_std):
        """
        Update running reward mean and standard deviation using an EMA.

        This is used for optional reward normalization.

        :param batch_mean: Mean reward of the considered batch/segment.
        :type batch_mean: float
        :param batch_std: Standard deviation of rewards of the considered batch/segment.
        :type batch_std: float

        :return: None.
        :rtype: None
        """
        batch_mean = float(batch_mean)
        batch_std  = float(batch_std)
        batch_std  = max(batch_std, 1e-8)   # prevent degenerate std
    
        if not self._initialized_stats:
            self.r_mean = np.float32(batch_mean)
            self.r_std  = np.float32(batch_std)
            self._initialized_stats = True
            return
    
        m = self.reward_norm_momentum
    
        self.r_mean = np.float32(m * self.r_mean + (1.0 - m) * batch_mean)
        self.r_std  = np.float32(m * self.r_std  + (1.0 - m) * batch_std)

    # ---------- Period markers ----------
    def start_period(self):
        """
        Mark the start of a new period within the current episode.

        :return: None.
        :rtype: None
        """
        self._period_start = len(self._obs)

    def store_substep(self, obs, act, val, logp, mask):
        """
        Store a LOW-level sub-step within the current period.

        :param obs: LOW observation at the sub-step.
        :type obs: array-like or numpy.ndarray
        :param act: Discrete action selected (integer index).
        :type act: int
        :param val: Critic estimate V(s) for the LOW-level state.
        :type val: float
        :param logp: Log-probability of the action under the old LOW policy.
        :type logp: float
        :param mask: Action-validity mask used at the sub-step.
        :type mask: array-like or numpy.ndarray

        :return: None.
        :rtype: None
        """
        self._obs.append(np.asarray(obs, dtype=np.float32))
        self._act.append(int(act))
        self._val.append(np.float32(val))
        self._logp.append(np.float32(logp))
        self._mask.append(np.asarray(mask, dtype=np.float32))

    def end_period_assign_global_reward(self, r_period):
        """
        Assign the period-level global reward to all sub-steps in the period.

        If the period contains T sub-steps, ``r_period`` is replicated T times.

        :param r_period: Total reward of the period (e.g., ``-cost_t``).
        :type r_period: float

        :return: None.
        :rtype: None
        """
        start = self._period_start
        end = len(self._obs)
        T = end - start
    
        if T > 0:
            self._rew.extend([np.float32(r_period)] * T)
    
        self._period_ranges.append((start, end))
        self.periods_in_batch += 1

    # ---------- Close episode and accumulate into the global batch ----------
    def finish_episode_and_collect(self, last_val=0.0):
        """
        Close the current episode and append its data into the global batch accumulator.

        GAE(λ) advantages and returns are computed over the linear sequence of LOW sub-steps,
        using the per-period rewards already assigned to each sub-step.

        :param last_val: Bootstrap value estimate for the state following the final sub-step.
                         Used when the episode ends due to truncation rather than termination.
        :type last_val: float

        :return: None.
        :rtype: None
        """
        if len(self._obs) == 0:
            self._reset_episode_buffers()
            return
    
        rew = np.asarray(self._rew, dtype=np.float32)
        val = np.asarray(self._val, dtype=np.float32)
    
        # Optional reward normalization (EMA)
        if self.normalize_rewards and rew.size > 0:
            b_mean = float(rew.mean())
            b_std = float(rew.std())
            self._update_running_reward_stats(b_mean, b_std)
            rew = (rew - self.r_mean) / (self.r_std + 1e-8)
    
        # Compute GAE(λ) and returns
        if rew.size > 0:
            last_val_f = np.float32(last_val)
            next_vals = np.concatenate(
                (val[1:], np.array([last_val_f], dtype=np.float32))
            )
            deltas = rew + self.gamma * next_vals - val
            adv = discount_cumsum(deltas, self.gamma * self.lam)   # float32
            ret = adv + val
        else:
            adv = np.empty(0, dtype=np.float32)
            ret = np.empty(0, dtype=np.float32)
    
        # Append into the global batch accumulator
        self._batch["obs"].extend(self._obs)
        self._batch["act"].extend(self._act)
        self._batch["val"].extend(self._val)
        self._batch["logp"].extend(self._logp)
        self._batch["mask"].extend(self._mask)
        self._batch["adv"].extend(adv.tolist())
        self._batch["ret"].extend(ret.tolist())
    
        # Reset episode buffers
        self._reset_episode_buffers()

    def _reset_episode_buffers(self):
        """
        Clear internal buffers associated with the current episode.

        :return: None.
        :rtype: None
        """
        self._obs, self._act, self._val, self._logp, self._mask = [], [], [], [], []
        self._rew = []
        self._period_ranges = []
        self._period_start = 0

    # ---------- Batch readiness ----------
    def is_batch_ready(self, target_periods):
        """
        Return whether the accumulated number of periods has reached the target.

        :param target_periods: Minimum number of periods required for the batch to be considered ready.
        :type target_periods: int

        :return: ``True`` if enough periods have been accumulated; otherwise ``False``.
        :rtype: bool
        """
        return self.periods_in_batch >= int(target_periods)

    # ---------- Build tensors and reset accumulator ----------
    def get(self):
        """
        Return the accumulated batch as PyTorch tensors, then reset the accumulator.

        If ``normalize_advantages=True``, advantages are normalized across the batch.
        If no data has been accumulated, empty tensors are returned.

        :return: Dictionary with keys:
                 ``obs``, ``act``, ``adv``, ``ret``, ``logp``, ``val``, ``mask``.
        :rtype: dict
        """

        # Empty case
        if len(self._batch["obs"]) == 0:
            empty = torch.empty(0, device=self.device)
            self._batch = dict(obs=[], act=[], val=[], logp=[], mask=[], adv=[], ret=[])
            self.periods_in_batch = 0
            return dict(obs=empty, act=empty, adv=empty, ret=empty,
                        logp=empty, val=empty, mask=empty)
    
        # Convert to tensors-
        obs  = torch.tensor(np.array(self._batch["obs"],  dtype=np.float32), device=self.device)
        act  = torch.tensor(np.array(self._batch["act"],  dtype=np.int64),   device=self.device)
        val  = torch.tensor(np.array(self._batch["val"],  dtype=np.float32), device=self.device)
        logp = torch.tensor(np.array(self._batch["logp"], dtype=np.float32), device=self.device)
        mask = torch.tensor(np.array(self._batch["mask"], dtype=np.float32), device=self.device)
        adv  = torch.tensor(np.array(self._batch["adv"],  dtype=np.float32), device=self.device)
        ret  = torch.tensor(np.array(self._batch["ret"],  dtype=np.float32), device=self.device)
    
        # Optional advantage normalization
        if self.normalize_advantages and adv.numel() > 0:
            std = adv.std()
            if std > 1e-8:
                adv = (adv - adv.mean()) / (std + 1e-8)
            else:
                adv = adv - adv.mean()
    
        data = dict(obs=obs, act=act, adv=adv, ret=ret,
                    logp=logp, val=val, mask=mask)
    
        # Reset accumulator
        self._batch = dict(obs=[], act=[], val=[], logp=[], mask=[], adv=[], ret=[])
        self.periods_in_batch = 0
    
        return data
