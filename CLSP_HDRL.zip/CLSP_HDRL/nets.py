import torch
import torch.nn as nn


# ============================================================
# Utilities: MLP construction and orthogonal initialization
# ============================================================

def mlp(sizes, act=nn.Tanh):
    """
    Build a fully connected multi-layer perceptron (MLP).

    This helper creates a sequence of linear layers with an activation function
    inserted between hidden layers. The final layer is left without an activation
    so the network can learn an output range appropriate for the downstream head
    (e.g., logits or value estimates).

    :param sizes: Layer widths in order:
                  [input_dim, hidden_1, ..., hidden_n, output_dim].
    :type sizes: list[int] or tuple[int, ...]
    :param act: Activation class applied between hidden layers.
                Defaults to ``nn.Tanh``.
    :type act: type[nn.Module]

    :return: A sequential neural network composed of linear layers and intermediate
             activations.
    :rtype: nn.Sequential
    """
    layers = []
    for i in range(len(sizes) - 1):
        layers.append(nn.Linear(sizes[i], sizes[i + 1]))
        if i < len(sizes) - 2:
            layers.append(act())
    return nn.Sequential(*layers)


def orthogonal_init(module, gain=1.0):
    """
    Apply orthogonal initialization to linear layers.

    - If ``module`` is an ``nn.Linear``:
        * weights are initialized orthogonally and scaled by ``gain``,
        * biases are initialized to 0.
    - Otherwise, the module is returned unchanged.

    :param module: PyTorch module to initialize.
    :type module: nn.Module
    :param gain: Scaling factor applied to the orthogonal weight matrix.
    :type gain: float

    :return: The same module, potentially initialized in-place.
    :rtype: nn.Module
    """
    if isinstance(module, nn.Linear):
        nn.init.orthogonal_(module.weight, gain=gain)
        nn.init.constant_(module.bias, 0.0)
    return module


def init_actor_critic_nets(actor, critic, act_hidden_act=nn.Tanh):
    """
    Orthogonally initialize actor and critic networks with head-specific gains.

    Initialization policy:
      - Hidden layers:
          * gain computed from the hidden activation (e.g., Tanh).
      - Actor head (final layer):
          * very small gain (0.01) to start with conservative logits and smoother
            early exploration.
      - Critic head (final layer):
          * gain = 1.0 to yield reasonable initial value scales.

    This setup typically helps:
      - avoid early saturation of nonlinearities,
      - stabilize exploration (especially for stochastic policies),
      - provide more consistent initial value estimates.

    :param actor: Actor network (typically an ``nn.Sequential``).
    :type actor: nn.Module
    :param critic: Critic network (typically an ``nn.Sequential``).
    :type critic: nn.Module
    :param act_hidden_act: Activation class used in hidden layers (used to compute
                           the appropriate gain).
    :type act_hidden_act: type[nn.Module]

    :return: None. Networks are modified in-place.
    :rtype: None
    """
    gain_hidden = nn.init.calculate_gain(
        "tanh" if act_hidden_act is nn.Tanh else "linear"
    )

    # Actor hidden layers
    for m in actor[:-1]:
        if isinstance(m, nn.Linear):
            orthogonal_init(m, gain=gain_hidden)
    # Actor output head (logits)
    if isinstance(actor[-1], nn.Linear):
        orthogonal_init(actor[-1], gain=0.01)

    # Critic hidden layers
    for m in critic[:-1]:
        if isinstance(m, nn.Linear):
            orthogonal_init(m, gain=gain_hidden)
    # Critic output head (V(s))
    if isinstance(critic[-1], nn.Linear):
        orthogonal_init(critic[-1], gain=1.0)


# ============================================================
# Hierarchical policy networks
# ============================================================
class HighPolicy(nn.Module):
    """
    High-level (HIGH) actor-critic network.

    Implements:
      - An actor that outputs logits for a ``MultiBinary(K)`` action
        (one logit per product).
      - A critic that estimates the state value V(s).

    The actor and critic use the same MLP backbone shape (same hidden widths)
    but have separate output heads.

    :param obs_dim: Dimension of the high-level observation (typically 2K).
    :type obs_dim: int
    :param K: Number of products (dimension of the MultiBinary action).
    :type K: int
    :param hidden: Hidden layer widths for the MLP. Defaults to (256, 256).
    :type hidden: tuple[int, ...] or list[int]
    :param act: Activation class used between hidden layers. Defaults to ``nn.Tanh``.
    :type act: type[nn.Module]
    """
    def __init__(self, obs_dim, K, hidden=(256, 256), act=nn.Tanh):
        super().__init__()

        # Actor: logits for MultiBinary(K)
        self.actor = mlp([obs_dim, *hidden, K], act=act)

        # Critic: scalar V(s)
        self.critic = mlp([obs_dim, *hidden, 1], act=act)

        # Consistent orthogonal initialization for actor and critic
        init_actor_critic_nets(self.actor, self.critic, act_hidden_act=act)

    def forward(self, obs):
        """
        Compute policy logits and state value V(s).

        :param obs: Batch of high-level observations.
        :type obs: torch.Tensor

        :return: (logits, value)
                 - logits: tensor of shape [B, K] with pre-sigmoid logits,
                 - value: tensor of shape [B] with V(s) estimates.
        :rtype: tuple[torch.Tensor, torch.Tensor]
        """
        logits = self.actor(obs)              # [B, K]
        value = self.critic(obs).squeeze(-1)  # [B]
        return logits, value


class LowPolicy(nn.Module):
    """
    Low-level (LOW) actor-critic network.

    Implements:
      - A categorical actor producing logits over discrete actions
        {0, 1, ..., A_max - 1}, typically mapped to feasible batch quantities.
      - A critic estimating the low-level state value V(s).

    :param obs_dim: Dimension of the low-level observation.
    :type obs_dim: int
    :param A_max: Maximum number of discrete actions (e.g., CAP + 1).
    :type A_max: int
    :param hidden: Hidden layer widths for the MLP. Defaults to (256, 256).
    :type hidden: tuple[int, ...] or list[int]
    :param act: Activation class used between hidden layers. Defaults to ``nn.Tanh``.
    :type act: type[nn.Module]
    """
    def __init__(self, obs_dim, A_max, hidden=(256, 256), act=nn.Tanh):
        super().__init__()

        self.A_max = A_max

        # Actor: categorical logits over A_max actions (no softmax applied here)
        self.actor = mlp([obs_dim, *hidden, self.A_max], act=act)

        # Critic: scalar V(s)
        self.critic = mlp([obs_dim, *hidden, 1], act=act)

        # Orthogonal init aligned with high-level setup
        init_actor_critic_nets(self.actor, self.critic, act_hidden_act=act)

    def forward(self, obs):
        """
        Compute LOW policy logits and associated state value V(s).

        :param obs: Batch of low-level observations.
        :type obs: torch.Tensor

        :return: (logits, value)
                 - logits: tensor of shape [B, A_max] (to be used with a masked categorical),
                 - value: tensor of shape [B] with V(s) estimates.
        :rtype: tuple[torch.Tensor, torch.Tensor]
        """
        logits = self.actor(obs)              # [B, A_max]
        value = self.critic(obs).squeeze(-1)  # [B]
        return logits, value

