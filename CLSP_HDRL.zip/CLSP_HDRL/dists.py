import torch
import torch.nn.functional as F

class MaskedBernoulli:
    """
    Masked multivariate Bernoulli distribution for the HIGH-level agent.

    This class models a ``MultiBinary(K)`` action as K independent Bernoulli
    components while allowing certain action components to be disabled via a mask.

    Parameters
    ----------
    :param logits: Tensor of shape ``(B, K)`` containing the actor logits before
                   applying the sigmoid.
    :type logits: torch.Tensor
    :param mask: Tensor of shape ``(B, K)`` containing a binary feasibility mask:
                 ``1`` = action component allowed, ``0`` = action component blocked.
    :type mask: torch.Tensor

    Notes
    -----
    - Masked (blocked) components receive a very negative logit so that their
      sigmoid probability is effectively 0.
    - Log-probabilities are computed assuming independence across components.
    """

    def __init__(self, logits, mask):
        # Extremely negative value compatible with logits dtype
        very_neg = torch.finfo(logits.dtype).min / 2

        # Align mask dtype with logits for safe broadcasting
        mask = mask.to(dtype=logits.dtype)

         # Where mask == 0 -> assign very_neg to suppress the action component
        self.logits = torch.where(mask > 0, logits, torch.full_like(logits, very_neg))

        # Component-wise Bernoulli probabilities
        self.probs = torch.sigmoid(self.logits)

    def sample(self):
        """
        Sample binary actions {0, 1} from the independent Bernoulli distribution.

        :return: Sampled binary actions with the same shape as ``self.logits``.
        :rtype: torch.Tensor
        """
        return torch.bernoulli(self.probs)

    def log_prob(self, actions):
        """
        Compute the joint log-probability of a binary action vector.

        The distribution is assumed to factorize across components
        (independent Bernoulli per action dimension).

        :param actions: Tensor of binary actions {0, 1} with the same shape as ``self.logits``.
        :type actions: torch.Tensor

        :return: Per-sample log-probabilities summed across the action dimension (shape: ``(B,)``).
        :rtype: torch.Tensor
        """
        actions = actions.to(dtype=self.logits.dtype)

        # log(sigmoid(x)) = -softplus(-x)
        logp1 = -F.softplus(-self.logits)          # log P(a=1)
        # log(1 - sigmoid(x)) = -x + log(sigmoid(x))
        logp0 = -self.logits + logp1               # log P(a=0)

        logp = actions * logp1 + (1 - actions) * logp0
        return logp.sum(dim=-1)



class MaskedCategorical:
    """
    Masked categorical distribution for the LOW-level agent.

    This class supports discrete policies with invalid actions (masked out),
    ensuring stable numerical behavior and a well-defined fallback even when
    an entire row is masked.

    Parameters
    ----------
    :param logits: Tensor of shape ``(B, A_max)`` containing unnormalized actor logits
                   (pre-softmax).
    :type logits: torch.Tensor
    :param mask: Tensor of shape ``(B, A_max)`` containing a binary feasibility mask:
                 ``1`` = action allowed, ``0`` = action blocked.
    :type mask: torch.Tensor

    Notes
    -----
    - Blocked actions receive a very negative logit so their softmax probability is
      effectively 0.
    - If a batch row has no valid actions (all masked), action 0 is automatically
      enabled to avoid NaNs and undefined behavior.
    - The underlying distribution is instantiated from ``logits=`` for numerical stability.
    """
    def __init__(self, logits, mask):
        # Extremely negative value compatible with logits dtype
        very_neg = torch.finfo(logits.dtype).min / 2

        # Align mask dtype with logits for safe broadcasting
        mask = mask.to(dtype=logits.dtype)

        # Apply masking: logits -> very_neg where mask == 0
        masked_logits = torch.where(mask > 0, logits, torch.full_like(logits, very_neg))

        # If a row has no valid actions, enable action 0 to keep the distribution well-defined
        no_valid = (mask <= 0).all(dim=-1)  # shape: (B,)
        if no_valid.any():
            fix = masked_logits.new_full(masked_logits.shape, very_neg)
            fix[:, 0] = 0.0
            masked_logits = torch.where(no_valid.unsqueeze(-1), fix, masked_logits)

        self.logits = masked_logits
        self.probs = torch.softmax(self.logits, dim=-1)

    def sample(self):
        """
        Sample a valid discrete action from the masked categorical distribution.

        :return: Integer action indices (shape: ``(B,)``).
        :rtype: torch.Tensor
        """
        return torch.distributions.Categorical(logits=self.logits).sample()

    def log_prob(self, actions):
        """
        Compute the log-probability of the given discrete actions.

        :param actions: Tensor of chosen action indices (shape: ``(B,)``).
        :type actions: torch.Tensor

        :return: Log-probabilities of the selected actions (shape: ``(B,)``).
        :rtype: torch.Tensor
        """
        return torch.distributions.Categorical(logits=self.logits).log_prob(actions)

