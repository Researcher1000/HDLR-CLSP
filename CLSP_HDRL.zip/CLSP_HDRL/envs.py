import numpy as np
import gymnasium as gym
from gymnasium import spaces

class CLSPHierEnv(gym.Env):
    """
    Hierarchical RL environment for the Stochastic Capacitated Lot-Sizing Problem (S-CLSP).

    This environment implements a two-level (HIGH/LOW) hierarchical control scheme
    for a finite-capacity CLSP. The HIGH-level policy selects which products are
    eligible for production in each period, and the LOW-level policy decides how
    many batches to produce for each selected product.

    HIGH level:
      - Action:
          :class:`gymnasium.spaces.MultiBinary(K)` → binary vector indicating the
          candidate products to be produced in the current period.
      - Observation (dimension = 2K):
          [ coverage_norm(K), omega_f(K) ]
          where ``coverage_norm`` is the normalized inventory coverage and
          ``omega_f`` encodes the active setup state in {-1, +1}.

    LOW level:
      - For each product selected by HIGH, the agent chooses the production quantity
        (in batches).
      - LOW observation (dimension = 4K + 2):
          [ onehot_norm(K)
          , cap_norm(1)
          , a_high_norm(K)
          , a_high_bin(K)
          , need_setup_norm(1)
          , coverage_norm(K) ]

    Per-period reward:
      - ``r_t = - cost_t ``,
        where ``cost_t`` includes holding, backorder, and setup costs.

    Parameters
    ----------
    :param K: Number of products.
    :type K: int

    :param mu: Mean demand per product. Scalar or array-like of length K.
    :type mu: float or array-like

    :param bs: Batch size (units per batch) for each product.
    :type bs: int or array-like

    :param h: Per-unit holding cost for each product.
    :type h: float or array-like

    :param b: Per-unit backorder cost for each product.
    :type b: float or array-like

    :param k: Setup cost for each product.
    :type k: float or array-like

    :param st: Setup time for each product (expressed in capacity units / batches).
    :type st: int or array-like

    :param CAP: Total capacity per period (in number of batches).
    :type CAP: int

    :param cov: Demand coefficient(s) of variation per product. This is used to
                parameterize the discrete uniform demand model described in the paper.
    :type cov: float or array-like

    :param cov_tau: Coverage bound used to clip ``I / mu`` and rescale it to [-1, 1].
    :type cov_tau: float

    :param reserve_future_min: If ``True``, the LOW-level reserves a minimum amount
                               of capacity for products that have not yet been visited
                               within the current period.
    :type reserve_future_min: bool

    :param force_min_batch: If ``True``, the LOW-level forces production of at least
                            one batch when capacity is available.
    :type force_min_batch: bool

    :param enable_Ilim: If ``True``, inventory is clipped to ``[-0.5 · I_lim, I_lim]``
                        where ``I_lim = 15 · mu``.
    :type enable_Ilim: bool

    :param enforce_eoq_qmax: If ``True``, caps the per-product production quantity using
                             an EOQ-based reference limit.
    :type enforce_eoq_qmax: bool

    :param eoq_slack_batches: Additional slack (in batches) added to the EOQ-based cap.
    :type eoq_slack_batches: int

    :param auto_kmax_from_paper: If ``True``, automatically computes ``Kmax`` following
                                 the procedure described in the comparison paper.
    :type auto_kmax_from_paper: bool

    :param kmax_prob_threshold: Probability threshold used to define ``Kmax`` from the
                                Poisson–binomial distribution.
    :type kmax_prob_threshold: float

    :param enable_ip_eligibility: Enables a HIGH-level eligibility mask based on
                                  inventory and setup state.
    :type enable_ip_eligibility: bool

    :param horizon: Episode length in periods. If ``None``, the horizon is unbounded.
    :type horizon: int or None

    :param seed: Base seed for the internal RNG.
    :type seed: int or None

    :param normalize_rewards_flag: Hint for the trainer; the environment does not
                                   normalize rewards internally.
    :type normalize_rewards_flag: bool

    :param normalize_advantages_flag: Hint for the trainer; the environment does not
                                      normalize advantages internally.
    :type normalize_advantages_flag: bool
    """

    metadata = {"render_modes": []}
        
    def __init__(
        self,
        # ------------------------
        # Problem parameters
        # ------------------------
        K, mu, bs, h, b, k, st, CAP,
        # ------------------------
        # Demand / normalization
        # ------------------------
        cov=None, cov_tau=5.0,
        # ------------------------
        # Demand correlation for 
        # new cases (optional)
        # ------------------------
        demand_corr_mode=None,
        demand_corr_pairs=None,
        demand_corr_groups=None,
        # ------------------------
        # LOW-level behavior
        # -----------------------
        reserve_future_min=True, force_min_batch=True,
        # ------------------------
        # Limits / toggles 
        # -----------------------
        enable_Ilim=True,
        enforce_eoq_qmax=True,
        eoq_slack_batches=0,
        auto_kmax_from_paper=True,
        kmax_prob_threshold=0.01,
        enable_ip_eligibility=True,
        # ------------------------
        # Episode
        # ------------------------
        horizon=None,
        # ------------------------
        # Seed and trainer flags
        # ------------------------
        seed=None,
        normalize_rewards_flag=True,
        normalize_advantages_flag=True,
    ):
        super().__init__()

        # -----------------------
        # 1) Base parameters
        # -----------------------
        self.K = K
        self.CAP = CAP

        # Vectorize with appropriate dtypes
        self.mu = np.asarray(mu, dtype=np.float32)
        self.bs = np.asarray(bs, dtype=np.int32)
        self.h  = np.asarray(h, dtype=np.float32)
        self.b  = np.asarray(b, dtype=np.float32)
        self.k  = np.asarray(k, dtype=np.float32)
        self.st = np.asarray(st, dtype=np.int32)

        # -------------------------
        # 2) Demand / normalization
        # -------------------------
        self.cov = np.asarray(cov, dtype=np.float32)
        self.cov_tau = cov_tau

        # Optional demand correlation
        #   - demand_corr_mode: None | "pair_plus_one"
        #   - demand_corr_pairs: iterable of (i, j) product index pairs
        self.demand_corr_mode = demand_corr_mode
        self.demand_corr_pairs = demand_corr_pairs  
        self.demand_corr_groups = demand_corr_groups

        # -----------------------
        # 4) RNG and horizon
        # -----------------------
        self._seed = seed
        self.rng = np.random.default_rng(seed)
        self.horizon = horizon

        # -----------------------
        # 5) Internal state
        # -----------------------
        self.last_a_high = np.zeros(self.K, dtype=np.int8)

        # -----------------------
        # 6) Inventory limits
        # -----------------------
        self.enable_Ilim = enable_Ilim
        self.I_lim = 15.0 * self.mu
        
        # -----------------------
        # 7) LOW-level flags
        # -----------------------
        self.reserve_future_min = reserve_future_min
        self.force_min_batch_default = force_min_batch

        # --------------------------------
        # 8) Optional EOQ-based q_max cap
        # --------------------------------
        self.enforce_eoq_qmax = enforce_eoq_qmax
        self.eoq_slack_batches = eoq_slack_batches
        self._Q_eoq = None
        self._qmax_eoq = None
        
        if self.enforce_eoq_qmax:
            # Classical EOQ: Q_eoq = sqrt(2 * mu * k / h
            self._Q_eoq = np.sqrt(2.0 * self.mu * self.k / self.h)
        
            # Cap in batches: floor(Q_eoq / bs) + slack
            self._qmax_eoq = np.floor(self._Q_eoq / self.bs).astype(int) + self.eoq_slack_batches

        # -----------------------
        # 9) Automatic Kmax 
        # -----------------------
        self.auto_kmax_from_paper = auto_kmax_from_paper
        self.kmax_prob_threshold = kmax_prob_threshold
        self.Kmax = None
        
        if self.auto_kmax_from_paper:
            self.Kmax = self._compute_Kmax()

        # ---------------------------
        # 10) HIGH-level eligibility
        # ---------------------------
        self.enable_ip_eligibility = enable_ip_eligibility

        # -----------------------
        # 11) Trainer hints
        # -----------------------
        self.normalize_rewards_flag = normalize_rewards_flag
        self.normalize_advantages_flag = normalize_advantages_flag

        # -----------------------
        # 12) Gymnasium spaces
        # -----------------------
        self.observation_space = spaces.Box(
            low=-np.ones(2 * self.K, dtype=np.float32),
            high=np.ones(2 * self.K, dtype=np.float32),
            dtype=np.float32,
        )
        self.action_space = spaces.MultiBinary(self.K)
        self._low_action_n = self.CAP + 1
        
        # -----------------------------------------
        # 13) Demand model setup and initial state
        # -----------------------------------------
        self._setup_demand_params()
        self.reset()


    
    # ==============================================================
    # ============  Demand model: discrete uniform =================
    # ==============================================================
    def _setup_demand_params(self):
        """
        Define the discrete uniform demand ranges for each product.
    
        The demand bounds are determined based on the coefficient of variation
        (cov) and the mean demand (mu), following the demand model described
        in the paper:
    
          - cov ≈ 0.58 and mu = 4  → U{0, 8}
          - cov ≈ 0.58 and mu = 2  → U{0, 4}
          - cov ≈ 0.14 and mu = 4 → U{3, 5}
    
        For high variability (cov ≈ 0.58), the bounds are set explicitly as
        U{0, 2·mu}, matching the paper.
    
        For low variability (e.g., cov ≈ 0.14), the interval is constructed
        to be symmetric around the mean and to approximately reproduce the
        desired coefficient of variation of a discrete uniform distribution.
        In practice, this yields U{3, 5} for (mu=4, cov=0.14), and produces
        coherent intervals for other low-variability combinations.
    
        Any remaining combinations fall back to a degenerate distribution
        U{mu, mu}.
    
        :param self: CLSPHierEnv instance.
        :type self: CLSPHierEnv
    
        :return: None. This method sets the internal attributes
                 ``self._unif_a`` and ``self._unif_b``, which store the lower
                 and upper bounds of the discrete uniform demand distributions
                 for each product.
        :rtype: None
        """
        cov = self.cov.astype(np.float32, copy=False)
        mu  = self.mu.astype(np.float32, copy=False)
    
        K = self.K
        a = np.empty(K, dtype=np.int32)
        b = np.empty(K, dtype=np.int32)
    
        for i in range(K):
            if np.isclose(cov[i], 0.58, atol=1e-3):
                a[i] = 0
                b[i] = int(round(2 * mu[i]))
            else:
                # Low variability (e.g., cov ≈ 0.14)
                if np.isclose(mu[i], 4.0, atol=1e-3):
                    a[i], b[i] = 3, 5
                else:
                    a[i] = b[i] = int(round(mu[i]))
    
        self._unif_a = a
        self._unif_b = b


    
    
    # ==============================================================
    # =============  Demand sampling per period  ===================
    # ==============================================================
    def _sample_demand(self):
        """
        Generate an integer-valued demand realization for the current period.
    
        For each product i, demand is sampled from a discrete uniform
        distribution U{a_i, b_i}, where the bounds a_i and b_i are precomputed
        in `_setup_demand_params` and stored in `self._unif_a` and `self._unif_b`.
    
        By default, demands are sampled independently across products.
    
        If `self.demand_corr_mode == "pair_plus_one"` and `self.demand_corr_pairs`
        is provided, then each configured pair (i, j) is overridden to introduce
        a simple positive dependence:
          - sample a base value for product i from its feasible interval,
          - set demand of product j to base + 1,
          - clip the resulting demand of j to remain within [a_j, b_j].
    
        :return: Vector of integer demands for the K products, where each element
                 satisfies d_i ∈ [a_i, b_i].
        :rtype: numpy.ndarray
        """
        d = self.rng.integers(
            low=self._unif_a,
            high=self._unif_b + 1,  # numpy integers 'high' is exclusive
            size=self.K,
            dtype=np.int32,
        )
    
        mode = self.demand_corr_mode
        
        if mode == "pair_plus_one" and self.demand_corr_pairs is not None:
            for (i, j) in self.demand_corr_pairs:
                base = self.rng.integers(self._unif_a[i], self._unif_b[i] + 1, dtype=np.int32)
                d[i] = base
                d[j] = base + 1
                d[j] = np.clip(d[j], self._unif_a[j], self._unif_b[j])
        
        elif mode == "pair_same" and self.demand_corr_pairs is not None:
            for (i, j) in self.demand_corr_pairs:
                base = self.rng.integers(self._unif_a[i], self._unif_b[i] + 1, dtype=np.int32)
                d[i] = base
                d[j] = base
                d[j] = np.clip(d[j], self._unif_a[j], self._unif_b[j])  # safety
                d[i] = np.clip(d[i], self._unif_a[i], self._unif_b[i])
        
        elif mode == "group_same" and self.demand_corr_groups is not None:
            for grp in self.demand_corr_groups:
                grp = list(grp)
                if len(grp) == 0:
                    continue
                i0 = grp[0]
                base = self.rng.integers(self._unif_a[i0], self._unif_b[i0] + 1, dtype=np.int32)
                for j in grp:
                    d[j] = base
                    d[j] = np.clip(d[j], self._unif_a[j], self._unif_b[j])

    
        return d

        
    # ==============================================================
    # =============  HIGH-level observations  ======================
    # ==============================================================
    def _coverage_norm_vec(self, I_view=None):
        """
        Compute the normalized inventory coverage vector.
    
        The coverage of each product is defined as:
    
            coverage_i = I_i / mu_i
    
        The resulting values are then clipped to the interval
        [-cov_tau, +cov_tau] and linearly rescaled to lie in [-1, +1].
    
        :param I_view: Optional alternative inventory vector.
                       If not provided, the current inventory state
                       ``self.I`` is used.
        :type I_view: numpy.ndarray or None
    
        :return: Normalized coverage vector for the K products,
                 with values in the range [-1, 1].
        :rtype: numpy.ndarray
        """
        I = self.I if I_view is None else np.asarray(I_view, dtype=np.float32)
    
        coverage = I.astype(np.float32) / self.mu
        cov_tau = np.float32(self.cov_tau)
    
        coverage = np.clip(coverage, -cov_tau, cov_tau) / cov_tau
    
        return coverage.astype(np.float32)

    
    
    def _obs_high(self):
        """
        Construct the observation vector for the HIGH-level agent.
    
        The observation combines normalized inventory coverage with the
        active setup state, resulting in a vector of dimension 2K:
    
            obs_high = [ coverage_norm(K), omega_f(K) ]
    
        where:
            - coverage_norm(K): inventory coverage normalized to [-1, 1]^K
            - omega_f(K): binary indicator of the active setup state in {-1, +1}^K
                          (+1 if the setup is active, -1 otherwise)
    
        :return: HIGH-level observation vector of shape (2K,).
        :rtype: numpy.ndarray
        """
        cov_norm = self._coverage_norm_vec()
        omega_f = (2 * self.omega - 1).astype(np.float32)
    
        obs_high = np.concatenate((cov_norm, omega_f)).astype(np.float32)
        return obs_high



    # ==============================================================
    # =============  LOW state and mask  ===========================
    # ==============================================================
    def _low_state_mask_for(self, i, CAP_rem, a_high_scores, pos=None, chosen=None, 
                            force_min_batch=None, I_view=None, a_high_vec=None):

        """
        Build the LOW-level state vector and the feasible action set for one product.
    
        For the current product index ``i``, this method constructs:
          - the LOW-level state vector of dimension (4K + 2), including:
                * one-hot encoding of the current product 
                * remaining capacity 
                * HIGH scores/probabilities 
                * binary HIGH selection vector
                * setup requirement indicator 
                * normalized inventory coverage
          - the set of feasible production quantities (in batches)
          - a boolean feasibility mask for those quantities
          - a flag indicating whether a new setup is required for the product
    
        The available capacity for product ``i`` accounts for:
          - remaining period capacity (CAP_rem),
          - optional minimum capacity reservation for future products,
          - setup time if a new setup is required,
          - an optional EOQ-based upper bound if enabled.
    
        :param i: Index of the current product.
        :type i: int
    
        :param CAP_rem: Remaining capacity in the current period (in batches).
        :type CAP_rem: int
    
        :param a_high_scores: HIGH-level scores/probabilities for each product (values in [0, 1]).
        :type a_high_scores: numpy.ndarray
    
        :param pos: Position of the current product within the LOW visiting sequence ``chosen``.
        :type pos: int or None
    
        :param chosen: Indices of products selected by HIGH in the current period.
        :type chosen: list or numpy.ndarray or None
    
        :param force_min_batch: If True, forces producing at least one batch when capacity is available.
                                If None, uses ``self.force_min_batch_default``.
        :type force_min_batch: bool or None
    
        :param I_view: Optional "virtual" inventory vector used to compute observation features.
                       If None, uses the current inventory ``self.I``.
        :type I_view: numpy.ndarray or None
    
        :param a_high_vec: Optional explicit binary HIGH action vector {0,1}^K to be included in the LOW state.
                           If None, a proxy is derived from ``a_high_scores`` using a 0.5 threshold.
        :type a_high_vec: numpy.ndarray or None
    
        :return: Tuple (low_s, mask_q, need_setup), where:
                 - low_s: LOW-level state vector of shape (4K + 2,),
                 - mask_q: boolean feasibility mask,
                 - need_setup: True if producing product i requires a new setup.
        :rtype: tuple
        """
        
        # Setup requirement and flags
        fmb = self.force_min_batch_default if force_min_batch is None else force_min_batch
        st_i = self.st[i]
        need_setup = (self.omega[i] == 0)
    
        # Optional future capacity reservation (if applicable)
        reserve_future = self._future_min_capacity(chosen, pos) if (chosen is not None and pos is not None) else 0
        cap_for_current = max(0, CAP_rem - reserve_future)
    
        # Natural q_max given remaining capacity and action-space definition
        qmax_natural = min(self._low_action_n - 1, cap_for_current)

        # Capacity-feasible q_max accounting for setup time (if needed)
        if need_setup:
            qmax_res = max(0, min(qmax_natural, cap_for_current - st_i))
        else:
            qmax_res = max(0, min(qmax_natural, cap_for_current))

        # Optional EOQ-based cap
        if self.enforce_eoq_qmax and (self._qmax_eoq is not None):
            qmax_res = min(qmax_res, max(0, int(self._qmax_eoq[i])))


        Amax = self._low_action_n  # = CAP + 1
        mask_q = np.zeros((Amax,), dtype=np.float32)
        
        # Natural candidates: q in [0..qmax_res]
        if qmax_res >= 0:
            mask_q[:qmax_res + 1] = 1.0
        
        # Force-min-batch
        if fmb and qmax_res >= 1:
            mask_q[0] = 0.0
        
        # Fallback: if all items mask is 0, allow q=0
        if mask_q.sum() == 0:
            mask_q[0] = 1.0

    
        # -------------------------
        # ====== LOW state ========
        # -------------------------
        # Normalized one-hot encoding of the current product
        onehot = np.zeros(self.K, dtype=np.float32)
        onehot[i] = 1.0
        onehot_norm = (2 * onehot - 1).astype(np.float32)
    
        # Remaining capacity normalized to [-1, 1]
        cap_norm = np.array([(2 * (cap_for_current / max(1, self.CAP))) - 1], dtype=np.float32)
    
        # HIGH scores normalized to [-1, 1]
        scores = np.clip(np.asarray(a_high_scores, dtype=np.float32), 0.0, 1.0)
        a_high_norm = (2 * scores - 1).astype(np.float32)
    
        # Binary HIGH selection vector (kept in [0, 1])
        if a_high_vec is None:
            a_high_vec = (scores > 0.5).astype(np.float32)
        else:
            a_high_vec = np.clip(np.asarray(a_high_vec, dtype=np.float32), 0.0, 1.0)
        a_high_bin = (a_high_vec).astype(np.float32)
    
        # Setup requirement indicator in {-1, +1}
        need_setup_norm = np.array([1 if need_setup else -1], dtype=np.float32)
    
        # Normalized inventory coverage
        cov_norm_vec = self._coverage_norm_vec(I_view)
    
        # Final LOW state vector
        low_s = np.concatenate(
            (onehot_norm, cap_norm, a_high_norm, a_high_bin, need_setup_norm, cov_norm_vec),
            dtype=np.float32
        )
    
        return low_s, mask_q, bool(need_setup)


    
    # ==============================================================
    # ========  LOW-level visiting order (prob / paper) ============
    # ==============================================================
    def plan_quantity_assignment_order(self, a_high_exec, a_high_scores):
        """
        Define the visit order for LOW-level quantity decisions within a period.
    
        This method determines the sequence in which products selected by the HIGH
        level will be processed by the LOW-level policy when assigning production
        quantities.
    
        The ordering is based on the HIGH-level action scores:
          - Only products activated by the HIGH-level decision (a_high_exec = 1)
            are considered.
          - Selected products are sorted in descending order of their associated
            HIGH-level probabilities or scores.
          - Products with higher HIGH-level confidence are assigned quantities first,
            which typically leads to more effective capacity allocation.
    
        If no product is selected by the HIGH level, an empty order is returned.
    
        :param self: CLSPHierEnv instance.
        :type self: CLSPHierEnv
        :param a_high_exec: Binary vector indicating which products are activated
                            by the HIGH-level policy (1 = selected, 0 = not selected).
        :type a_high_exec: array-like or numpy.ndarray of shape (K,)
        :param a_high_scores: Continuous scores or probabilities produced by the
                              HIGH-level policy for each product. Values are expected
                              to lie in the interval [0, 1].
        :type a_high_scores: array-like or numpy.ndarray of shape (K,)
    
        :return: Array of product indices in the order in which the LOW-level policy
                 should assign production quantities.
        :rtype: numpy.ndarray of dtype int32
        """
        a = np.asarray(a_high_exec, dtype=np.int8)
        chosen = np.nonzero(a)[0]
        if chosen.size == 0:
            return chosen.astype(np.int32)
    
        scores = np.clip(np.asarray(a_high_scores, dtype=np.float32), 0.0, 1.0)
        order = np.argsort(scores[chosen])[::-1]
        return chosen[order].astype(np.int32)

        
    def plan_production_order_paper(self, produced_mask, a_high_scores, I_view_final=None):
        """
        Define the production sequence used exclusively to update the setup carryover
        variable (omega) at the end of a period.
    
        This method determines an ordered list of products that were produced in the
        current period. 
        The resulting order is NOT used for LOW-level quantity decisions, but solely to
        determine which product remains set up for the next period.
    
        The ordering logic is as follows:
          - Only products with produced_mask[i] = 1 are considered.
          - If the product currently set up (HEAD) is produced, it is placed first
            in the sequence.
          - The last product in the sequence (TAIL) is chosen as the product with
            the lowest inventory coverage proxy, computed from a pseudo final
            inventory state.
          - If HEAD exists and more than one product is produced, HEAD is explicitly
            forbidden from being selected as TAIL.
          - Remaining products (MID) are ordered in descending order of their
            HIGH-level scores or probabilities.
    
        Inventory coverage is approximated as the ratio between inventory and mean
        demand, and may be computed using either the actual inventory at the end of
        the period or a virtual inventory snapshot passed via `I_view_final`.
    
        :param self: CLSPHierEnv instance.
        :type self: CLSPHierEnv
        :param produced_mask: Binary vector indicating which products were produced
                              in the current period (1 = produced, 0 = not produced).
        :type produced_mask: array-like or numpy.ndarray of shape (K,)
        :param a_high_scores: Continuous scores or probabilities produced by the
                              HIGH-level policy for each product. Values are expected
                              to lie in the interval [0, 1].
        :type a_high_scores: array-like or numpy.ndarray of shape (K,)
        :param I_view_final: Optional pseudo inventory vector representing the
                             within-period inventory state after LOW-level decisions.
                             If None, the actual environment inventory is used.
        :type I_view_final: array-like or numpy.ndarray of shape (K,) or None
    
        :return: Array of product indices in the order used to update the setup
                 carryover variable omega, with guaranteed uniqueness.
        :rtype: numpy.ndarray of dtype int32
        """
        produced_mask = np.asarray(produced_mask, dtype=np.int8)
        produced = np.nonzero(produced_mask)[0]
        if produced.size == 0:
            return produced.astype(np.int32)
    
        scores = np.clip(np.asarray(a_high_scores, dtype=np.float32), 0.0, 1.0)
    
        # HEAD = current setup item if produced
        omega_prod = self.omega[produced]
        head_idx = np.where(omega_prod == 1)[0]
        head = produced[head_idx[0]] if head_idx.size > 0 else None
    
        # Inventory reference for tail selection (pseudo inventory final)
        I_ref = self.I.astype(np.float32) if I_view_final is None else np.asarray(I_view_final, dtype=np.float32)
        cov_ref = I_ref / self.mu  # coverage prox
    
        # TAIL selection with constraint: head cannot be tail if produced.size > 1
        if head is not None and produced.size > 1:
            tail_candidates = produced[produced != head]
            tail = tail_candidates[np.argmin(cov_ref[tail_candidates])]
        else:
            tail = produced[np.argmin(cov_ref[produced])]
    
        # MID = remaining items excluding head and tail, sorted by prob desc
        mask_mid = (produced != tail)
        if head is not None:
            mask_mid &= (produced != head)
    
        mid = produced[mask_mid]
        if mid.size > 0:
            mid = mid[np.argsort(scores[mid])[::-1]]
    
        # Compose order: HEAD -> MID -> TAIL
        seq = []
        if head is not None:
            seq.append(int(head))
        seq.extend([int(x) for x in mid])
        seq.append(int(tail))
    
        # Uniq safety
        uniq = []
        seen = set()
        for x in seq:
            if x not in seen:
                seen.add(x)
                uniq.append(x)
    
        return np.asarray(uniq, dtype=np.int32)


    
    # ==============================================================
    # ========  Minimum future capacity reservation (LOW) ==========
    # ==============================================================
    def _future_min_capacity(self, chosen, pos):
        """
        Compute the minimum capacity that should be reserved for yet-unvisited products
        in the current period, following the logic described in the paper.
    
        The reserved capacity is estimated as:
          - +1 batch for each remaining (future) product to be processed in this period.
          - +st[j] additional capacity if product j would require a setup (omega[j] == 0).
    
        If the option ``reserve_future_min`` is disabled, no capacity is reserved.
    
        :param chosen: Indices of products selected by HIGH in the current period.
        :type chosen: list or numpy.ndarray or None
    
        :param pos: Current 0-based position within the ``chosen`` sequence.
        :type pos: int or None
    
        :return: Minimum capacity to reserve (non-negative integer).
        :rtype: int
        """
        
        if not self.reserve_future_min:
            return 0
    
        # Convert chosen to an array (assumed valid when called)
        chosen = np.asarray(chosen, dtype=int)
    
        # If there are no future products, nothing needs to be reserved
        if pos >= chosen.size - 1:
            return 0
    
        # Products that remain to be visited
        fut_idxs = chosen[pos + 1:]
    
        # Reserve at least 1 batch per future product
        base = fut_idxs.size
    
        # Add setup time only for products without an active setup
        needs_setup = (self.omega[fut_idxs] == 0)
        setup_cost = self.st[fut_idxs][needs_setup].sum() if needs_setup.any() else 0
    
        return int(base + setup_cost)


    
    # ===============================================================
    # =========  HIGH-level eligibility mask ========================
    # ===============================================================
    def eligibility_mask_high(self):
        """
        Generate a binary mask indicating which products are eligible to be
        selected by the HIGH-level agent.
    
        Logic based on the paper:
          - If ``enable_ip_eligibility = False`` → all products are eligible.
          - If ``enable_ip_eligibility = True``:
                * A product is marked as ineligible (0) if:
                    - it does not have an active setup (omega[i] == 0), and
                    - its inventory level is high (I_i > 5 · μ_i).
                * Otherwise, the product is eligible (1).
    
        :return: Binary vector of shape (K,), where:
                 1 = eligible product,  
                 0 = blocked (ineligible) product.
        :rtype: numpy.ndarray
        """
        if not self.enable_ip_eligibility:
            return np.ones(self.K, dtype=np.int32)
    
        # A product is ineligible if:
        #   - it has no active setup (omega == 0), and
        #   - its inventory exceeds 5 * mu
        ineligible = (self.omega == 0) & (self.I > (5.0 * self.mu))
    
        # 1 = eligible, 0 = ineligible
        return (~ineligible).astype(np.int32)

    
    def clip_high_to_Kmax(self, a_high_raw, a_high_scores, mode="stochastic"):
        """
        Enforce the Kmax constraint on a HIGH-level MultiBinary action.
    
        This method post-processes a binary selection vector proposed by the HIGH
        policy to ensure that no more than Kmax products are active in a single
        period. If the number of selected products exceeds Kmax, a subset of size
        Kmax is retained according to either a deterministic or stochastic rule
        based on the HIGH-level scores.
    
        The clipping operation is applied only when necessary; otherwise, the
        original action is returned unchanged.
    
        Clipping strategies
        -------------------
        - Deterministic:
            Retains the Kmax products with the highest HIGH-level scores.
        - Stochastic:
            Samples Kmax products *without replacement*, with probabilities
            proportional to the HIGH-level scores.
    
        After clipping, the eligibility mask is enforced again as a safety measure.
        If this secondary masking reduces the number of active products below Kmax,
        no refilling is performed.
    
        Parameters
        ----------
        a_high_raw : numpy.ndarray
            Binary vector {0,1}^K proposed by the HIGH policy, representing the
            initially selected products. The vector is assumed to be already masked
            by eligibility constraints.
        a_high_scores : numpy.ndarray
            Continuous scores or probabilities in [0,1]^K associated with each
            product (typically the Bernoulli probabilities output by the HIGH policy).
            These scores are used to rank or weight products during clipping.
        mode : str, optional
            Clipping mode to apply. Supported values are:
              - "stochastic": randomly select Kmax products without replacement,
                weighted by `a_high_scores` (default).
              - "deterministic": keep the Kmax products with the highest scores.
    
        Returns
        -------
        a_high_exec : numpy.ndarray
            Binary vector {0,1}^K after enforcing the Kmax constraint. This vector is
            safe to execute in the environment.
        clipped : bool
            Flag indicating whether clipping was actually applied (True) or whether
            the original action already satisfied the Kmax constraint (False).
        """
        a_high_raw = np.asarray(a_high_raw, dtype=np.int8)
        scores = np.clip(np.asarray(a_high_scores, dtype=np.float32), 0.0, 1.0)
    
        # If no Kmax, or trivial bound, no-op
        if (self.Kmax is None) or (self.Kmax >= self.K):
            return a_high_raw.copy(), False
    
        on = np.nonzero(a_high_raw)[0]
        if on.size <= int(self.Kmax):
            return a_high_raw.copy(), False
    
        Kmax = int(self.Kmax)
    
        if mode == "deterministic":
            keep = on[np.argsort(scores[on])[::-1][:Kmax]]
        else:
            w = scores[on].astype(np.float64)
            w = np.clip(w, 1e-12, None)
            w = w / w.sum()
            keep = self.rng.choice(on, size=Kmax, replace=False, p=w)
    
        a_exec = np.zeros_like(a_high_raw)
        a_exec[keep] = 1
    
        # Safety: enforce eligibility (in case caller forgot masking)
        elig = self.eligibility_mask_high().astype(np.int8)
        a_exec = (a_exec & elig)
    
        # If eligibility enforcement dropped below Kmax, that's ok (won't "refill")
        return a_exec.astype(np.int8), True
        


    # ==============================================================
    # ======================  Kmax computation  ====================
    # ==============================================================
    def _compute_Kmax(self):
        """
        Estimate Kmax, the maximum number of distinct products produced within a period.
    
        Computation steps:
            1) TBO_i = sqrt(2 * k_i / (h_i * mu_i))
            2) p1_i  = 1 / TBO_i         → probability of producing product i in a period
            3) X = Σ Bernoulli(p1_i)     → Poisson–binomial distribution
            4) Kmax = max { k : P(X = k) > kmax_prob_threshold }
    
        :return: Integer estimate of Kmax.
        :rtype: int
        """
        
        # --- 1) Compute TBO and p1 ---
        h = self.h.astype(np.float64)
        mu = self.mu.astype(np.float64)
        k = self.k.astype(np.float64)
    
        # TBO_i = sqrt(2 k_i / (h_i * mu_i))
        TBO = np.sqrt(2.0 * k / (h * mu))
    
        # Probability of producing product i in a period
        p1 = np.clip(1.0 / TBO, 0.0, 1.0)
    
        # Extreme cases:
        # - if all probabilities are ~0 → never produce → Kmax = 0
        if np.all(p1 == 0):
            return 0
        # - if all probabilities are 1 → always produce all → bounded by CAP and K
        if np.all(p1 == 1):
            return min(self.K, self.CAP)
    
        # --- 2) Poisson–binomial PMF via convolutions ---
        pmf = np.array([1.0], dtype=np.float64)
        for pi in p1:
            pmf = np.convolve(pmf, np.array([1.0 - pi, pi], dtype=np.float64))
    
        # Light renormalization
        s = pmf.sum()
        if s > 0:
            pmf /= s
    
        # --- 3) Thresholding and bounds ---
        thr = self.kmax_prob_threshold
        kvals = np.where(pmf > thr)[0]
    
        if kvals.size == 0:
            return 0
    
        kmax_raw = kvals.max()
        return int(min(kmax_raw, self.K, self.CAP))

    
    # ==============================================================
    # ======================== RESET ================================
    # ==============================================================
    def reset(self, seed=None, options=None):
        """
        Reset the CLSP environment at the beginning of a new episode.
    
        This method restores the internal state of the environment, including
        inventories, active setups, and the time counter. It also reinitializes
        the internal random number generator using the provided seed (or a
        previously stored seed in ``self._seed``).
    
        :param seed: Optional integer seed for the random number generator.
                     If None, the environment's stored seed is used.
        :type seed: int or None
    
        :param options: Standard Gymnasium argument (not used).
        :type options: dict or None
    
        :return: Tuple (obs, info), where:
                 - obs: initial HIGH-level observation (float32 vector),
                 - info: empty dictionary (Gymnasium compatibility).
        :rtype: tuple
        """
        
        # If no seed is provided, use the stored one
        if seed is None:
            seed = self._seed
    
        # Gymnasium global seeding
        super().reset(seed=seed)
    
        # Reseed the internal RNG
        self.rng = np.random.default_rng(seed)
    
        # Initial state
        self.I = np.zeros(self.K, dtype=np.int32)
        self.omega = np.zeros(self.K, dtype=np.int8)
        self.t = 0
    
        # Reproducible selection of the initial active setup
        active_idx = self.rng.integers(0, self.K)
        self.omega[active_idx] = 1
    
        # Initial observation
        obs_init = self._obs_high()
        return obs_init, {}

        
    @property
    def low_obs_dim(self):
        """
        Dimension of the LOW-level observation vector.
    
        :return: Size of the observation vector used by the LOW-level agent.
        :rtype: int
        """
        return 4 * self.K + 2



    # ==============================================================
    # ========================= STEP ===============================
    # ==============================================================
    def step(self, a_high, low_actions=None, a_high_scores=None):
        """
        Execute one full period of the hierarchical CLSP environment.
    
        The HIGH-level agent selects which products are eligible for production in the
        current period (via ``a_high``), and the LOW-level agent decides, for each
        selected product, how many batches to produce, while respecting capacity,
        and setup requirements.
    
        High-level flow:
            1) Validate and store the HIGH action.
            2) Identify active products and determine the LOW visiting order.
            3) For each product in the visiting order:
                   - build the LOW state and feasible action set,
                   - apply the proposed LOW action (with clamping and feasibility masking),
                   - update remaining capacity, setups, and the within-period "virtual" inventory.
            4) Apply production, sample demand, and update the real inventory state.
            5) Compute costs (holding, backorder, setup) and the scalar reward.
            6) Update the active setup state for the next period and advance time.
            7) Return the next HIGH observation and detailed metrics in ``info``.
    
        :param a_high: Binary vector {0,1}^K indicating which products are selected by HIGH.
        :type a_high: numpy.ndarray
    
        :param low_actions: Proposed LOW actions, expressed as indices into the ``qs`` vectors
                            returned by `_low_state_mask_for` for each visited product.
                            If None, action index 0 is assumed for all visited products.
        :type low_actions: list or numpy.ndarray or None
    
        :param a_high_scores: Scores/probabilities associated with each product, used for:
                              - LOW observation features,
                              If None, ``a_high`` is used as a proxy score vector.
        :type a_high_scores: numpy.ndarray or None
    
        :param chosen_order: Optional explicit visiting order (product indices). If provided,
                             it is respected after filtering to keep only active products.
        :type chosen_order: numpy.ndarray or None
    
        :return: (obs_next, reward, terminated, truncated, info), where:
                 - obs_next: HIGH-level observation for the next period,
                 - reward: scalar reward for the current period,
                 - terminated: True if the episode horizon is reached,
                 - truncated: always False in this implementation,
                 - info: dictionary with detailed metrics (costs, LOW sequence, etc.).
        :rtype: tuple
        """
        
        # ------------------------------
        # 1) HIGH action and validation
        # ------------------------------
        a_high = np.asarray(a_high, dtype=np.int8)
        self.last_a_high = a_high.copy()
    
        # Scores for LOW features / ordering
        if a_high_scores is None:
            scores_vec = a_high.astype(np.float32)
        else:
            scores_vec = np.clip(np.asarray(a_high_scores, dtype=np.float32), 0.0, 1.0)
    
        # ---------------------------
        # 2) No-production case
        # ---------------------------
        active = np.nonzero(a_high)[0]
    
        if active.size == 0:
            # Demand only → inventory decreases
            d = self._sample_demand()
            self.I = self.I - d
    
            # Inventory clipping (if enabled)
            if self.enable_Ilim:
                hi = self.I_lim.astype(np.int32)
                lo = (-0.5 * self.I_lim).astype(np.int32)
                self.I = np.clip(self.I, lo, hi)
    
            # Costs
            holding = self.h * np.clip(self.I, 0, None)
            backord = self.b * np.clip(-self.I, 0, None)
            z = np.zeros(self.K, dtype=np.int8)
    
            cost_t = float(holding.sum() + backord.sum())
            reward = -cost_t 
    
            # Time advance
            self.t += 1
            terminated = (self.horizon is not None) and (self.t >= self.horizon)
    
            return (
                self._obs_high(),
                reward,
                terminated,
                False,
                {
                    "cost": cost_t,
                    "low_seq_used": [],
                    "q": np.zeros(self.K, dtype=np.int32),
                    "z": z,
                    "holding": holding.astype(np.float32),
                    "backord": backord.astype(np.float32),
                    "setup_cost": (self.k * z).astype(np.float32),
                    "chosen_order_used": np.array([], dtype=int),
                    "a_high_scores_used": scores_vec.copy(),
                    "normalize_rewards_flag": self.normalize_rewards_flag,
                    "normalize_advantages_flag": self.normalize_advantages_flag,
                },
            )

        # ---------------------------------------------------------
        # 3) Quantity-assignment order: highest prob decides first
        # ---------------------------------------------------------
        chosen = self.plan_quantity_assignment_order(a_high, scores_vec)
        
        # ---------------------------
        # 4) Per-period state
        # ---------------------------
        CAP_rem = self.CAP
        z = np.zeros(self.K, dtype=np.int8)      # setups performed
        q = np.zeros(self.K, dtype=np.int32)     # batches produced
        seq_used = []
        
        # Normalize low_actions to match the length of chosen
        if low_actions is None:
            low_actions = [0] * chosen.size
        else:
            low_actions = list(low_actions)
            if len(low_actions) < chosen.size:
                low_actions.extend([0] * (chosen.size - len(low_actions)))
            low_actions = low_actions[:chosen.size]
        
        I_view = self.I.copy()
        produced_count = 0

        # -------------------------------------------
        # 5) LOW loop: decide quantities per product
        # -------------------------------------------
        for pos, i in enumerate(chosen):
            low_s, mask_q, need_setup = self._low_state_mask_for(
                i,
                CAP_rem,
                a_high_scores=scores_vec,
                pos=pos,
                chosen=chosen,
                I_view=I_view,
                a_high_vec=a_high,  # current binary HIGH action
            )
        
        
            q_i = int(low_actions[pos])   
            q_i = max(0, min(q_i, self.CAP))  
            
            # If q_i is invalid according to mask_q, select a valid alternative
            if mask_q[q_i] <= 0:
                feas_q = np.nonzero(mask_q > 0)[0]
                q_i = int(feas_q[-1]) if feas_q.size > 0 else 0
        
            # Update capacity and setups
            if q_i > 0 and need_setup:
                z[i] = 1
                CAP_rem -= self.st[i]
        
            q[i] = q_i
            CAP_rem = max(0, CAP_rem - q_i)
        
            # Within-period "visible" inventory update
            if q_i > 0:
                I_view[i] = I_view[i] + q_i * self.bs[i]
                produced_count += 1
        
            seq_used.append({
                "idx": int(i),
                "mask_q": mask_q.copy(),      
                "chosen_q": int(q_i),
                "CAP_rem_after": int(CAP_rem),
            })


        # -------------------------------
        # 6) Apply production and demand
        # -------------------------------
        if np.any(q):
            self.I = self.I + q * self.bs
        
        d = self._sample_demand()
        self.I = self.I - d
        
        if self.enable_Ilim:
            hi = self.I_lim.astype(np.int32)
            lo = (-0.5 * self.I_lim).astype(np.int32)
            self.I = np.clip(self.I, lo, hi)
        
        # ---------------------------
        # 7) Costs and reward
        # --------------------------
        I_pos = np.clip(self.I, 0, None)
        I_neg = np.clip(-self.I, 0, None)
        
        holding = (self.h * I_pos).astype(np.float32)
        backord = (self.b * I_neg).astype(np.float32)
        setup_cost = (self.k * z).astype(np.float32)
        
        cost_t = float(holding.sum() + backord.sum() + setup_cost.sum())
        reward = -cost_t 
        
        # ---------------------------
        # 8) Update setup carryover
        # ---------------------------
        produced_mask = (q > 0).astype(np.int8)
        produced = np.nonzero(produced_mask)[0]
        if produced.size > 0:
            # Uses pseudo-inventory final (I_view already includes within-period production)
            prod_order = self.plan_production_order_paper(
                produced_mask=produced_mask,
                a_high_scores=scores_vec,
                I_view_final=I_view
            )
            last = int(prod_order[-1]) if prod_order.size > 0 else int(produced[-1])
            self.omega[:] = 0
            self.omega[last] = 1

        
        # ---------------------------------
        # 9) Time and termination condition
        # ---------------------------------
        self.t += 1
        terminated = (self.horizon is not None) and (self.t >= self.horizon)
        
        # ---------------------------
        # 10) Output
        # ---------------------------
        obs_next = self._obs_high().astype(np.float32)
        info = dict(
            cost=cost_t,
            low_seq_used=seq_used,
            q=q,
            z=z,
            holding=holding,
            backord=backord,
            setup_cost=setup_cost,
            chosen_qty_order=chosen.copy(),
            a_high_scores_used=scores_vec.copy(),
            normalize_rewards_flag=self.normalize_rewards_flag,
            normalize_advantages_flag=self.normalize_advantages_flag,
        )
        
        return obs_next, reward, terminated, False, info



def make_env_from_hyp(hyp, seed=None):
    """
    Create a CLSPHierEnv instance from a hyperparameter dictionary.

    This helper function builds a fully configured hierarchical CLSP environment
    using the contents of a HYP dictionary, ensuring consistency between the
    experimental configuration and the environment dynamics.

    The total per-period capacity (CAP) is derived from the capacity factor and
    the aggregate expected demand, following the convention used in the paper.

    :param hyp: Dictionary containing all environment and algorithm hyperparameters.
                Expected keys include:
                ``K``, ``capacity_factor``, ``mu``, ``bs``, ``h``, ``b``, ``k``, ``st``,
                ``horizon``, and ``cov``.
    :type hyp: dict

    :param seed: Optional random seed for the environment.
    :type seed: int or None

    :return: Instantiated CLSPHierEnv environment.
    :rtype: CLSPHierEnv
    """
    K  = hyp["K"]
    cf = hyp["capacity_factor"]
    mu, bs, h, b, k, st = hyp["mu"], hyp["bs"], hyp["h"], hyp["b"], hyp["k"], hyp["st"]
    CAP = int(np.ceil(cf * (mu.sum() / bs[0])))

    env = CLSPHierEnv(
        K, mu, bs, h, b, k, st, CAP,
        horizon=hyp["horizon"],
        cov=hyp["cov"],
        reserve_future_min=True,
        force_min_batch=True,
        enable_Ilim=True,
        enforce_eoq_qmax=True,
        auto_kmax_from_paper=False,
        enable_ip_eligibility=True,
        demand_corr_mode=hyp.get("demand_corr_mode", None),
        demand_corr_pairs=hyp.get("demand_corr_pairs", None),
        demand_corr_groups=hyp.get("demand_corr_groups", None),
        seed=seed,
    )
    return env

