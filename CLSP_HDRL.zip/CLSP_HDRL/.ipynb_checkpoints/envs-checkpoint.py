import numpy as np
import gymnasium as gym
from gymnasium import spaces

class CLSPHierEnv(gym.Env):
    """
    HRL CLSP Environment (CLSPHierEnv).

    Entorno jerárquico alto/bajo nivel para el problema CLSP con capacidad finita.
    El nivel HIGH selecciona qué productos pueden producirse en cada periodo y el
    nivel LOW decide cuántos batches producir de cada producto elegido.

    Alto nivel (HIGH):
      - Acción:
          :class:`gym.spaces.MultiBinary(K)` → vector binario con productos candidatos.
      - Observación (dim = 2K):
          [ coverage_norm(K), omega_f(K) ]
          donde ``coverage_norm`` es la cobertura normalizada de inventario
          y ``omega_f`` indica el setup activo en {-1, +1}.

    Bajo nivel (LOW):
      - Para cada producto seleccionado por HIGH, decide la cantidad a producir en batches.
      - Observación LOW (dim = 4K + 2):
          [ onehot_norm(K)
          , cap_norm(1)
          , a_high_norm(K)
          , a_high_bin(K)
          , need_setup_norm(1)
          , coverage_norm(K)]

    Recompensa por periodo:
      - ``r_t = - coste_t * reward_scale``,
        donde ``coste_t`` incluye inventario, backorders y setups.

    Parámetros
    ----------
    :param K: Número de productos.
    :type K: int

    :param mu: Demanda media por producto. Escalar o array-like de longitud K.
    :type mu: float or array-like

    :param bs: Tamaño de lote (unidades por batch) para cada producto.
    :type bs: int or array-like

    :param h: Coste unitario de inventario por producto.
    :type h: float or array-like

    :param b: Coste unitario de backorder por producto.
    :type b: float or array-like

    :param k: Coste de setup por producto.
    :type k: float or array-like

    :param st: Tiempo de setup por producto (en unidades de capacidad).
    :type st: int or array-like

    :param CAP: Capacidad total por periodo (en número de batches).
    :type CAP: int

    :param cov: Coeficiente(s) de variación de la demanda por producto.
                Se usa para parametrizar el modelo de demanda uniforme del paper.
    :type cov: float or array-like

    :param cov_tau: Límite de cobertura usado para recortar ``I / mu`` y normalizarlo a [-1, 1].
    :type cov_tau: float

    :param reserve_future_min: Si es ``True``, el LOW reserva capacidad mínima para
                               productos aún no visitados en el periodo.
    :type reserve_future_min: bool

    :param force_min_batch: Si es ``True``, el LOW fuerza producir al menos un batch
                            cuando hay capacidad disponible.
    :type force_min_batch: bool

    :param order_mode: Regla para el orden de visita LOW.
                       ``"prob"`` (orden por score) o ``"paper"`` (heurística del artículo).
    :type order_mode: str

    :param cover_order: Flag legado; sólo relevante cuando ``order_mode="prob"``.
    :type cover_order: bool

    :param enable_Ilim: Si es ``True``, acota el inventario a
                        ``[-0.5 · I_lim, I_lim]`` con ``I_lim = 15 · mu``.
    :type enable_Ilim: bool

    :param enforce_eoq_qmax: Si es ``True``, limita la cantidad máxima por producto
                             usando la EOQ como referencia.
    :type enforce_eoq_qmax: bool

    :param eoq_slack_batches: Holgura adicional (en batches) sobre el límite EOQ.
    :type eoq_slack_batches: int

    :param auto_kmax_from_paper: Si es ``True``, calcula automáticamente ``Kmax``
                                 siguiendo el apéndice del paper.
    :type auto_kmax_from_paper: bool

    :param kmax_prob_threshold: Umbral de probabilidad usado para definir ``Kmax``
                                a partir de la distribución Poisson–binomial.
    :type kmax_prob_threshold: float

    :param enable_ip_eligibility: Activa la máscara de elegibilidad del HIGH basada
                                  en inventario y estado de setup.
    :type enable_ip_eligibility: bool

    :param reward_scale: Factor de escala de la recompensa
                         (``r_t = -coste_t * reward_scale``).
    :type reward_scale: float

    :param horizon: Longitud del episodio en periodos.
                    Si es ``None``, el horizonte es ilimitado.
    :type horizon: int or None

    :param seed: Semilla base para el RNG interno cuando ``demand_rng`` es ``None``.
    :type seed: int or None

    :param normalize_rewards_flag: Pista para el trainer; el entorno **no**
                                   normaliza recompensas internamente.
    :type normalize_rewards_flag: bool

    :param normalize_advantages_flag: Pista para el trainer; el entorno **no**
                                      normaliza ventajas internamente.
    :type normalize_advantages_flag: bool
    """

    metadata = {"render_modes": []}
        
    def __init__(
        self,
        # ------------------------
        # Parámetros del problema
        # ------------------------
        K, mu, bs, h, b, k, st, CAP,
        # ------------------------
        # Demanda / normalización
        # ------------------------
        cov=None, cov_tau=5.0,
        # ------------------------
        # Comportamiento LOW
        # ------------------------
        reserve_future_min=False, force_min_batch=False,
        # ------------------------
        # Control HIGH / heurística
        # ------------------------
        order_mode="prob",
        # ------------------------
        # Límites / toggles (paper)
        # ------------------------
        enable_Ilim=True,
        enforce_eoq_qmax=False,
        eoq_slack_batches=0,
        auto_kmax_from_paper=False,
        kmax_prob_threshold=0.01,
        enable_ip_eligibility=False,
        # ------------------------
        # Recompensa / episodio
        # ------------------------
        reward_scale=1e-2, horizon=None,
        # ------------------------
        # Semilla y flags trainer
        # ------------------------
        seed=None,
        normalize_rewards_flag=True,
        normalize_advantages_flag=True,
    ):
        super().__init__()

        # -----------------------
        # 1) Parámetros base
        # -----------------------
        self.K = K
        self.CAP = CAP

        # Vectoriza con tipos correctos
        self.mu = np.asarray(mu, dtype=np.float32)
        self.bs = np.asarray(bs, dtype=np.int32)
        self.h  = np.asarray(h, dtype=np.float32)
        self.b  = np.asarray(b, dtype=np.float32)
        self.k  = np.asarray(k, dtype=np.float32)
        self.st = np.asarray(st, dtype=np.int32)

        # -----------------------
        # 2) Demanda / normalización
        # -----------------------
        self.cov = np.asarray(cov, dtype=np.float32)
        self.cov_tau = cov_tau

        # -----------------------
        # 3) Modo de orden HIGH
        # -----------------------
        self.order_mode = order_mode

        # -----------------------
        # 4) RNG y horizonte
        # -----------------------
        self._seed = seed
        self.rng = np.random.default_rng(seed)
        self.horizon = horizon

        # -----------------------
        # 5) Estado interno
        # -----------------------
        self.last_a_high = np.zeros(self.K, dtype=np.int8)
        self.reward_scale = reward_scale

        # -----------------------
        # 6) Límites de inventario
        # -----------------------
        self.enable_Ilim = enable_Ilim
        self.I_lim = 15.0 * self.mu

        # -----------------------
        # 7) Flags LOW
        # -----------------------
        self.reserve_future_min = reserve_future_min
        self.force_min_batch_default = force_min_batch

        # -----------------------
        # 8) EOQ → q_max opcional
        # -----------------------
        self.enforce_eoq_qmax = enforce_eoq_qmax
        self.eoq_slack_batches = eoq_slack_batches
        self._Q_eoq = None
        self._qmax_eoq = None
        
        if self.enforce_eoq_qmax:
            # EOQ clásico: Q_eoq = sqrt(2 * mu * k / h)
            self._Q_eoq = np.sqrt(2.0 * self.mu * self.k / self.h)
        
            # Límite en batches: floor(Q_eoq / bs) + holgura
            self._qmax_eoq = np.floor(self._Q_eoq / self.bs).astype(int) + self.eoq_slack_batches

        # -----------------------
        # 9) Kmax automático
        # -----------------------
        self.auto_kmax_from_paper = auto_kmax_from_paper
        self.kmax_prob_threshold = kmax_prob_threshold
        self.Kmax = None
        
        if self.auto_kmax_from_paper:
            self.Kmax = self._compute_Kmax()

        # -----------------------
        # 10) Elegibilidad HIGH
        # -----------------------
        self.enable_ip_eligibility = enable_ip_eligibility

        # -----------------------
        # 11) Señales al trainer
        # -----------------------
        self.normalize_rewards_flag = normalize_rewards_flag
        self.normalize_advantages_flag = normalize_advantages_flag

        # -----------------------
        # 12) Espacios gym
        # -----------------------
        self.observation_space = spaces.Box(
            low=-np.ones(2 * self.K, dtype=np.float32),
            high=np.ones(2 * self.K, dtype=np.float32),
            dtype=np.float32,
        )
        self.action_space = spaces.MultiBinary(self.K)
        self._low_action_n = self.CAP + 1

        # -----------------------
        # 13) Preparar demanda y estado inicial
        # -----------------------
        self._setup_demand_params()
        self.reset()


    
    # ==============================================================
    # =============  Demanda: modelo uniforme (paper)  =============
    # ==============================================================
    def _setup_demand_params(self):
        """
        Define los rangos de demanda uniforme para cada producto
        según COV y la media mu, siguiendo el paper:
    
          - COV = 0.58, mu = 4 → U{0, 8}
          - COV = 0.58, mu = 2 → U{0, 4}
          - COV = 0.14, mu = 4 → U{3, 5}
    
        El resto de combinaciones usan un fallback razonable.
        """
        cov = self.cov.astype(np.float32, copy=False)
        mu  = self.mu.astype(np.float32, copy=False)
    
        K = self.K
        a = np.empty(K, dtype=np.int32)
        b = np.empty(K, dtype=np.int32)
    
        for i in range(K):
            if np.isclose(cov[i], 0.58, atol=1e-3):
                # Alta variabilidad (paper):
                if np.isclose(mu[i], 4.0, atol=1e-3):
                    # Caso explícito del paper: U{0, 8}
                    a[i], b[i] = 0, 8
                elif np.isclose(mu[i], 2.0, atol=1e-3):
                    # Para mu=2 con mismo COV≈0.58 → U{0, 4}
                    a[i], b[i] = 0, 4
                else:
                    # Fallback genérico: simétrico alrededor de mu
                    R = int(round(2 * mu[i]))  # da COV ~ 0.58
                    a[i], b[i] = int(mu[i] - R), int(mu[i] + R)
            else:
                # COV bajo (0.14) – sólo se usa en Set 1 con mu=4
                if np.isclose(mu[i], 4.0, atol=1e-3):
                    # Caso explícito del paper: U{3, 5}
                    a[i], b[i] = 3, 5
                else:
                    # Fallback: sin variabilidad (demanda casi determinista)
                    a[i] = b[i] = int(round(mu[i]))
    
        self._unif_a = a
        self._unif_b = b

    
    
    # ==============================================================
    # =============  Muestreo de demanda por periodo  ===============
    # ==============================================================
    def _sample_demand(self):
        """
        Genera una muestra de demanda entera para el periodo actual.
    
        Para cada producto i se muestrea de una uniforme discreta U{a_i, b_i},
        donde a_i y b_i se han definido en `_setup_demand_params`.

        :return: Vector de demandas enteras para los K productos, 
                 donde cada elemento cumple d_i ∈ [a_i, b_i].
        :rtype: numpy.ndarray
        """
        # high = b_i + 1 por la convención de np.integers (límite superior exclusivo)
        demand = self.rng.integers(low=self._unif_a, high=self._unif_b + 1, size=self.K, dtype=np.int32)
        return demand

        
    # ==============================================================
    # =============  Observaciones para el ALTO nivel  =============
    # ==============================================================
    def _coverage_norm_vec(self, I_view=None):
        """
        Calcula el vector de cobertura normalizada de inventarios.

        La cobertura de cada producto se define como:

            coverage_i = I_i / mu_i

        Posteriormente, se recorta el valor al rango [-cov_tau, +cov_tau] 
        y se escala linealmente para que quede en [-1, +1].

        :param I_view: Inventario alternativo opcional. 
                       Si no se proporciona, se utiliza self.I.
        :type I_view: numpy.ndarray o None

        :return: Vector de cobertura normalizada para los K productos, 
                 con valores en el rango [-1, 1].
        :rtype: numpy.ndarray
        """
        I = self.I if I_view is None else np.asarray(I_view, dtype=np.float32)
    
        coverage = I.astype(np.float32) / self.mu
        cov_tau = np.float32(self.cov_tau)
    
        coverage = np.clip(coverage, -cov_tau, cov_tau) / cov_tau
    
        return coverage.astype(np.float32)

    
    
    def _obs_high(self):
        """
        Construye la observación del agente de nivel alto (HIGH).

        La observación combina la cobertura normalizada del inventario con 
        el estado de los setups activos, generando un vector de dimensión 2K:

            obs_high = [ coverage_norm(K), omega_f(K) ]

        donde:
            - coverage_norm(K): inventarios normalizados en [-1, 1]^K
            - omega_f(K): indicador binario del setup activo en {-1, +1}^K  
                          (+1 si el setup está activo, -1 si no)

        :return: Vector de observación del nivel alto de tamaño (2K,).
        :rtype: numpy.ndarray
        """
        cov_norm = self._coverage_norm_vec()
    
        # omega ∈ {0,1} → omega_f ∈ {-1,+1}
        omega_f = (2 * self.omega - 1).astype(np.float32)
    
        obs_high = np.concatenate((cov_norm, omega_f)).astype(np.float32)
        return obs_high



    # ==============================================================
    # =============  Estado y máscara del BAJO nivel  ==============
    # ==============================================================
    def _low_state_mask_for(self, i, CAP_rem, a_high_scores, pos=None, chosen=None, 
                            force_min_batch=None, I_view=None, a_high_vec=None):

        """
        Construye el estado del agente LOW y las acciones factibles para un producto.

        Para el producto actual i, genera:
          - el estado LOW de dimensión (4K + 2), que incluye:
                * one-hot del producto actual
                * capacidad restante normalizada
                * scores del HIGH normalizados
                * vector binario de productos elegidos
                * indicador de necesidad de setup
                * cobertura de inventario normalizada
          - el conjunto de cantidades factibles en batches
          - una máscara de factibilidad asociada
          - un indicador de si es necesario un nuevo setup

        La capacidad disponible tiene en cuenta:
          - capacidad restante del periodo (CAP_rem),
          - posible reserva mínima para productos futuros,
          - tiempo de setup si aplica,
          - límite opcional por EOQ si está activado.

        :param i: Índice del producto actual.
        :type i: int
        :param CAP_rem: Capacidad restante en el periodo (en batches).
        :type CAP_rem: int
        :param a_high_scores: Scores/probabilidades del HIGH para cada producto (en [0, 1]).
        :type a_high_scores: numpy.ndarray
        :param pos: Posición del producto actual dentro de la secuencia `chosen`.
        :type pos: int or None
        :param chosen: Índices de productos seleccionados por el HIGH para este periodo.
        :type chosen: list or numpy.ndarray or None
        :param force_min_batch: Si es True, fuerza producir al menos un batch cuando hay capacidad.
                                Si es None, se usa `self.force_min_batch_default`.
        :type force_min_batch: bool or None
        :param I_view: Inventario “virtual” utilizado para construir las features.
                       Si es None, se usa `self.I`.
        :type I_view: numpy.ndarray or None

        :return: Tupla (low_s, qs, feas, need_setup), donde:
                 - low_s: vector de estado LOW (4K + 2),
                 - qs: cantidades posibles en batches,
                 - feas: máscara booleana de factibilidad para cada entrada de qs,
                 - need_setup: True si el producto requiere un nuevo setup.
        :rtype: tuple
        """
        
        # Flags y necesidad de setup
        fmb = self.force_min_batch_default if force_min_batch is None else force_min_batch
        st_i = self.st[i]
        need_setup = (self.omega[i] == 0)
    
        # Reserva futura de capacidad (si aplica)
        reserve_future = self._future_min_capacity(chosen, pos) if (chosen is not None and pos is not None) else 0
        cap_for_current = max(0, CAP_rem - reserve_future)
    
        # q_max factible por capacidad y setup
        qmax_natural = min(self._low_action_n - 1, CAP_rem)
    
        if need_setup:
            qmax_res = max(0, min(qmax_natural, cap_for_current - st_i))
        else:
            qmax_res = max(0, min(qmax_natural, cap_for_current))
    
        if self.enforce_eoq_qmax and (self._qmax_eoq is not None):
            qmax_res = min(qmax_res, max(0, self._qmax_eoq[i]))
    
        # Cantidades factibles
        if fmb:
            if qmax_res >= 1:
                qs = np.arange(1, qmax_res + 1, dtype=np.int32)
                feas = np.ones_like(qs, dtype=bool)
            else:
                qs = np.array([0], dtype=np.int32)
                feas = np.array([True], dtype=bool)
        else:
            qs = np.arange(qmax_res + 1, dtype=np.int32)
            feas = np.ones_like(qs, dtype=bool)
    
        # Restricción por setup
        if need_setup and qs.size > 0:
            feas &= ((qs == 0) | ((qs + st_i) <= CAP_rem))
    
        # Fallback si nada es factible
        if not np.any(feas):
            qs = np.array([0], dtype=np.int32)
            feas = np.array([True], dtype=bool)
    
        # -------------------------
        # ====== Estado LOW =======
        # -------------------------
        # One-hot normalizado
        onehot = np.zeros(self.K, dtype=np.float32)
        onehot[i] = 1.0
        onehot_norm = (2 * onehot - 1).astype(np.float32)
    
        # Capacidad restante normalizada en [-1,1]
        cap_norm = np.array([(2 * (CAP_rem / max(1, self.CAP))) - 1], dtype=np.float32)
    
        # Scores HIGH normalizados en [-1,1]
        scores = np.clip(np.asarray(a_high_scores, dtype=np.float32), 0.0, 1.0)
        a_high_norm = (2 * scores - 1).astype(np.float32)
    
        # Vector binario HIGH normalizado a [0,1]
        if a_high_vec is None:
            a_high_vec = (scores > 0.5).astype(np.float32)
        else:
            a_high_vec = np.clip(np.asarray(a_high_vec, dtype=np.float32), 0.0, 1.0)
        a_high_bin = (a_high_vec).astype(np.float32)
    
        # Setup necesario (+1 o -1)
        need_setup_norm = np.array([1 if need_setup else -1], dtype=np.float32)
    
        # Cobertura normalizada
        cov_norm_vec = self._coverage_norm_vec(I_view)
    
        # Estado final
        low_s = np.concatenate(
            (onehot_norm, cap_norm, a_high_norm, a_high_bin, need_setup_norm, cov_norm_vec),
            #(onehot_norm, cap_norm, a_high_bin, need_setup_norm, cov_norm_vec),
            dtype=np.float32
        )
    
        return low_s, qs, feas, bool(need_setup)


    
    # ==============================================================
    # ========  Orden de visita del BAJO nivel (prob / paper) ======
    # ==============================================================
    def plan_low_level(self, a_high, a_high_scores):
        """
        Determina el orden de visita de los productos seleccionados por el HIGH.

        A partir del vector binario de selección del nivel alto, construye la
        secuencia de índices que el nivel bajo (LOW) seguirá al decidir cantidades.

        Comportamiento según modo:
            - ``order_mode = "prob"``:
                ordena los productos elegidos en orden descendente de score.
            - ``order_mode = "paper"``:
                1) primero, el producto con setup activo (si está entre los elegidos),
                2) último, el producto con menor inventario actual,
                3) el resto en medio, ordenados por score descendente.

        Si no se proporcionan scores explícitos, se usa ``a_high`` (0/1) como proxy.

        :param a_high: Vector binario {0,1}^K con los productos seleccionados por el HIGH.
        :type a_high: numpy.ndarray
        :param a_high_scores: Scores o probabilidades asociados a cada producto (opcional).
                              Si es None, se utiliza ``a_high`` como scores.
        :type a_high_scores: numpy.ndarray or None

        :return: Array con los índices de productos en el orden de visita del LOW.
        :rtype: numpy.ndarray
        """
        
        # Vector binario de selección HIGH → aseguramos int8
        a_high = np.asarray(a_high, dtype=np.int8)
        chosen = np.nonzero(a_high)[0]
        if chosen.size == 0:
            return chosen
    
        scores = np.clip(np.asarray(a_high_scores, dtype=np.float32), 0.0, 1.0)
        
        # ------------------------
        # Modo 1: orden puro por score
        # ------------------------
        if self.order_mode == "prob":
            order = np.argsort(scores[chosen])[::-1]
            return chosen[order]
    
        # ------------------------
        # Modo 2: lógica del paper
        # ------------------------
    
        # HEAD → producto con setup activo entre los elegidos (si existe)
        omega_chosen = self.omega[chosen]
        head_idx = np.where(omega_chosen == 1)[0]
        head = chosen[head_idx[0]] if head_idx.size > 0 else None
    
        # TAIL → menor inventario actual
        I_chosen = self.I[chosen]
        tail = chosen[np.argmin(I_chosen)]
    
        # MID → el resto (sin HEAD ni TAIL), ordenados por score descendente
        mask_mid = (chosen != tail)
        if head is not None:
            mask_mid &= (chosen != head)
    
        mid = chosen[mask_mid]
        if mid.size > 0:
            mid = mid[np.argsort(scores[mid])[::-1]]
    
        # Construcción final preservando orden: HEAD → MID → TAIL
        seq = []
        if head is not None:
            seq.append(head)
        seq.extend(mid)
        seq.append(tail)
    
        # Eliminar posibles duplicados (por seguridad)
        uniq = []
        seen = set()
        for i in seq:
            if i not in seen:
                seen.add(i)
                uniq.append(i)
    
        return np.array(uniq, dtype=np.int32)


    
    # ==============================================================
    # ========  Reserva mínima de capacidad a futuro (LOW) =========
    # ==============================================================
    def _future_min_capacity(self, chosen, pos):
        """
        Calcula la capacidad mínima que debe reservarse para los productos aún no visitados
        en el periodo actual, siguiendo la lógica del artículo original.

        La reserva de capacidad se estima considerando:
          - +1 batch por cada producto pendiente de procesar.
          - +st[j] adicional si el producto j requiere setup (omega[j] == 0).

        Si la opción `reserve_future_min` está desactivada o los parámetros no son válidos,
        no se reserva capacidad.

        :param chosen: Índices de los productos seleccionados por el HIGH en el periodo actual.
        :type chosen: list or numpy.ndarray or None
        :param pos: Posición actual (0-based) dentro del vector `chosen`.
        :type pos: int or None

        :return: Capacidad mínima a reservar (entero mayor o igual a 0).
        :rtype: int
        """
        
        if not self.reserve_future_min:
            return 0
    
        # Convertimos chosen a array si no lo es; asumimos que chosen siempre es válido.
        chosen = np.asarray(chosen, dtype=int)
    
        # Si no quedan productos futuros → no hay nada que reservar.
        if pos >= chosen.size - 1:
            return 0
    
        # Productos que quedan por visitar
        fut_idxs = chosen[pos + 1:]
    
        # Cada producto futuro reserva como mínimo 1 batch
        base = fut_idxs.size
    
        # Añadimos coste de setup sólo para los que no tienen setup activo
        needs_setup = (self.omega[fut_idxs] == 0)
        setup_cost = self.st[fut_idxs][needs_setup].sum() if needs_setup.any() else 0
    
        return int(base + setup_cost)


    
    # ==============================================================
    # ========  Máscara de elegibilidad para el HIGH  ==============
    # ==============================================================
    def eligibility_mask_high(self):
        """
        Genera una máscara binaria que indica qué productos son elegibles
        para ser seleccionados por el agente de alto nivel (HIGH).

        Lógica basada en el paper:
          - Si ``enable_ip_eligibility = False`` → todos los productos son elegibles.
          - Si ``enable_ip_eligibility = True``:
                * Un producto se marca como no elegible (0) si:
                    - No tiene setup activo (omega[i] == 0)
                    - Su inventario es alto (I_i > 5 · μ_i)
                * En caso contrario, el producto es elegible (1).

        :return: Vector binario de tamaño (K,), donde:
                 1 = producto elegible,  
                 0 = producto bloqueado.
        :rtype: numpy.ndarray
        """
        if not self.enable_ip_eligibility:
            return np.ones(self.K, dtype=np.int32)
    
        # Producto es no elegible si:
        #   - no tiene setup (omega = 0)
        #   - inventario > 5 * mu
        ineligible = (self.omega == 0) & (self.I > (5.0 * self.mu))
    
        # 1 = elegible, 0 = no elegible
        return (~ineligible).astype(np.int32)



    # ==============================================================
    # ========  Cálculo de Kmax (según apéndice del paper) =========
    # ==============================================================
    def _compute_Kmax(self):
        """
        Estima Kmax, el número máximo de productos distintos que se producen en un periodo,
        siguiendo la aproximación descrita en el apéndice del paper.

        Pasos del cálculo:
            1) TBO_i = sqrt(2 * k_i / (h_i * mu_i))
            2) p1_i  = 1 / TBO_i        → probabilidad de producir el producto i en un periodo
            3) X = Σ Bernoulli(p1_i)    → distribución Poisson–binomial
            4) Kmax = max { k : P(X = k) > kmax_prob_threshold }

        :return: Estimación entera de Kmax.
        :rtype: int
        """
        
        # --- 1) Cálculo de TBO y p1 ---
        h = self.h.astype(np.float64)
        mu = self.mu.astype(np.float64)
        k = self.k.astype(np.float64)
    
        # TBO_i = sqrt(2 k_i / (h_i * mu_i))
        TBO = np.sqrt(2.0 * k / (h * mu))
    
        # Probabilidad de producir el producto i en un periodo
        p1 = np.clip(1.0 / TBO, 0.0, 1.0)
    
        # Casos extremos:
        # - si todas las probabilidades son ~0 → nunca se produce → Kmax = 0
        if np.all(p1 == 0):
            return 0
        # - si todas son 1 → siempre todos se producen → limitado por CAP y K
        if np.all(p1 == 1):
            return min(self.K, self.CAP)
    
        # --- 2) PMF Poisson–binomial via convoluciones ---
        pmf = np.array([1.0], dtype=np.float64)
        for pi in p1:
            pmf = np.convolve(pmf, np.array([1.0 - pi, pi], dtype=np.float64))
    
        # Normalización ligera
        s = pmf.sum()
        if s > 0:
            pmf /= s
    
        # --- 3) Umbral y límites ---
        thr = self.kmax_prob_threshold
        kvals = np.where(pmf > thr)[0]
    
        if kvals.size == 0:
            return 0
    
        kmax_raw = kvals.max()
        return int(min(kmax_raw, self.K, self.CAP))

    
    # ==============================================================
    # ======================== RESET ================================
    # ==============================================================
    def reset(self, seed=None, options=None):
        """
        Reinicia el entorno CLSP al comienzo de un nuevo episodio.

        Este método restablece el estado interno del entorno, incluyendo los
        inventarios, setups activos y el contador temporal.  
        Además, reconfigura el generador de números aleatorios según la semilla
        indicada (o una almacenada previamente en `self._seed`).

        :param seed: Semilla entera opcional para el generador de números aleatorios.
                     Si es None, se usa la semilla guardada en el entorno.
        :type seed: int or None
        :param options: Parámetro estándar de Gymnasium (no utilizado).
        :type options: dict or None

        :return: Tupla (obs, info) donde:
                 - obs: observación inicial del nivel HIGH (vector de float32),
                 - info: diccionario vacío (compatibilidad Gymnasium).
        :rtype: tuple
        """
        
        # Si no se da semilla, usar la interna
        if seed is None:
            seed = self._seed
    
        # Semilla global Gymnasium
        super().reset(seed=seed)
    
        # Re-siembra del RNG interno
        self.rng = np.random.default_rng(seed)
    
        # Estado inicial
        self.I = np.zeros(self.K, dtype=np.int32)
        self.omega = np.zeros(self.K, dtype=np.int8)
        self.t = 0
    
        # Selección reproducible del setup inicial
        active_idx = self.rng.integers(0, self.K)
        self.omega[active_idx] = 1
    
        # Observación inicial
        obs_init = self._obs_high()
        return obs_init, {}

        
    @property
    def low_obs_dim(self):
        """
        Dimensión del vector de observación del agente LOW.  
        Returns:
            int: tamaño del vector de observación para el nivel bajo.
        """
        return 4 * self.K + 2



    # ==============================================================
    # ========================= STEP ===============================
    # ==============================================================
    def step(self, a_high, low_actions=None, a_high_scores=None, chosen_order=None):
        """
        Ejecuta un periodo completo del entorno CLSP jerárquico.

        El nivel HIGH selecciona qué productos son candidatos a producirse en el periodo
        (a través de ``a_high``) y el nivel LOW decide, para cada producto elegido,
        la cantidad de batches a producir, respetando capacidad, setups y (opcionalmente)
        la cota Kmax.

        Flujo general:
            1. Validar y registrar la acción HIGH.
            2. Determinar los productos activos y el orden de visita (explícito o heurístico).
            3. Para cada producto en el orden:
                   - construir estado LOW,
                   - aplicar la acción propuesta (con recortes y máscaras de factibilidad),
                   - actualizar capacidad, setups e inventarios "virtuales".
            4. Aplicar producción, muestrear demanda y actualizar inventarios reales.
            5. Calcular costes (holding, backorder, setups) y recompensa.
            6. Actualizar setups para el siguiente periodo y avanzar el tiempo.
            7. Devolver la nueva observación HIGH y métricas detalladas en `info`.

        :param a_high: Vector binario {0,1}^K con los productos seleccionados por el HIGH.
        :type a_high: numpy.ndarray
        :param low_actions: Acciones LOW propuestas, como índices dentro de los vectores ``qs``
                            devueltos por `_low_state_mask_for` para cada producto elegido.
                            Si es None, se asume 0 para todos.
        :type low_actions: list or numpy.ndarray or None
        :param a_high_scores: Scores/probabilidades asociados a cada producto para:
                              - features del LOW,
                              - ordenación de visita si se usa ``order_mode = "prob"``.
        :type a_high_scores: numpy.ndarray or None
        :param chosen_order: Orden explícito de visita de productos (índices).
                             Si se proporciona, se respeta tras filtrar productos activos.
        :type chosen_order: numpy.ndarray or None

        :return: (obs_next, reward, terminated, truncated, info)
                 - obs_next: observación HIGH del siguiente periodo.
                 - reward: recompensa escalar del periodo actual.
                 - terminated: True si se alcanza el horizonte del episodio.
                 - truncated: siempre False en esta implementación.
                 - info: diccionario con métricas detalladas (costes, secuencia LOW, etc.).
        :rtype: tuple
        """
        
        # ---------------------------
        # 1) Acción HIGH y validación
        # ---------------------------
        a_high = np.asarray(a_high, dtype=np.int8)
        self.last_a_high = a_high.copy()
    
        # Scores para LOW / ordenación
        if a_high_scores is None:
            scores_vec = a_high.astype(np.float32)
        else:
            scores_vec = np.clip(np.asarray(a_high_scores, dtype=np.float32), 0.0, 1.0)
    
        # ---------------------------
        # 2) Caso sin producción
        # ---------------------------
        active = np.nonzero(a_high)[0]
    
        if active.size == 0:
            # Solo demanda → inventario baja
            d = self._sample_demand()
            self.I = self.I - d
    
            # Límite de inventario (si está activo)
            if self.enable_Ilim:
                hi = self.I_lim.astype(np.int32)
                lo = (-0.5 * self.I_lim).astype(np.int32)
                self.I = np.clip(self.I, lo, hi)
    
            # Costes
            holding = self.h * np.clip(self.I, 0, None)
            backord = self.b * np.clip(-self.I, 0, None)
            z = np.zeros(self.K, dtype=np.int8)
    
            cost_t = float(holding.sum() + backord.sum())
            reward = -cost_t * self.reward_scale
    
            # Avance temporal
            self.t += 1
            terminated = (self.horizon is not None) and (self.t >= self.horizon)
    
            return (
                self._obs_high(),
                reward,
                terminated,
                False,
                {
                    "cost": cost_t,
                    "low_seq_used": [],
                    "q": np.zeros(self.K, dtype=np.int32),
                    "z": z,
                    "holding": holding.astype(np.float32),
                    "backord": backord.astype(np.float32),
                    "setup_cost": (self.k * z).astype(np.float32),
                    "chosen_order_used": np.array([], dtype=int),
                    "a_high_scores_used": scores_vec.copy(),
                    "normalize_rewards_flag": self.normalize_rewards_flag,
                    "normalize_advantages_flag": self.normalize_advantages_flag,
                },
            )

        # ---------------------------
        # 3) Orden de visita de productos
        # ---------------------------
        if chosen_order is not None:
            chosen_order = np.asarray(chosen_order, dtype=int)
            # Filtrar solo los productos activos
            chosen = chosen_order[np.isin(chosen_order, active)]
        else:
            chosen = self.plan_low_level(a_high, a_high_scores=scores_vec)
        
        # ---------------------------
        # 4) Estado del periodo
        # ---------------------------
        CAP_rem = self.CAP
        z = np.zeros(self.K, dtype=np.int8)      # setups aplicados
        q = np.zeros(self.K, dtype=np.int32)     # batches producidos
        seq_used = []
        
        # Normalizar low_actions al tamaño de chosen
        if low_actions is None:
            low_actions = [0] * chosen.size
        else:
            low_actions = list(low_actions)
            if len(low_actions) < chosen.size:
                low_actions.extend([0] * (chosen.size - len(low_actions)))
            low_actions = low_actions[:chosen.size]
        
        I_view = self.I.copy()
        produced_count = 0


        # ---------------------------
        # 5) Bucle LOW: decidir cantidades por producto
        # ---------------------------
        for pos, i in enumerate(chosen):
            low_s, qs, feas, need_setup = self._low_state_mask_for(
                i,
                CAP_rem,
                a_high_scores=scores_vec,
                pos=pos,
                chosen=chosen,
                I_view=I_view,
                a_high_vec=a_high,  # acción binaria HIGH actual
            )
        
            # Límite Kmax: si ya hemos producido Kmax productos, sólo permitimos q = 0
            if self.Kmax is not None and produced_count >= self.Kmax:
                feas = np.zeros_like(feas, dtype=bool)
                if qs.size > 0 and qs[0] == 0:
                    feas[0] = True
        
            # Si no hay acciones posibles, fijamos q_i = 0 directamente
            if qs.size == 0:
                q_i = 0
                a_idx = 0
            else:
                # Índice propuesto por el agente LOW (clamp al rango válido)
                a_idx = int(low_actions[pos])
                a_idx = max(0, min(a_idx, qs.size - 1))
        
                # Si la acción propuesta no es factible, usamos la última factible; si no hay, 0
                if not feas[a_idx]:
                    feas_idxs = np.nonzero(feas)[0]
                    a_idx = int(feas_idxs[-1]) if feas_idxs.size > 0 else 0
        
                q_i = int(qs[a_idx])
        
            # Actualizar capacidad y setups
            if q_i > 0 and need_setup:
                z[i] = 1
                CAP_rem -= self.st[i]
        
            q[i] = q_i
            CAP_rem = max(0, CAP_rem - q_i)
        
            # Inventario "visible" dentro del periodo
            if q_i > 0:
                I_view[i] = I_view[i] + q_i * self.bs[i]
                produced_count += 1
        
            seq_used.append(
                {
                    "idx": int(i),
                    "qs": qs,
                    "feas": feas,
                    "chosen_idx": int(a_idx),
                    "chosen_q": int(q_i),
                    "CAP_rem_after": int(CAP_rem),
                }
            )


        # ---------------------------
        # 6) Actualizar inventario con producción y demanda
        # ---------------------------
        if np.any(q):
            self.I = self.I + q * self.bs
        
        d = self._sample_demand()
        self.I = self.I - d
        
        if self.enable_Ilim:
            hi = self.I_lim.astype(np.int32)
            lo = (-0.5 * self.I_lim).astype(np.int32)
            self.I = np.clip(self.I, lo, hi)
        
        # ---------------------------
        # 7) Costes y recompensa
        # ---------------------------
        I_pos = np.clip(self.I, 0, None)
        I_neg = np.clip(-self.I, 0, None)
        
        holding = (self.h * I_pos).astype(np.float32)
        backord = (self.b * I_neg).astype(np.float32)
        setup_cost = (self.k * z).astype(np.float32)
        
        cost_t = float(holding.sum() + backord.sum() + setup_cost.sum())
        reward = -cost_t * self.reward_scale
        
        # ---------------------------
        # 8) Actualizar setups (carryover)
        # ---------------------------
        produced = np.nonzero(q > 0)[0]
        if produced.size > 0:
            last = produced[-1]
            self.omega[:] = 0
            self.omega[last] = 1
        # Si no hubo producción, se mantiene self.omega
        
        # ---------------------------
        # 9) Tiempo y condición de fin
        # ---------------------------
        self.t += 1
        terminated = (self.horizon is not None) and (self.t >= self.horizon)
        
        # ---------------------------
        # 10) Salida
        # ---------------------------
        obs_next = self._obs_high().astype(np.float32)
        info = dict(
            cost=cost_t,
            low_seq_used=seq_used,
            q=q,
            z=z,
            holding=holding,
            backord=backord,
            setup_cost=setup_cost,
            chosen_order_used=chosen.copy(),
            a_high_scores_used=scores_vec.copy(),
            normalize_rewards_flag=self.normalize_rewards_flag,
            normalize_advantages_flag=self.normalize_advantages_flag,
        )
        
        return obs_next, reward, terminated, False, info



def make_env_from_hyp(hyp, seed=None):
    """
    Crea una instancia de CLSPHierEnv a partir de un diccionario HYP.
    """
    K  = hyp["K"]
    cf = hyp["capacity_factor"]
    mu, bs, h, b, k, st = hyp["mu"], hyp["bs"], hyp["h"], hyp["b"], hyp["k"], hyp["st"]
    CAP = int(np.ceil(cf * (mu.sum() / bs[0])))

    env = CLSPHierEnv(
        K, mu, bs, h, b, k, st, CAP,
        reward_scale=hyp["reward_scale"],
        horizon=hyp["horizon"],
        cov=hyp["cov"],
        reserve_future_min=hyp["reserve_future_min"],
        force_min_batch=hyp["force_min_batch"],
        enable_Ilim=hyp["enable_Ilim"],
        enforce_eoq_qmax=hyp["enforce_eoq_qmax"],
        auto_kmax_from_paper=hyp["auto_kmax_from_paper"],
        enable_ip_eligibility=hyp["enable_ip_eligibility"],
        order_mode="paper",
        seed=seed,
    )
    return env

