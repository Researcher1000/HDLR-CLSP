import numpy as np
import torch


# ============================================================
# =============== Utilidad: discount_cumsum ==================
# ============================================================
def discount_cumsum(x, discount):
    """
    Calcula la **suma acumulada descontada** de una secuencia temporal.

    Esta operación se usa para calcular retornos o ventajas en métodos de
    refuerzo, acumulando las recompensas futuras ponderadas por el factor
    de descuento γ.

    Fórmula:
        y[t] = x[t] + γ * x[t+1] + γ² * x[t+2] + ... 

    :param x: Secuencia de valores (por ejemplo, recompensas o ventajas)
              a lo largo del tiempo.
    :type x: array-like o np.ndarray
    :param discount: Factor de descuento γ ∈ (0, 1].
    :type discount: float

    :return: Vector con las sumas descontadas, del mismo tamaño que `x`.
    :rtype: np.ndarray
    """
    x = np.asarray(x, dtype=np.float32)
    y = np.empty_like(x)
    acc = 0.0

    # Recorre hacia atrás acumulando valores futuros con descuento
    for t in range(len(x) - 1, -1, -1):
        acc = x[t] + discount * acc
        y[t] = acc

    return y

# ============================================================
# ====================== HighLevelBuffer =====================
# ============================================================
class HighLevelBuffer:
    """
    Buffer para el agente de nivel ALTO (HIGH) en PPO.

    Se encarga de almacenar trayectorias y preparar los datos necesarios
    para el entrenamiento del actor-crítico de alto nivel.

    Funcionalidad principal:
      - Almacena:
          * observaciones
          * acciones MultiBinary
          * recompensas
          * valores del crítico
          * log-probabilidades antiguas
          * máscaras de elegibilidad
      - Calcula:
          * ventajas (usando GAE(λ))
          * retornos descontados
      - Opcionalmente:
          * normaliza recompensas mediante media móvil exponencial (EMA)
          * normaliza ventajas por batch (media 0, var ≈ 1)

    :param obs_dim: Dimensión de la observación del nivel alto.
    :type obs_dim: int
    :param act_dim: Dimensión de la acción MultiBinary (número de productos).
    :type act_dim: int
    :param size: Número máximo de pasos almacenados en el buffer.
    :type size: int
    :param gamma: Factor de descuento γ.
    :type gamma: float
    :param lam: Parámetro λ de GAE.
    :type lam: float
    :param device: Dispositivo destino para los tensores devueltos ("cpu" o "cuda").
    :type device: str
    :param normalize_rewards: Si es True, aplica normalización móvil de recompensas.
    :type normalize_rewards: bool
    :param normalize_advantages: Si es True, normaliza ventajas al extraer el batch.
    :type normalize_advantages: bool
    :param reward_norm_momentum: Momento de la EMA para la normalización de recompensas.
    :type reward_norm_momentum: float
    """

    def __init__(self, obs_dim, act_dim, size, gamma=0.99, lam=0.95, device="cpu", normalize_rewards=False, 
                 normalize_advantages=True, reward_norm_momentum=0.99):
        # Buffers de datos
        self.obs_buf = np.zeros((size, obs_dim), dtype=np.float32)
        self.act_buf = np.zeros((size, act_dim), dtype=np.float32)
        self.adv_buf = np.zeros(size, dtype=np.float32)
        self.rew_buf = np.zeros(size, dtype=np.float32)
        self.ret_buf = np.zeros(size, dtype=np.float32)
        self.val_buf = np.zeros(size, dtype=np.float32)
        self.logp_buf = np.zeros(size, dtype=np.float32)
        self.mask_buf = np.zeros((size, act_dim), dtype=np.float32)

        # Hiperparámetros y estado del buffer
        self.gamma = gamma
        self.lam = lam
        self.ptr = 0
        self.path_start_idx = 0
        self.max_size = size
        self.device = device

        # Opciones de normalización
        self.normalize_rewards = normalize_rewards
        self.normalize_advantages = normalize_advantages
        self.reward_norm_momentum = reward_norm_momentum

        # Estadísticos móviles de recompensas
        self.r_mean = 0.0
        self.r_std = 1.0
        self._initialized_stats = False

    # --------------------------------------------------------
    # Almacenamiento de una transición
    # --------------------------------------------------------
    def store(self, obs, act, rew, val, logp, mask):
        """
        Inserta una transición en el buffer.

        Guarda una tupla (obs, act, rew, val, logp, mask) en la posición actual.

        :param obs: Observación del estado.
        :type obs: np.ndarray
        :param act: Acción tomada (vector MultiBinary).
        :type act: np.ndarray
        :param rew: Recompensa inmediata.
        :type rew: float
        :param val: Valor V(s) estimado por el crítico.
        :type val: float
        :param logp: Log-probabilidad de la acción bajo la política antigua.
        :type logp: float
        :param mask: Máscara de elegibilidad asociada a la acción.
        :type mask: np.ndarray
        """
        assert self.ptr < self.max_size, "Buffer lleno; llama a get() antes de seguir."

        self.obs_buf[self.ptr] = obs
        self.act_buf[self.ptr] = act
        self.rew_buf[self.ptr] = rew
        self.val_buf[self.ptr] = val
        self.logp_buf[self.ptr] = logp
        self.mask_buf[self.ptr] = mask

        self.ptr += 1

    # --------------------------------------------------------
    # Estadísticos móviles de recompensas
    # --------------------------------------------------------
    def _update_running_reward_stats(self, batch_mean, batch_std):
        """
        Actualiza la media y desviación estándar de recompensas con una EMA.

        Similar a la estrategia usada en VecNormalize (Stable-Baselines3).

        :param batch_mean: Media de recompensas del batch.
        :type batch_mean: float
        :param batch_std: Desviación estándar de recompensas del batch.
        :type batch_std: float
        """
        batch_mean = float(batch_mean)
        batch_std = float(batch_std)
    
        # Evitar std = 0
        batch_std = max(batch_std, 1e-8)
    
        if not self._initialized_stats:
            # Primer batch: copiar directamente sus estadísticas
            self.r_mean = np.float32(batch_mean)
            self.r_std = np.float32(batch_std)
            self._initialized_stats = True
            return
    
        m = self.reward_norm_momentum  # típicamente algo como 0.9–0.99
    
        # EMA: nuevo = m * viejo + (1 - m) * batch
        self.r_mean = np.float32(m * self.r_mean + (1.0 - m) * batch_mean)
        self.r_std  = np.float32(m * self.r_std  + (1.0 - m) * batch_std)

        
    # --------------------------------------------------------
    # Cierre de trayectoria: cálculo de ventajas y retornos
    # --------------------------------------------------------
    def finish_path(self, last_val=0.0):
        """
        Cierra la trayectoria actual y calcula ventajas GAE y retornos.

        Opera sobre el segmento [path_start_idx : ptr) del buffer. Este método
        debe llamarse al finalizar un episodio o al cortar una trayectoria.

        Si `normalize_rewards=True`, las recompensas del segmento se normalizan
        usando estadísticos móviles antes de aplicar GAE.

        :param last_val: Valor estimado en el siguiente estado al final de la trayectoria
                         (0.0 si el episodio terminó).
        :type last_val: float
        """
        ps = slice(self.path_start_idx, self.ptr)
    
        rews = self.rew_buf[ps].astype(np.float32, copy=False)
        vals = self.val_buf[ps].astype(np.float32, copy=False)
    
        # ----------------------------------------------------
        # Normalización móvil de recompensas (opcional)
        # ----------------------------------------------------
        if self.normalize_rewards and rews.size > 0:
            batch_mean = float(rews.mean())
            batch_std  = float(rews.std())
            self._update_running_reward_stats(batch_mean, batch_std)
    
            rews = (rews - self.r_mean) / (self.r_std + 1e-8)
            self.rew_buf[ps] = rews  # mantener buffer coherente
    
        # ----------------------------------------------------
        # Cálculo de GAE(λ) y retornos
        # ----------------------------------------------------
        if rews.size > 0:
            # next_vals: vals desplazados, + last_val en el final
            next_vals = np.concatenate(
                [vals[1:], np.array([last_val], dtype=np.float32)]
            )
    
            deltas = rews + self.gamma * next_vals - vals
            adv = discount_cumsum(deltas, self.gamma * self.lam)
            ret = adv + vals
    
            self.adv_buf[ps] = adv.astype(np.float32)
            self.ret_buf[ps] = ret.astype(np.float32)
    
        # Reiniciar inicio del siguiente segmento
        self.path_start_idx = self.ptr

    
    # --------------------------------------------------------
    # Recuperación del batch para entrenamiento PPO
    # --------------------------------------------------------
    def get(self):
        """
        Devuelve el contenido del buffer como tensores listos para PPO
        y resetea los punteros internos.

        Si `normalize_advantages=True`, normaliza las ventajas del batch.

        :return: Diccionario con:
                 - 'obs': observaciones
                 - 'act': acciones
                 - 'ret': retornos
                 - 'adv': ventajas (normalizadas si aplica)
                 - 'logp': log-probabilidades antiguas
                 - 'val': valores V(s)
                 - 'mask': máscaras de elegibilidad
        :rtype: dict
        """
        assert self.ptr == self.max_size, "El buffer no está completo aún."

        adv = self.adv_buf
        if self.normalize_advantages and adv.size > 0:
            std = adv.std()
            if std > 1e-8:
                adv_norm = (adv - adv.mean()) / (std + 1e-8)
            else:
                adv_norm = adv - adv.mean()
        else:
            adv_norm = adv

        data = dict(
            obs=torch.as_tensor(self.obs_buf, device=self.device),
            act=torch.as_tensor(self.act_buf, device=self.device),
            ret=torch.as_tensor(self.ret_buf, device=self.device),
            adv=torch.as_tensor(adv_norm, device=self.device),
            logp=torch.as_tensor(self.logp_buf, device=self.device),
            val=torch.as_tensor(self.val_buf, device=self.device),
            mask=torch.as_tensor(self.mask_buf, device=self.device),
        )

        # Reset de punteros para siguiente recopilación
        self.ptr = 0
        self.path_start_idx = 0

        return data



# ============================================================
# =============== LowLevelBufferFuture =======================
# ============================================================
class LowLevelBuffer:
    """
    Buffer para el agente de nivel BAJO (LOW) en el esquema jerárquico.

    Cada subpaso dentro de un mismo periodo recibe la misma recompensa global
    del periodo (r_t = -coste_t * reward_scale), igual que el nivel HIGH.
    Sobre la secuencia lineal de subpasos se calcula GAE y retornos.

    Flujo típico de uso:
      - start_period()
      - store_substep(...)
      - end_period_assign_global_reward(r_period)
      - finish_episode_and_collect(last_val)
      - is_batch_ready(target_periods) / get()

    Este buffer puede acumular varios episodios antes de construir el batch final.
    
    :param obs_dim: Dimensión de la observación LOW.
    :type obs_dim: int
    :param device: Dispositivo donde se crearán los tensores finales ("cpu" o "cuda").
    :type device: str
    :param gamma: Factor de descuento γ.
    :type gamma: float
    :param lam: Parámetro λ de GAE.
    :type lam: float
    :param normalize_rewards: Si es True, normaliza recompensas con EMA.
    :type normalize_rewards: bool
    :param normalize_advantages: Si es True, normaliza ventajas en el batch final.
    :type normalize_advantages: bool
    :param reward_norm_momentum: Momento de la EMA para la normalización de recompensas.
    :type reward_norm_momentum: float
    """

    def __init__(self, obs_dim, device="cpu", gamma=0.99, lam=0.95, normalize_rewards=False, 
                 normalize_advantages=True, reward_norm_momentum=0.99):
        
        self.device = device
        self.gamma = gamma
        self.lam = lam

        # Episodio actual (secuencia de subpasos)
        self._obs = []
        self._act = []
        self._val = []
        self._logp = []
        self._mask = []
        self._rew = []               # recompensa por subpaso (global del periodo)
        self._period_ranges = []     # [(start_idx, end_idx), ...] por periodo
        self._period_start = 0
        self.periods_in_batch = 0

        # Acumulador de batch (puede contener varios episodios)
        self._batch = dict(obs=[], act=[], val=[], logp=[], mask=[], adv=[], ret=[])

        # Toggles de normalización
        self.normalize_rewards = normalize_rewards
        self.normalize_advantages = normalize_advantages
        self.reward_norm_momentum = reward_norm_momentum

        # Estadísticos EMA para recompensas
        self.r_mean = 0.0
        self.r_std = 1.0
        self._initialized_stats = False
            
    # ---------- Estadística móvil de recompensas ----------
    def _update_running_reward_stats(self, batch_mean, batch_std):
        """
        Actualiza la media y desviación estándar de recompensas mediante EMA.

        Se utiliza para la normalización opcional de recompensas.

        :param batch_mean: Media de recompensas del batch considerado.
        :type batch_mean: float
        :param batch_std: Desviación estándar de recompensas del batch.
        :type batch_std: float
        """
        batch_mean = float(batch_mean)
        batch_std  = float(batch_std)
        batch_std  = max(batch_std, 1e-8)   # evitar std = 0
    
        if not self._initialized_stats:
            self.r_mean = np.float32(batch_mean)
            self.r_std  = np.float32(batch_std)
            self._initialized_stats = True
            return
    
        m = self.reward_norm_momentum
    
        self.r_mean = np.float32(m * self.r_mean + (1.0 - m) * batch_mean)
        self.r_std  = np.float32(m * self.r_std  + (1.0 - m) * batch_std)

    # ---------- Marcadores de periodo ----------
    def start_period(self):
        """
        Marca el inicio de un nuevo periodo dentro del episodio actual.
        """
        self._period_start = len(self._obs)

    def store_substep(self, obs, act, val, logp, mask):
        """
        Almacena un subpaso LOW dentro del periodo actual.

        :param obs: Observación LOW en el subpaso.
        :type obs: array-like
        :param act: Acción discreta seleccionada (índice entero).
        :type act: int
        :param val: Valor V(s) estimado por el crítico LOW.
        :type val: float
        :param logp: Log-probabilidad de la acción bajo la política LOW antigua.
        :type logp: float
        :param mask: Máscara de acciones válidas utilizada en el subpaso.
        :type mask: array-like
        """
        self._obs.append(np.asarray(obs, dtype=np.float32))
        self._act.append(int(act))
        self._val.append(np.float32(val))
        self._logp.append(np.float32(logp))
        self._mask.append(np.asarray(mask, dtype=np.float32))

    def end_period_assign_global_reward(self, r_period):
        """
        Asigna la recompensa global del periodo a todos sus subpasos.

        Si el periodo contiene T subpasos, se replica `r_period` T veces.

        :param r_period: Recompensa total del periodo (e.g. -coste_t * reward_scale).
        :type r_period: float
        """
        start = self._period_start
        end = len(self._obs)
        T = end - start
    
        if T > 0:
            # Añadir T veces la recompensa en float32 (sin crear lista gigante)
            self._rew.extend([np.float32(r_period)] * T)
    
        self._period_ranges.append((start, end))
        self.periods_in_batch += 1

    # ---------- Cierre de episodio y acumulación al batch ----------
    def finish_episode_and_collect(self, last_val=0.0):
        """
        Cierra el episodio actual y acumula sus datos al batch global.

        Calcula ventajas GAE y retornos sobre la secuencia lineal de subpasos,
        usando las recompensas por periodo ya asignadas.

        :param last_val: Valor estimado en el estado siguiente al último subpaso.
                         Usado cuando el episodio termina por truncamiento.
        :type last_val: float
        """
        if len(self._obs) == 0:
            self._reset_episode_buffers()
            return
    
        # Arrays de recompensas y valores en float32
        rew = np.asarray(self._rew, dtype=np.float32)
        val = np.asarray(self._val, dtype=np.float32)
    
        # -------------------------
        # Normalización de recompensas (opcional)
        # -------------------------
        if self.normalize_rewards and rew.size > 0:
            b_mean = float(rew.mean())
            b_std = float(rew.std())
            self._update_running_reward_stats(b_mean, b_std)
            rew = (rew - self.r_mean) / (self.r_std + 1e-8)
    
        # -------------------------
        # Cálculo de ventajas GAE y retornos
        # -------------------------
        if rew.size > 0:
            last_val_f = np.float32(last_val)
            next_vals = np.concatenate(
                (val[1:], np.array([last_val_f], dtype=np.float32))
            )
            deltas = rew + self.gamma * next_vals - val
            adv = discount_cumsum(deltas, self.gamma * self.lam)   # float32
            ret = adv + val
        else:
            adv = np.empty(0, dtype=np.float32)
            ret = np.empty(0, dtype=np.float32)
    
        # -------------------------
        # Acumular al batch global
        # -------------------------
        self._batch["obs"].extend(self._obs)
        self._batch["act"].extend(self._act)
        self._batch["val"].extend(self._val)
        self._batch["logp"].extend(self._logp)
        self._batch["mask"].extend(self._mask)
        self._batch["adv"].extend(adv.tolist())
        self._batch["ret"].extend(ret.tolist())
    
        # Reset buffers del episodio
        self._reset_episode_buffers()

    def _reset_episode_buffers(self):
        """
        Limpia los buffers internos asociados al episodio actual.
        """
        self._obs, self._act, self._val, self._logp, self._mask = [], [], [], [], []
        self._rew = []
        self._period_ranges = []
        self._period_start = 0

    # ---------- Batch listo ----------
    def is_batch_ready(self, target_periods):
        """
        Indica si el número de periodos acumulados alcanza el objetivo.

        :param target_periods: Número mínimo de periodos para considerar el batch listo.
        :type target_periods: int
        :return: True si hay suficientes periodos, False en caso contrario.
        :rtype: bool
        """
        return self.periods_in_batch >= int(target_periods)

    # ---------- Obtener batch como tensores ----------
    def get(self):
        """
        Devuelve el batch acumulado como tensores PyTorch y resetea el acumulador.

        Si `normalize_advantages=True`, normaliza las ventajas del batch.
        Si no hay datos acumulados, devuelve tensores vacíos.

        :return: Diccionario con claves:
                 'obs', 'act', 'adv', 'ret', 'logp', 'val', 'mask'.
        :rtype: dict
        """
        # -----------------------------
        # Caso vacío: no hay transición
        # -----------------------------
        if len(self._batch["obs"]) == 0:
            empty = torch.empty(0, device=self.device)
            self._batch = dict(obs=[], act=[], val=[], logp=[], mask=[], adv=[], ret=[])
            self.periods_in_batch = 0
            return dict(obs=empty, act=empty, adv=empty, ret=empty,
                        logp=empty, val=empty, mask=empty)
    
        # -----------------------------
        # Conversión a tensores
        # -----------------------------
        obs  = torch.tensor(np.array(self._batch["obs"],  dtype=np.float32), device=self.device)
        act  = torch.tensor(np.array(self._batch["act"],  dtype=np.int64),   device=self.device)
        val  = torch.tensor(np.array(self._batch["val"],  dtype=np.float32), device=self.device)
        logp = torch.tensor(np.array(self._batch["logp"], dtype=np.float32), device=self.device)
        mask = torch.tensor(np.array(self._batch["mask"], dtype=np.float32), device=self.device)
        adv  = torch.tensor(np.array(self._batch["adv"],  dtype=np.float32), device=self.device)
        ret  = torch.tensor(np.array(self._batch["ret"],  dtype=np.float32), device=self.device)
    
        # -----------------------------
        # Normalización de ventajas
        # -----------------------------
        if self.normalize_advantages and adv.numel() > 0:
            std = adv.std()
            if std > 1e-8:
                adv = (adv - adv.mean()) / (std + 1e-8)
            else:
                adv = adv - adv.mean()
    
        data = dict(obs=obs, act=act, adv=adv, ret=ret,
                    logp=logp, val=val, mask=mask)
    
        # -----------------------------
        # Limpiar batch acumulado
        # -----------------------------
        self._batch = dict(obs=[], act=[], val=[], logp=[], mask=[], adv=[], ret=[])
        self.periods_in_batch = 0
    
        return data

