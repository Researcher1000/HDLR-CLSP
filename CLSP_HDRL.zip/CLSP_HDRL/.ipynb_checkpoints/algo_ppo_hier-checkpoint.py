import os
import random
from tqdm import trange

import numpy as np
import torch
import torch.nn.functional as F
from torch.optim import Adam
import matplotlib.pyplot as plt

from .utils import set_determinism
from .envs import CLSPHierEnv
from .nets import HighPolicy, LowPolicy
from .dists import MaskedBernoulli, MaskedCategorical
from .buffers import HighLevelBuffer, LowLevelBuffer


class PPO_Hier:
    """
    Implementa entrenamiento PPO jerárquico conjunto HIGH+LOW sobre CLSPHierEnv.

    Esta clase coordina:
      - La construcción de las políticas de alto (HIGH) y bajo nivel (LOW).
      - La recolección de trayectorias jerárquicas:
            HIGH decide qué productos considerar,
            LOW decide cantidades factibles respetando máscaras y capacidad.
      - El cálculo de ventajas y retornos mediante buffers específicos
      - Las actualizaciones PPO separadas para HIGH y LOW con clipping, entropía
        y parada temprana por KL.
      - El registro y guardado de métricas:
            curvas de coste/recompensa, mejores modelos y checkpoints periódicos.
      - La evaluación reproducible en entornos clonados (método `test`).

    Argumentos
    ----------
    :param env: Entorno jerárquico CLSPHierEnv ya configurado.
    :type env: CLSPHierEnv
    :param HYP: Diccionario de hiperparámetros. Debe contener, al menos:
                - "lr_high": learning rate del actor-crítico HIGH.
                - "lr_low":  learning rate del actor-crítico LOW.
                - "gamma":   factor de descuento.
                - "lam":     parámetro λ de GAE.
                - "steps_per_update": nº de pasos HIGH por actualización PPO.
                - "train_iters": nº de iteraciones de optimización por update.
                - "batch_size": tamaño de minibatch PPO.
                - "clip_ratio": radio de clipping de PPO.
                - "entropy_coef": coeficiente de entropía.
                - "kl_target": umbral de KL para parada temprana.
                - "updates": nº total de actualizaciones conjuntas.
                - "print_every": frecuencia (en updates) de logging por consola.
                - "out_dir": directorio de salida para modelos, curvas y CSVs.
    :type HYP: dict
    :param device: Dispositivo donde se ejecutarán redes y tensores ("cpu" o "cuda").
    :type device: str
    :param seed: Semilla opcional para reproducibilidad total (entorno, PyTorch, etc.).
    :type seed: int or None
    """

    def __init__(self, env, HYP, device="cpu", seed=None):
        self.env = env
        self.HYP = HYP
        self.device = device
        self.seed = seed

        # Semilla (opcional) para reproducibilidad
        if seed is not None:
            set_determinism(seed)
            try:
                self.env.action_space.seed(seed)
                self.env.observation_space.seed(seed)
            except Exception:
                pass

        # Dimensiones derivadas del entorno
        self.K = self.env.K
        self.high_obs_dim = self.env.observation_space.shape[0]  # 2K
        self.low_obs_dim = self.env.low_obs_dim                  # 3K + 3
        self.Amax = self.env.CAP + 1                             # acciones {0..CAP}

        # Políticas HIGH y LOW
        self.high = HighPolicy(self.high_obs_dim, self.K).to(self.device)
        self.low = LowPolicy(self.low_obs_dim, self.Amax).to(self.device)

        # Optimizadores
        self.opt_high = Adam(self.high.parameters(), lr=HYP["lr_high"], eps=1e-5)
        self.opt_low = Adam(self.low.parameters(), lr=HYP["lr_low"], eps=1e-5)

        # Buffers de experiencia
        self.buf_high = HighLevelBuffer(
            obs_dim=self.high_obs_dim,
            act_dim=self.K,
            size=HYP["steps_per_update"],
            gamma=HYP["gamma"],
            lam=HYP["lam"],
            device=self.device,
            normalize_rewards=True,
            normalize_advantages=True,
            reward_norm_momentum=0.99,
        )

        self.buf_low = LowLevelBuffer(
            obs_dim=self.low_obs_dim,
            device=self.device,
            gamma=HYP["gamma"],
            lam=HYP["lam"],
            normalize_rewards=True,
            normalize_advantages=True,
            reward_norm_momentum=0.99,
        )

        self.use_wandb = HYP.get("use_wandb", False)

        # Logging básico de entrenamiento
        self.curve_cost = []
        self.curve_real_reward = []

        # Métricas de validación (nuevo criterio de "best model")
        self.best_val_cost = None        # mejor coste de validación (menor = mejor)
        self.best_val_step = None        # update en el que se logró ese mejor modelo
        self.val_cost_curve = []         # evolución del coste de validación
        self.val_steps = []              # updates en los que se evaluó

        os.makedirs(HYP["out_dir"], exist_ok=True)

        # Estado inicial del entorno
        self.obs, _ = self.env.reset(seed=self.seed)


    
    # --------- PPO updates (HIGH / LOW) ----------
    def _ppo_update_high(self, data):
        """
        Actualiza la red HIGH con un paso PPO sobre el batch dado.

        Utiliza:
          - Política enmascarada (MaskedBernoulli) para acciones MultiBinary.
          - Clipping en la razón de probas.
          - Término de entropía para fomentar exploración.
          - Pérdida cuadrática para el crítico.
          - Parada temprana si la KL media supera `H["kl_target"]`.

        :param data: Diccionario con tensores listos para entrenamiento PPO:
                     'obs', 'act', 'adv', 'ret', 'logp', 'mask'.
        :type data: dict

        :return: Último valor medio de KL divergencia estimado durante la actualización.
        :rtype: float
        """
        H = self.HYP
        self.high.train()

        N = data["obs"].shape[0]
        if N == 0:
            return 0.0, 0.0, 0.0

        idx = torch.randperm(N, device=self.device)
        last_kl = 0.0

        pi_losses_all = []
        v_losses_all = []

        for _ in range(H["train_iters"]):
            kls = []

            for j in range(0, N, H["batch_size"]):
                b = idx[j:j + H["batch_size"]]
                obs, act, adv, ret, logp_old, mask = (
                    data[k][b] for k in ["obs", "act", "adv", "ret", "logp", "mask"]
                )

                # Forward actor-crítico HIGH
                logits, v = self.high(obs)

                # Distribución enmascarada
                mask = mask.to(device=logits.device, dtype=logits.dtype)
                dist = MaskedBernoulli(logits, mask)
                logp = dist.log_prob(act)
                probs = dist.probs

                # PPO: razón y pérdida de política con clipping
                ratio = torch.exp(logp - logp_old)
                clip_adv = torch.clamp(ratio, 1 - H["clip_ratio"], 1 + H["clip_ratio"]) * adv
                pi_loss = -torch.min(ratio * adv, clip_adv).mean()

                # Entropía (MultiBinary independiente)
                ent = -(probs * torch.log(probs + 1e-8)
                        + (1 - probs) * torch.log(1 - probs + 1e-8)).sum(dim=-1).mean()

                # Pérdida del crítico
                v_loss = F.mse_loss(v, ret)

                # Pérdida total
                loss = pi_loss + 0.5 * v_loss - H["entropy_coef"] * ent

                # Paso de optimización
                self.opt_high.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.high.parameters(), 10.0)
                self.opt_high.step()

                # Acumular pérdidas para logging
                pi_losses_all.append(float(pi_loss.item()))
                v_losses_all.append(float(v_loss.item()))

                # KL aproximada
                with torch.no_grad():
                    kl = (logp_old - logp).mean().clamp_min(0.0)
                    kls.append(float(kl))

            last_kl = float(np.mean(kls)) if kls else 0.0

            if last_kl > H["kl_target"]:
                break

        mean_pi_loss = float(np.mean(pi_losses_all)) if pi_losses_all else 0.0
        mean_v_loss = float(np.mean(v_losses_all)) if v_losses_all else 0.0

        return last_kl, mean_pi_loss, mean_v_loss
        

    def _ppo_update_low(self, data):
        """
        Actualiza la red LOW con un paso PPO sobre el batch dado.

        Utiliza:
          - Política categórica enmascarada (MaskedCategorical).
          - Clipping en la razón de probas.
          - Término de entropía categórica.
          - Pérdida cuadrática para el crítico.
          - Parada temprana si la KL media supera `H["kl_target"]`.

        :param data: Diccionario con tensores listos para entrenamiento PPO:
                     'obs', 'act', 'adv', 'ret', 'logp', 'mask'.
        :type data: dict

        :return: Último valor medio de KL divergencia estimado durante la actualización.
        :rtype: float
        """
        H = self.HYP
        self.low.train()

        N = data["obs"].shape[0]
        if N == 0:
            return 0.0, 0.0, 0.0

        idx = torch.randperm(N, device=self.device)
        last_kl = 0.0

        pi_losses_all = []
        v_losses_all = []

        for _ in range(H["train_iters"]):
            kls = []

            for j in range(0, N, H["batch_size"]):
                b = idx[j:j + H["batch_size"]]
                obs, act, adv, ret, logp_old, mask = (
                    data[k][b] for k in ["obs", "act", "adv", "ret", "logp", "mask"]
                )

                # Forward actor-crítico LOW
                logits, v = self.low(obs)

                # Distribución categórica enmascarada
                mask = mask.to(device=logits.device, dtype=logits.dtype)
                dist = MaskedCategorical(logits, mask)
                logp = dist.log_prob(act)
                probs = dist.probs

                # PPO: razón y pérdida de política con clipping
                ratio = torch.exp(logp - logp_old)
                clip_adv = torch.clamp(ratio, 1 - H["clip_ratio"], 1 + H["clip_ratio"]) * adv
                pi_loss = -torch.min(ratio * adv, clip_adv).mean()

                # Entropía categórica
                ent = -(probs * torch.log(probs + 1e-8)).sum(dim=-1).mean()

                # Pérdida del crítico
                v_loss = F.mse_loss(v, ret)

                # Pérdida total
                loss = pi_loss + 0.5 * v_loss - H["entropy_coef"] * ent

                # Paso de optimización
                self.opt_low.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.low.parameters(), 10.0)
                self.opt_low.step()

                # Acumular pérdidas para logging
                pi_losses_all.append(float(pi_loss.item()))
                v_losses_all.append(float(v_loss.item()))

                # KL aproximada
                with torch.no_grad():
                    kl = (logp_old - logp).mean().clamp_min(0.0)
                    kls.append(float(kl))

            last_kl = float(np.mean(kls)) if kls else 0.0

            if last_kl > H["kl_target"]:
                break

        mean_pi_loss = float(np.mean(pi_losses_all)) if pi_losses_all else 0.0
        mean_v_loss = float(np.mean(v_losses_all)) if v_losses_all else 0.0

        return last_kl, mean_pi_loss, mean_v_loss


    
    # --------- bucle de entrenamiento ----------
    def train(self):
        """
        Ejecuta el **bucle principal de entrenamiento** conjunto de las políticas HIGH y LOW
        bajo el esquema **PPO jerárquico**.

        Este método coordina la interacción entre el agente y el entorno, la recolección de datos,
        el cálculo de ventajas, las actualizaciones PPO y el registro de métricas.

        Flujo general:
            1. **Recolección de experiencia jerárquica**:
               - HIGH (nivel superior) selecciona los productos a producir mediante una política
                 Bernoulli enmascarada (`MaskedBernoulli`).
               - LOW (nivel inferior) decide las cantidades o lotes válidos para cada producto activo
                 usando una política categórica enmascarada (`MaskedCategorical`).
               - LOW recibe la **misma recompensa global del periodo** que HIGH (coste total negado).
            2. **Cierre de trayectorias**:
               - Calcula ventajas y retornos (GAE).
               - Normaliza recompensas y ventajas si está activado.
            3. **Actualización PPO**:
               - Se entrena primero HIGH, luego LOW.
               - Cada actualización usa clipping, entropía y parada por divergencia KL.
            4. **Logging y guardado de progreso**:
               - Registra coste medio y recompensa real.
               - Guarda checkpoints y mejores modelos.
               - Genera gráficas y CSVs al finalizar el entrenamiento.

        Returns:
            None. (Guarda los modelos entrenados, curvas y métricas en disco).
        """
        H = self.HYP
        print_every = H["print_every"]
        out_dir = H["out_dir"]
        episode_id = 0
        obs = self.obs  # estado inicial ya reseteado

        # Frecuencia de evaluación: 1% de los updates totales
        total_updates = H["updates"]
        eval_every = max(1, total_updates // 100)

        # Semilla base fija para las evaluaciones (permite comparar en las mismas condiciones)
        eval_seed_base = H.get("eval_seed_base", 10000)

        for upd in trange(total_updates, desc="Train HIGH+LOW joint PPO"):
            total_costs = []

            # =====================================================
            # RECOLECCIÓN DE DATOS
            # =====================================================
            while self.buf_high.ptr < self.buf_high.max_size or not self.buf_low.is_batch_ready(H["steps_per_update"]):
                obs_t = torch.as_tensor(obs[None, :], dtype=torch.float32, device=self.device)

                # HIGH: máscara + acción
                high_mask_np = self.env.eligibility_mask_high().astype(np.float32)[None, :]
                high_mask_t  = torch.as_tensor(high_mask_np, device=self.device, dtype=torch.float32)

                with torch.no_grad():
                    logits_H, vH = self.high(obs_t)
                    dist_H = MaskedBernoulli(logits_H, high_mask_t)
                    aH_t   = dist_H.sample()
                    logpH  = dist_H.log_prob(aH_t)
                    probs_H = dist_H.probs.squeeze(0).cpu().numpy().astype(np.float32)

                aH_env = (aH_t.squeeze(0).cpu().numpy().astype(np.int8) & high_mask_np.squeeze(0).astype(np.int8))

                # Orden LOW (definición del subnivel de decisión)
                chosen = self.env.plan_low_level(aH_env, probs_H)

                # Periodo LOW
                self.buf_low.start_period()
                low_actions_idx = []
                
                CAP_rem = int(self.env.CAP)
                I_view = self.env.I.copy()  # inventario virtual dentro del periodo
                
                for pos, i in enumerate(chosen):
                    # Estado LOW + acciones factibles dado CAP_rem actual
                    low_obs_np, qs, feas, need_setup = self.env._low_state_mask_for(
                        i,
                        CAP_rem,
                        a_high_scores=probs_H,
                        pos=pos,
                        chosen=chosen,
                        I_view=I_view,
                        a_high_vec=aH_env,  
                    )

                
                    # Fallback robusto por si algo raro devuelve vacío
                    if qs.size == 0 or not np.any(feas):
                        qs = np.array([0], dtype=np.int32)
                        feas = np.array([True], dtype=bool)
                
                    L = qs.size
                
                    # Máscara categórica sobre {0..Amax-1}
                    mask_local = np.zeros((self.Amax,), dtype=np.float32)
                    mask_local[:L] = feas.astype(np.float32)
                
                    low_obs_t = torch.as_tensor(low_obs_np[None, :], dtype=torch.float32, device=self.device)
                    mask_t = torch.as_tensor(mask_local[None, :], dtype=torch.float32, device=self.device)
                
                    with torch.no_grad():
                        logits_L, vL = self.low(low_obs_t)
                        dist_L = MaskedCategorical(logits_L, mask_t)
                        a_idx_t = dist_L.sample()
                        logpL_t = dist_L.log_prob(a_idx_t)
                
                    a_idx = int(a_idx_t.item())
                
                    # Seguridad: si índice fuera de rango o no factible, ajustamos
                    if a_idx < 0 or a_idx >= L or not feas[a_idx]:
                        feas_idxs = np.nonzero(feas)[0]
                        a_idx = int(feas_idxs[-1]) if feas_idxs.size > 0 else 0
                
                    q_i = int(qs[a_idx])
                
                    # Guardar subpaso LOW en el buffer
                    self.buf_low.store_substep(low_obs_np, a_idx, float(vL.item()), float(logpL_t.item()), mask=mask_local)
                    low_actions_idx.append(a_idx)
                
                    if q_i > 0:
                        if need_setup:
                            CAP_rem -= int(self.env.st[i])
                        CAP_rem -= q_i
                
                        CAP_rem = max(0, CAP_rem)
                        I_view[i] = I_view[i] + q_i * self.env.bs[i]

                # Paso del entorno y recompensa global
                next_obs, _, term, trunc, info = self.env.step(
                    aH_env, low_actions=low_actions_idx,
                    a_high_scores=probs_H, chosen_order=chosen
                )
                cost_t = float(info["cost"])
                reward_t = -cost_t * self.env.reward_scale
                total_costs.append(cost_t)

                # Guardado en buffers
                self.buf_high.store(
                    obs, aH_env, reward_t,
                    float(vH.item()), float(logpH.item()),
                    mask=high_mask_np.squeeze(0)
                )
                self.buf_low.end_period_assign_global_reward(reward_t)

                # Reinicio o avance
                if term or trunc:
                    self.buf_high.finish_path(last_val=0.0)
                    self.buf_low.finish_episode_and_collect()
                    episode_id += 1
                    obs, _ = self.env.reset(seed=self.seed + episode_id)
                else:
                    obs = next_obs

                # Condición de llenado del buffer HIGH
                if self.buf_high.ptr >= self.buf_high.max_size:
                    break

            # Cierre de trayectorias pendientes
            if self.buf_high.path_start_idx < self.buf_high.ptr:
                self.buf_high.finish_path(last_val=0.0)
            self.buf_low.finish_episode_and_collect()

            # Extracción de batches PPO
            dataH = self.buf_high.get()
            dataL = self.buf_low.get()

            # =====================================================
            # ACTUALIZACIÓN PPO + MÉTRICAS DE PÉRDIDA
            # =====================================================
            kl_h, pi_loss_h, v_loss_h = self._ppo_update_high(dataH)
            kl_l, pi_loss_l, v_loss_l = self._ppo_update_low(dataL)

            # Cálculo de métricas de entrenamiento
            mean_cost = float(np.mean(total_costs)) if total_costs else 0.0
            self.curve_cost.append(mean_cost)
            mean_real_reward = -mean_cost
            self.curve_real_reward.append(mean_real_reward)

            # Logging en consola (ya sin tail_mean_cost)
            if (upd + 1) % print_every == 0:
                print(
                    f"[Joint {upd+1}] mean RAW cost: {mean_cost:.3f} | "
                    f"mean REAL reward: {mean_real_reward:.3f} | "
                    f"KL_high={kl_h:.4f} | KL_low={kl_l:.4f}"
                )

            # Logging en WandB (incluyendo las 4 pérdidas)
            if self.use_wandb:
                import wandb

                log_dict = {
                    "update": upd + 1,
                    "mean_raw_cost": mean_cost,
                    "mean_real_reward": mean_real_reward,
                    "KL_high": kl_h,
                    "KL_low": kl_l,
                    "loss_actor_high": pi_loss_h,
                    "loss_critic_high": v_loss_h,
                    "loss_actor_low": pi_loss_l,
                    "loss_critic_low": v_loss_l,
                }

                wandb.log(log_dict, step=upd + 1)

            # =====================================================
            # VALIDACIÓN PERIÓDICA (cada ~1% de los updates)
            # =====================================================
            do_eval = ((upd + 1) % eval_every == 0) or (upd == total_updates - 1)
            if do_eval:
                eval_stats = self.test(
                    n_runs=5,
                    horizon=1000,
                    warmup=10,
                    greedy=True,
                    seed_base=eval_seed_base,
                    ckpt_high=None,
                    ckpt_low=None,
                    env_overrides={"horizon": 1000},
                )
                val_cost = float(eval_stats["mean_of_means"])

                # Guardar en curvas internas
                self.val_cost_curve.append(val_cost)
                self.val_steps.append(upd + 1)

                # Log a WandB como "coste de validación"
                if self.use_wandb:
                    import wandb
                    wandb.log(
                        {
                            "val_mean_cost": val_cost,
                        },
                        step=upd + 1,
                    )

                # Actualizar mejor modelo según validación
                if (self.best_val_cost is None) or (val_cost < self.best_val_cost - 1e-9):
                    self.best_val_cost = val_cost
                    self.best_val_step = upd + 1
                    torch.save(self.high.state_dict(), os.path.join(out_dir, "high_joint_best.pt"))
                    torch.save(self.low.state_dict(),  os.path.join(out_dir, "low_joint_best.pt"))
                    print(f"[VALID] Nuevo mejor modelo: val_mean_cost={self.best_val_cost:.3f} @ update {self.best_val_step}")

        # =========================================================
        # Guardado final y métricas (solo best + final, sin checkpoints periódicos)
        # =========================================================
        print("Entrenamiento conjunto finalizado.")
        torch.save(self.high.state_dict(), os.path.join(out_dir, "high_joint_final.pt"))
        torch.save(self.low.state_dict(),  os.path.join(out_dir, "low_joint_final.pt"))
        print("Modelos guardados: high_joint_final.pt / low_joint_final.pt")

        if self.best_val_cost is not None:
            print(
                f"Mejor coste de validación: {self.best_val_cost:.3f} "
                f"@ update {self.best_val_step} "
                f"(high_joint_best.pt / low_joint_best.pt)"
            )

        # Generación de gráficas y CSVs
        try:
            plt.figure()
            plt.plot(self.curve_cost, label="Mean RAW cost per update")
            plt.xlabel("Update"); plt.ylabel("Mean raw cost"); plt.title("Joint – Cost")
            plt.grid(True); plt.legend(); plt.tight_layout()
            plt.savefig(os.path.join(out_dir, "curve_joint_cost.png"), dpi=150)

            plt.figure()
            plt.plot(self.curve_real_reward, label="Mean REAL reward per update")
            plt.xlabel("Update"); plt.ylabel("Mean real reward"); plt.title("Joint – Real Reward")
            plt.grid(True); plt.legend(); plt.tight_layout()
            plt.savefig(os.path.join(out_dir, "curve_joint_real_reward.png"), dpi=150)

            np.savetxt(os.path.join(out_dir, "curve_joint_cost.csv"), np.array(self.curve_cost), delimiter=",")
            np.savetxt(os.path.join(out_dir, "curve_joint_real_reward.csv"), np.array(self.curve_real_reward), delimiter=",")

            # Curvas de validación (opcional, como en el ejemplo)
            if len(self.val_cost_curve) > 0:
                np.savetxt(os.path.join(out_dir, "curve_val_cost.csv"), np.array(self.val_cost_curve), delimiter=",")
                np.savetxt(os.path.join(out_dir, "curve_val_steps.csv"), np.array(self.val_steps, dtype=np.int32), delimiter=",")

            print("Guardadas gráficas/CSVs: curve_joint_cost.png, curve_joint_real_reward.png (+ curvas de validación si existen).")
        except Exception as e:
            print(f"(aviso) no se pudieron generar/guardar las gráficas o CSVs: {e}")


    # =========================
    # ======= EVALUACIÓN ======
    # =========================
    def _build_eval_env(self, env_overrides, seed):
        """
        Crea un entorno de evaluación nuevo a partir del entorno de entrenamiento,
        clonando su configuración base y aplicando cambios opcionales.

        Uso:
          - Permite evaluar la política entrenada sin tocar `self.env`.
          - Útil para probar distintos horizontes, escalas de recompensa o toggles.

        Parámetros:
            env_overrides : dict o None
                Diccionario opcional con parámetros a sobrescribir. Ejemplos:
                  - "horizon"               (int)
                  - "reward_scale"          (float)
                  - "reserve_future_min"    (bool)
                  - "force_min_batch"       (bool)
                  - "enable_Ilim"           (bool)
                  - "enforce_eoq_qmax"      (bool)
                  - "auto_kmax_from_paper"  (bool)
                  - "enable_ip_eligibility" (bool)
                  - "order_mode"            (str)
            seed : int o None
                Semilla para hacer reproducible la evaluación
                (se aplica al nuevo entorno y a sus espacios).

        Devuelve:
            env_eval : CLSPHierEnv
                Entorno clonado y configurado para evaluación.
            obs_init : np.ndarray
                Observación inicial tras el reset del entorno de evaluación.
        """
        src = self.env
        ov = env_overrides or {}

        # Copia de parámetros estructurales del entorno original
        K   = src.K
        mu  = np.array(src.mu, copy=True)
        bs  = np.array(src.bs, copy=True)
        h   = np.array(src.h,  copy=True)
        b   = np.array(src.b,  copy=True)
        k   = np.array(src.k,  copy=True)
        st  = np.array(src.st, copy=True)
        CAP = src.CAP

        # Parámetros heredados con posibilidad de override
        kwargs = dict(
            reward_scale = ov.get("reward_scale", getattr(src, "reward_scale", 1e-2)),
            horizon      = ov.get("horizon",      getattr(src, "horizon", 10_000) or 10_000),
            cov          = np.array(getattr(src, "cov", np.ones(K, np.float32)), copy=True),
            reserve_future_min = ov.get("reserve_future_min", getattr(src, "reserve_future_min", True)),
            force_min_batch    = ov.get("force_min_batch",    getattr(src, "force_min_batch_default", True)),
            enable_Ilim        = ov.get("enable_Ilim",        getattr(src, "enable_Ilim", True)),
            enforce_eoq_qmax   = ov.get("enforce_eoq_qmax",   getattr(src, "enforce_eoq_qmax", True)),
            auto_kmax_from_paper = ov.get("auto_kmax_from_paper", getattr(src, "auto_kmax_from_paper", True)),
            enable_ip_eligibility = ov.get("enable_ip_eligibility", getattr(src, "enable_ip_eligibility", True)),
            order_mode = ov.get("order_mode", getattr(src, "order_mode", "paper")),
            seed = seed,
        )

        # Nuevo entorno de evaluación (independiente del de entrenamiento)
        env_eval = CLSPHierEnv(K, mu, bs, h, b, k, st, CAP, **kwargs)

        # Si se da semilla, se siembran también los espacios
        if seed is not None:
            env_eval.action_space.seed(seed)
            env_eval.observation_space.seed(seed)

        obs_init, _ = env_eval.reset(seed=seed)
        return env_eval, obs_init


    
    @staticmethod
    @torch.no_grad()
    def _act_high(env, high_model, obs_np, device, greedy=True):
        """
        Selecciona una acción de ALTO nivel (HIGH) dada una observación y una política entrenada.

        Construye la distribución Bernoulli enmascarada sobre K productos usando:
          - logits producidos por `high_model`
          - máscara de elegibilidad `env.eligibility_mask_high()`

        Si `greedy=True`, aplica una regla determinista basada en probabilidades:
          - Activa productos con prob ≥ 0.5.
          - Si nadie cumple:
              * intenta activar el producto con setup actual (`env.omega`),
                si es elegible;
              * si no, activa el elegible con mayor probabilidad.
          - Si existe `env.Kmax` y se seleccionan más de Kmax productos,
            se queda solo con los de mayor probabilidad.
        Si `greedy=False`, muestrea estocásticamente de la distribución enmascarada.

        Parámetros:
            env : CLSPHierEnv
                Entorno jerárquico con la máscara de elegibilidad y estado actual.
            high_model : nn.Module
                Red actor-crítico del nivel HIGH. Debe recibir `obs_t` y devolver `(logits, value)`.
            obs_np : np.ndarray
                Observación actual del entorno (vector 1D).
            device : str
                Dispositivo donde se ejecuta el modelo ("cpu" o "cuda").
            greedy : bool, opcional (por defecto True)
                Si True, usa política determinista con reglas adicionales.
                Si False, muestrea acciones de la política estocástica.

        Devuelve:
            a_high : np.ndarray[int]
                Vector binario {0,1}^K con la acción HIGH aplicada (respetando la máscara).
            logp : float
                Log-probabilidad de `a_high` bajo la distribución enmascarada.
            value : float
                Valor V(s) estimado por el crítico HIGH.
            mask : np.ndarray[float32]
                Máscara de elegibilidad usada (tamaño K).
            probs : np.ndarray[float32]
                Probabilidades Bernoulli por producto antes de aplicar la regla greedy.
        """
        obs_t = torch.as_tensor(obs_np[None, :], dtype=torch.float32, device=device)
        logits, v = high_model(obs_t)

        # Máscara de elegibilidad HIGH
        mask_np = env.eligibility_mask_high().astype(np.float32)[None, :]
        mask_t = torch.as_tensor(mask_np, device=device, dtype=logits.dtype)

        # Distribución Bernoulli enmascarada
        dist = MaskedBernoulli(logits, mask_t)
        probs = dist.probs[0].cpu().numpy().astype(np.float32)

        if greedy:
            # Selección determinista por umbral
            a = (probs >= 0.5).astype(np.int64)

            # Fallback: si nadie seleccionado, prioriza setup actual o mayor prob elegible
            if a.sum() == 0:
                omega_idx = int(np.argmax(env.omega))
                if mask_np[0, omega_idx] > 0:
                    a[omega_idx] = 1
                else:
                    elig = np.where(mask_np[0] > 0)[0]
                    if elig.size > 0:
                        a[elig[np.argmax(probs[elig])]] = 1
        else:
            # Muestreo estocástico
            a = dist.sample()[0].cpu().numpy().astype(np.int64)

        # Asegura que respeta la máscara de elegibilidad
        a = (a & mask_np.squeeze(0).astype(np.int64))

        # Log-probabilidad de la acción elegida
        logp = dist.log_prob(
            torch.as_tensor(a[None, :], dtype=torch.float32, device=device)
        ).item()

        return a.astype(np.int64), float(logp), float(v.item()), mask_np.squeeze(0), probs


    
    @staticmethod
    @torch.no_grad()
    def _act_low_seq(env, low_model, a_high_env, a_high_scores=None, greedy=True, device="cpu", force_min_batch=None):
        """
        Genera la **secuencia de acciones LOW** (cantidades en batches) para los productos
        seleccionados por el nivel HIGH en un único periodo.

        Recorre los productos elegidos (según `plan_low_level`) y, para cada uno:
          - Construye el estado LOW con `_low_state_mask_for(...)`.
          - Genera la máscara local de acciones factibles `{0..Amax-1}`.
          - Aplica la política categórica enmascarada (`MaskedCategorical`):
              * Si `greedy=True`, elige el índice con mayor logit factible.
              * Si `greedy=False`, muestrea de la distribución.
          - Actualiza la capacidad simulada CAP_rem_sim respetando setups y batches.
        No modifica el entorno real: solo devuelve el orden y los índices elegidos.

        Parámetros:
            env : CLSPHierEnv
                Entorno jerárquico con la lógica LOW y los parámetros de capacidad.
            low_model : nn.Module
                Política del nivel bajo. Recibe `obs_t` y devuelve `(logits, value)`.
            a_high_env : np.ndarray[int]
                Acción binaria {0,1}^K aplicada por HIGH en el entorno.
            a_high_scores : np.ndarray[float] o None, opcional
                Scores/probabilidades asociados a HIGH para cada producto. Si es None,
                se usa `a_high_env` como proxy (0/1).
            greedy : bool, opcional (por defecto True)
                Si True, toma la acción factible con mayor logit.
                Si False, muestrea de la MaskedCategorical.
            device : str, opcional
                Dispositivo para ejecutar `low_model` ("cpu" o "cuda").
            force_min_batch : bool o None, opcional
                Si no es None, fuerza el comportamiento de mínimo batch en
                `_low_state_mask_for`. Si es None, usa `env.force_min_batch_default`.

        Devuelve:
            chosen : np.ndarray[int]
                Índices de productos visitados por LOW en el orden decidido.
            low_actions_idx : list[int]
                Índices seleccionados dentro de los `qs` factibles para cada producto de `chosen`.
                (La cantidad real producida es `qs[low_actions_idx[pos]]` para cada posición `pos`).
        """
        fmb = force_min_batch if force_min_batch is not None else getattr(env, "force_min_batch_default", False)

        # Orden de visita LOW según HIGH y/o reglas del entorno
        chosen = env.plan_low_level(a_high_env, a_high_scores=a_high_scores)
        Amax = env.CAP + 1
        low_actions_idx = []
        CAP_rem_sim = env.CAP

        # Scores usados para features LOW
        scores_vec = a_high_scores if a_high_scores is not None else a_high_env.astype(np.float32)

        for pos, i in enumerate(chosen):
            low_obs_np, qs, feas, need_setup = env._low_state_mask_for(
                i,
                CAP_rem_sim,
                a_high_scores=scores_vec,
                pos=pos,
                chosen=chosen,
                force_min_batch=fmb,
                a_high_vec=a_high_env,  
            )


            # Fallback robusto: si no hay acciones factibles, permitir solo "no producir"
            if len(qs) == 0 or not np.any(feas):
                qs = np.array([0], dtype=np.int32)
                feas = np.array([True], dtype=bool)

            L = len(qs)
            mask_local = np.zeros((1, Amax), dtype=np.float32)
            mask_local[0, :L] = feas.astype(np.float32)

            obs_t = torch.as_tensor(low_obs_np[None, :], dtype=torch.float32, device=device)
            logits, _ = low_model(obs_t)
            mask_t = torch.as_tensor(mask_local, device=device, dtype=logits.dtype)
            dist = MaskedCategorical(logits, mask_t)

            # Selección greedy o estocástica entre acciones válidas
            if greedy:
                masked_logits = dist.logits[0, :L].cpu().numpy()
                a_idx = int(np.argmax(masked_logits))
            else:
                a_idx = int(dist.sample().item())

            # Asegura índice dentro de rango
            a_idx = max(0, min(a_idx, L - 1))
            q_i = int(qs[a_idx])
            low_actions_idx.append(a_idx)

            # Actualiza capacidad simulada (solo para construcción consistente de la secuencia)
            if q_i > 0 and need_setup:
                CAP_rem_sim -= int(env.st[i])
            CAP_rem_sim -= q_i
            CAP_rem_sim = max(0, CAP_rem_sim)

        return chosen, low_actions_idx



    
    def test(self, n_runs=10, horizon=10_000, warmup=1_000, greedy=True, seed_base=12345, 
             ckpt_high=None, ckpt_low=None, env_overrides=None):
        """
        Evalúa la pareja HIGH+LOW en términos de **coste medio por periodo** sobre varias ejecuciones.

        Comportamiento:
          - Puede usar los pesos actuales o cargar checkpoints proporcionados.
          - En cada ejecución crea un entorno de evaluación nuevo mediante `_build_eval_env`,
            clonando el entorno de entrenamiento y aplicando `env_overrides` si se indican.
          - Ejecuta la política (greedy o estocástica) durante `horizon` pasos, descartando
            un prefijo de calentamiento (`warmup`) antes de promediar los costes.
          - Devuelve estadísticas agregadas sobre los costes medios.

        Parámetros:
            n_runs : int
                Número de ejecuciones independientes de evaluación.
            horizon : int
                Longitud máxima (en pasos) de cada episodio de evaluación.
            warmup : int
                Número de pasos iniciales a ignorar en el cálculo del coste medio
                (permite descartar la fase transitoria).
            greedy : bool
                Si True, usa decisiones deterministas (greedy) en HIGH y LOW.
                Si False, usa muestreo estocástico.
            seed_base : int o None
                Semilla base para generar las semillas de cada run (seed_base + r).
                Si es None, no se fuerza determinismo entre runs.
            ckpt_high : str o None
                Ruta opcional a un checkpoint de la política HIGH a cargar antes de evaluar.
            ckpt_low : str o None
                Ruta opcional a un checkpoint de la política LOW a cargar antes de evaluar.
            env_overrides : dict o None
                Diccionario opcional para sobrescribir parámetros del entorno de evaluación
                (por ejemplo: "horizon", "reward_scale", "force_min_batch", etc.).
                Tiene prioridad sobre los argumentos por defecto del entorno original.

        Devuelve:
            dict con:
              - "n_runs": nº de ejecuciones realizadas.
              - "horizon": horizonte usado en evaluación.
              - "warmup": prefijo ignorado en el cálculo.
              - "greedy": modo de decisión empleado.
              - "mean_costs_per_run": lista de costes medios por ejecución.
              - "mean_of_means": media de esos costes medios.
              - "std_of_means": desviación estándar entre ejecuciones.
        """
        # Carga opcional de checkpoints
        if ckpt_high and os.path.isfile(ckpt_high):
            self.high.load_state_dict(torch.load(ckpt_high, map_location=self.device))
        if ckpt_low and os.path.isfile(ckpt_low):
            self.low.load_state_dict(torch.load(ckpt_low, map_location=self.device))
        self.high.eval(); self.low.eval()

        # Priorizar horizon pasado en env_overrides sobre el argumento
        env_overrides = dict(env_overrides or {})
        env_overrides.setdefault("horizon", horizon)

        mean_costs = []

        for r in range(n_runs):
            # Semilla por ejecución (si se especifica base)
            run_seed = (seed_base + r) if (seed_base is not None) else None
            if run_seed is not None:
                random.seed(run_seed)
                np.random.seed(run_seed)
                torch.manual_seed(run_seed)
                if torch.cuda.is_available():
                    torch.cuda.manual_seed_all(run_seed)
                torch.backends.cudnn.benchmark = False
                torch.backends.cudnn.deterministic = True
                torch.use_deterministic_algorithms(True)

            # Entorno de evaluación y estado inicial
            env_eval, obs = self._build_eval_env(env_overrides, seed=run_seed)

            costs = []
            for t in range(int(env_overrides["horizon"])):
                # Acción HIGH (determinista o estocástica) + secuencia LOW
                a_high_env, _, _, _, probs_H = self._act_high(env_eval, self.high, obs, device=self.device, greedy=greedy)
                chosen, low_actions_idx = self._act_low_seq(
                    env_eval,
                    self.low,
                    a_high_env,
                    a_high_scores=probs_H,
                    greedy=greedy,
                    device=self.device,
                    force_min_batch=env_overrides.get("force_min_batch", None),
                )

                # Paso del entorno con ambas decisiones
                obs_next, _, terminated, truncated, info = env_eval.step(
                    a_high_env,
                    low_actions=low_actions_idx,
                    a_high_scores=probs_H,
                    chosen_order=chosen,
                )

                # Acumula coste solo tras el warmup
                if t >= int(warmup):
                    costs.append(float(info["cost"]))

                if terminated or truncated:
                    break

                obs = obs_next

            # Coste medio de esta ejecución
            mc = float(np.mean(costs)) if costs else float("nan")
            mean_costs.append(mc)

        # Resumen global sobre las ejecuciones
        mean_of_means = float(np.mean(mean_costs)) if mean_costs else float("nan")
        std_of_means = float(np.std(mean_costs, ddof=1)) if len(mean_costs) > 1 else 0.0

        return {
            "n_runs": n_runs,
            "horizon": int(env_overrides["horizon"]),
            "warmup": int(warmup),
            "greedy": bool(greedy),
            "mean_costs_per_run": mean_costs,
            "mean_of_means": mean_of_means,
            "std_of_means": std_of_means,
        }

