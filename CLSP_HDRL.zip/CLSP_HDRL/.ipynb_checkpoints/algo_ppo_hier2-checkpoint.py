import os
import random
from tqdm import trange

import numpy as np
import torch
import torch.nn.functional as F
from torch.optim import Adam
import matplotlib.pyplot as plt

from .envs import CLSPHierEnv
from .nets import HighPolicy, LowPolicy
from .dists import MaskedBernoulli, MaskedCategorical
from .buffers import HighLevelBuffer, LowLevelBuffer


class PPO_Hier:
    """
    Joint hierarchical PPO training (HIGH + LOW) for CLSPHierEnv.

    This class coordinates:
      - Building the high-level (HIGH) and low-level (LOW) policies.
      - Collecting hierarchical trajectories:
            HIGH selects which products to consider,
            LOW selects feasible production quantities subject to masks and capacity.
      - Computing advantages and returns via level-specific buffers.
      - Performing separate PPO updates for HIGH and LOW (clipping, entropy bonus,
        and early stopping based on KL).
      - Logging and checkpointing:
            cost/reward curves, best models, and periodic checkpoints.
      - Reproducible evaluation in cloned environments (method `test`).

    Parameters
    ----------
    :param env: A configured hierarchical environment instance.
    :type env: CLSPHierEnv
    :param HYP: Hyperparameter dictionary. It should include, at minimum:
                - "lr_high": learning rate for the HIGH actor-critic.
                - "lr_low":  learning rate for the LOW actor-critic.
                - "gamma":   discount factor.
                - "lam":     GAE(λ) parameter.
                - "steps_per_update": number of HIGH steps per PPO update.
                - "train_iters": number of optimization iterations per update.
                - "batch_size": PPO minibatch size.
                - "clip_ratio": PPO clipping ratio.
                - "entropy_coef": entropy bonus coefficient.
                - "kl_target": KL threshold for early stopping.
                - "updates": total number of joint updates.
                - "print_every": console logging frequency (in updates).
                - "out_dir": output directory for models, curves, and CSVs.
    :type HYP: dict
    :param device: Device where networks and tensors will be placed ("cpu" or "cuda").
    :type device: str
    :param seed: Optional seed for reproducibility (environment, PyTorch, etc.).
    :type seed: int or None
    """

    def __init__(self, env, HYP, device="cpu", seed=None):
        self.env = env
        self.HYP = HYP
        self.device = device
        self.seed = seed

        # Dimensions derived from the environmen
        self.K = self.env.K
        self.high_obs_dim = self.env.observation_space.shape[0]  # 2K
        self.low_obs_dim = self.env.low_obs_dim                  # 4K + 2
        self.Amax = self.env.CAP + 1                             # actions {0..CAP}

        # HIGH and LOW policies
        self.high = HighPolicy(self.high_obs_dim, self.K).to(self.device)
        self.low = LowPolicy(self.low_obs_dim, self.Amax).to(self.device)

        # Optimizers
        # --- LR schedule: start at level 0 ---
        high_levels = HYP.get("lr_high_levels", [HYP["lr_high"]])
        low_levels  = HYP.get("lr_low_levels",  [HYP["lr_low"]])

        self.opt_high = Adam(self.high.parameters(), lr=float(high_levels[0]), eps=1e-5)
        self.opt_low  = Adam(self.low.parameters(),  lr=float(low_levels[0]),  eps=1e-5)


        # Experience buffers
        self.buf_high = HighLevelBuffer(
            obs_dim=self.high_obs_dim,
            act_dim=self.K,
            size=HYP["steps_per_update"],
            gamma=HYP["gamma"],
            lam=HYP["lam"],
            device=self.device,
            normalize_rewards=True,
            normalize_advantages=True,
            reward_norm_momentum=0.99,
        )

        self.buf_low = LowLevelBuffer(
            obs_dim=self.low_obs_dim,
            device=self.device,
            gamma=HYP["gamma"],
            lam=HYP["lam"],
            normalize_rewards=True,
            normalize_advantages=True,
            reward_norm_momentum=0.99,
        )

        self.use_wandb = HYP.get("use_wandb", False)

        # Basic training logging
        self.curve_cost = []
        self.curve_real_reward = []

        # Validation metrics (new "best model" criterion)
        self.best_val_cost = None        # best validation cost (lower is better)
        self.best_val_step = None        # update index where best model was achieved
        self.val_cost_curve = []         # validation cost over time
        self.val_steps = []              # updates at which validation was performed

        os.makedirs(HYP["out_dir"], exist_ok=True)

        # Initial environment state
        self.obs, _ = self.env.reset(seed=self.seed)


    
    # --------- PPO updates (HIGH / LOW) ----------
    def _ppo_update_high(self, data):
        """
        Updates the HIGH network with PPO on the provided batch.

        This update uses:
          - A masked policy (MaskedBernoulli) for MultiBinary actions.
          - Probability ratio clipping (PPO clipping).
          - An entropy term to encourage exploration.
          - A mean-squared-error loss for the critic.
          - Early stopping if the mean KL divergence exceeds `H["kl_target"]`.

        :param data: Dictionary containing PPO-ready tensors:
                     'obs', 'act', 'adv', 'ret', 'logp', 'mask'.
        :type data: dict

        :return: Tuple (last_kl, mean_pi_loss, mean_v_loss), where:
                 - last_kl: last estimated mean KL divergence during the update loop,
                 - mean_pi_loss: mean policy loss across all minibatches processed,
                 - mean_v_loss: mean value-function loss across all minibatches processed.
        :rtype: tuple[float, float, float]
        """
        H = self.HYP
        self.high.train()

        N = data["obs"].shape[0]
        if N == 0:
            return 0.0, 0.0, 0.0

        idx = torch.randperm(N, device=self.device)
        last_kl = 0.0

        pi_losses_all = []
        v_losses_all = []

        for _ in range(H["train_iters"]):
            kls = []

            for j in range(0, N, H["batch_size"]):
                b = idx[j:j + H["batch_size"]]
                obs, act, adv, ret, logp_old, mask = (
                    data[k][b] for k in ["obs", "act", "adv", "ret", "logp", "mask"]
                )

                # HIGH actor-critic forward pass
                logits, v = self.high(obs)

                # Masked distribution
                mask = mask.to(device=logits.device, dtype=logits.dtype)
                dist = MaskedBernoulli(logits, mask)
                logp = dist.log_prob(act)
                probs = dist.probs

                # PPO: ratio and clipped policy loss
                ratio = torch.exp(logp - logp_old)
                clip_adv = torch.clamp(ratio, 1 - H["clip_ratio"], 1 + H["clip_ratio"]) * adv
                pi_loss = -torch.min(ratio * adv, clip_adv).mean()

                # Entropy (independent Bernoulli per component)
                ent = -(probs * torch.log(probs + 1e-8)
                        + (1 - probs) * torch.log(1 - probs + 1e-8)).sum(dim=-1).mean()

                # Critic loss
                v_loss = F.mse_loss(v, ret)

                # Total loss
                loss = pi_loss + 0.5 * v_loss - H["entropy_coef"] * ent

                # Optimization step
                self.opt_high.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.high.parameters(), 10.0)
                self.opt_high.step()

                # Accumulate losses for logging
                pi_losses_all.append(float(pi_loss.item()))
                v_losses_all.append(float(v_loss.item()))

                # Approximate KL
                with torch.no_grad():
                    kl = (logp_old - logp).mean().clamp_min(0.0)
                    kls.append(float(kl))

            last_kl = float(np.mean(kls)) if kls else 0.0

            if last_kl > H["kl_target"]:
                break

        mean_pi_loss = float(np.mean(pi_losses_all)) if pi_losses_all else 0.0
        mean_v_loss = float(np.mean(v_losses_all)) if v_losses_all else 0.0

        return last_kl, mean_pi_loss, mean_v_loss
        

    def _ppo_update_low(self, data):
        """
        Updates the LOW network with PPO on the provided batch.

        This update uses:
          - A masked categorical policy (MaskedCategorical).
          - Probability ratio clipping (PPO clipping).
          - A categorical entropy term to encourage exploration.
          - A mean-squared-error loss for the critic.
          - Early stopping if the mean KL divergence exceeds `H["kl_target"]`.

        :param data: Dictionary containing PPO-ready tensors:
                     'obs', 'act', 'adv', 'ret', 'logp', 'mask'.
        :type data: dict

        :return: Tuple (last_kl, mean_pi_loss, mean_v_loss), where:
                 - last_kl: last estimated mean KL divergence during the update loop,
                 - mean_pi_loss: mean policy loss across all minibatches processed,
                 - mean_v_loss: mean value-function loss across all minibatches processed.
        :rtype: tuple[float, float, float]
        """
        H = self.HYP
        self.low.train()

        N = data["obs"].shape[0]
        if N == 0:
            return 0.0, 0.0, 0.0

        idx = torch.randperm(N, device=self.device)
        last_kl = 0.0

        pi_losses_all = []
        v_losses_all = []

        for _ in range(H["train_iters"]):
            kls = []

            for j in range(0, N, H["batch_size"]):
                b = idx[j:j + H["batch_size"]]
                obs, act, adv, ret, logp_old, mask = (
                    data[k][b] for k in ["obs", "act", "adv", "ret", "logp", "mask"]
                )

                # LOW actor-critic forward pass
                logits, v = self.low(obs)

                # Masked categorical distribution
                mask = mask.to(device=logits.device, dtype=logits.dtype)
                dist = MaskedCategorical(logits, mask)
                logp = dist.log_prob(act)
                probs = dist.probs

                # PPO: ratio and clipped policy loss
                ratio = torch.exp(logp - logp_old)
                clip_adv = torch.clamp(ratio, 1 - H["clip_ratio"], 1 + H["clip_ratio"]) * adv
                pi_loss = -torch.min(ratio * adv, clip_adv).mean()

                # Categorical entropy
                ent = -(probs * torch.log(probs + 1e-8)).sum(dim=-1).mean()

                # Critic loss
                v_loss = F.mse_loss(v, ret)

                # Total loss
                loss = pi_loss + 0.5 * v_loss - H["entropy_coef"] * ent

                # Optimization step
                self.opt_low.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.low.parameters(), 10.0)
                self.opt_low.step()

                # Accumulate losses for logging
                pi_losses_all.append(float(pi_loss.item()))
                v_losses_all.append(float(v_loss.item()))

                # Approximate KL
                with torch.no_grad():
                    kl = (logp_old - logp).mean().clamp_min(0.0)
                    kls.append(float(kl))

            last_kl = float(np.mean(kls)) if kls else 0.0

            if last_kl > H["kl_target"]:
                break

        mean_pi_loss = float(np.mean(pi_losses_all)) if pi_losses_all else 0.0
        mean_v_loss = float(np.mean(v_losses_all)) if v_losses_all else 0.0

        return last_kl, mean_pi_loss, mean_v_loss


    
    # --------- bucle de entrenamiento ----------
    def train(self):
        """
        Runs the **main joint training loop** for the HIGH and LOW policies
        under the **hierarchical PPO** scheme.
    
        This method orchestrates interaction between the agent and the environment,
        data collection, advantage computation, PPO updates, and metric logging.
    
        General flow:
            1. **Hierarchical experience collection**:
               - HIGH (upper level) selects which products to consider/produce using a
                 masked Bernoulli policy (`MaskedBernoulli`).
               - LOW (lower level) selects feasible quantities/lots for each active product
                 using a masked categorical policy (`MaskedCategorical`).
               - LOW receives the **same global per-period reward** as HIGH (negative total cost).
            2. **Trajectory closure**:
               - Computes advantages and returns (GAE).
               - Normalizes rewards and advantages if enabled.
            3. **PPO update**:
               - Trains HIGH first, then LOW.
               - Each update uses clipping, entropy regularization, and KL-based early stopping.
            4. **Logging and checkpointing**:
               - Logs mean cost and real reward.
               - Saves best models and final checkpoints.
               - Produces plots and CSVs at the end of training.
    
        :return: None. (Trained models, curves, and metrics are saved to disk.)
        :rtype: None
        """
        H = self.HYP
        print_every = H["print_every"]
        out_dir = H["out_dir"]
        episode_id = 0
        obs = self.obs  # initial state already reset

        # Evaluation frequency: 1% of total updates
        total_updates = H["updates"]
        eval_every = max(1, total_updates // 100)

        # Fixed base seed for evaluations (enables fair comparisons)
        eval_seed_base = H.get("eval_seed_base", 10000)

        # Early stopping based on validation
        early_stop_patience = H.get("early_stop_patience", 15)
        no_improve_evals = 0      # number of consecutive validations without improvement
        stop_training = False  
        
        # =========================
        # Step-wise LR schedule
        # =========================
        high_lr_levels = H.get("lr_high_levels", [H.get("lr_high", 1e-4)])
        low_lr_levels  = H.get("lr_low_levels",  [H.get("lr_low",  1e-4)])
        lr_drop_patience = int(H.get("lr_drop_patience_evals", 7))

        high_lr_stage = 0
        low_lr_stage  = 0
        

        for upd in trange(total_updates, desc="Train HIGH+LOW joint PPO"):
            total_costs = []

            # =====================================================
            # DATA COLLECTION
            # =====================================================
            while self.buf_high.ptr < self.buf_high.max_size or not self.buf_low.is_batch_ready(H["steps_per_update"]):
                obs_t = torch.as_tensor(obs[None, :], dtype=torch.float32, device=self.device)

                # HIGH: mask + action
                high_mask_np = self.env.eligibility_mask_high().astype(np.float32)[None, :]
                high_mask_t  = torch.as_tensor(high_mask_np, device=self.device, dtype=torch.float32)

                with torch.no_grad():
                    logits_H, vH = self.high(obs_t)
                    dist_H = MaskedBernoulli(logits_H, high_mask_t)
                
                    # --- Acción Bernoulli ORIGINAL (para PPO) ---
                    aH_t = dist_H.sample()
                    logpH_t = dist_H.log_prob(aH_t)
                
                    probs_H = dist_H.probs.squeeze(0).cpu().numpy().astype(np.float32)
                
                # aH_raw: acción original Bernoulli (0/1) ya en numpy
                aH_raw = aH_t.squeeze(0).cpu().numpy().astype(np.int8)
                logpH_raw = float(logpH_t.item())
                
                # action executed in the environment: clip to Kmax if applicable
                aH_env = aH_raw
                clipped_high = False
                
                if self.env.Kmax is not None and aH_raw.sum() > int(self.env.Kmax):
                    # stochastic clipping en TRAIN
                    aH_env, clipped_high = self.env.clip_high_to_Kmax(
                        a_high_raw=aH_raw,
                        a_high_scores=probs_H,
                        mode="stochastic"
                    )
                
                # Extra safety: enforce eligibility mask again
                elig = self.env.eligibility_mask_high().astype(np.int8)
                aH_env = (aH_env & elig).astype(np.int8)

                # LOW order (definition of the sub-decision level)
                chosen = self.env.plan_quantity_assignment_order(aH_env, probs_H)

                # LOW period
                self.buf_low.start_period()
                low_actions_q = []
                
                CAP_rem = int(self.env.CAP)
                I_view = self.env.I.copy()
                prev_idx = int(self.env.current_setup_idx())

                
                for pos, i in enumerate(chosen):
                    # LOW state + feasible actions given current CAP_rem
                    low_obs_np, mask_q, need_setup = self.env._low_state_mask_for(
                        i,
                        CAP_rem,
                        a_high_scores=probs_H,
                        pos=pos,
                        chosen=chosen,
                        I_view=I_view,
                        a_high_vec=aH_env,
                        prev_idx=prev_idx,
                    )
                    
                    # Ensures shape (Amax,)
                    mask_local = np.asarray(mask_q, dtype=np.float32)
                    if mask_local.shape != (self.Amax,):
                        raise ValueError(f"mask_q shape {mask_local.shape} != (Amax,)={(self.Amax,)}")
                    
                    # Fallback 
                    if not np.any(mask_local > 0):
                        mask_local = np.zeros((self.Amax,), dtype=np.float32)
                        mask_local[0] = 1.0
                    
                    low_obs_t = torch.as_tensor(low_obs_np[None, :], dtype=torch.float32, device=self.device)
                    mask_t    = torch.as_tensor(mask_local[None, :], dtype=torch.float32, device=self.device)
                    
                    with torch.no_grad():
                        logits_L, vL = self.low(low_obs_t)
                        dist_L = MaskedCategorical(logits_L, mask_t)
                        q_t   = dist_L.sample()                 
                        logpL_t = dist_L.log_prob(q_t)
                    
                    q_i = int(q_t.item())
                    q_i = max(0, min(q_i, self.env.CAP))
                    
                    # Safety: if for any reason q_i is not feasible, snap to the largest feasible value or 0
                    if mask_local[q_i] <= 0:
                        feas_q = np.nonzero(mask_local > 0)[0]
                        q_i = int(feas_q[-1]) if feas_q.size > 0 else 0
                        q_fixed_t = torch.as_tensor([q_i], device=self.device, dtype=torch.int64)
                        with torch.no_grad():
                            logpL_t = dist_L.log_prob(q_fixed_t)
                    
                    # Store LOW substep: act = q (no índice)
                    self.buf_low.store_substep(low_obs_np, q_i, float(vL.item()), float(logpL_t.item()), mask=mask_local)
                    low_actions_q.append(q_i)
                    
                    # Updates CAP_rem with q_i (quantity)
                    if q_i > 0:
                        if need_setup:
                            st_ij = int(self.env.st_sd[prev_idx, i]) if (self.env.st_sd is not None) else int(self.env.st[i])
                            CAP_rem -= st_ij
                        CAP_rem -= q_i
                        CAP_rem = max(0, CAP_rem)
                
                        I_view[i] += q_i * self.env.bs[i]
                        prev_idx = int(i)


                # Environment step and global reward
                next_obs, _, term, trunc, info = self.env.step(aH_env, low_actions=low_actions_q, a_high_scores=probs_H)
                cost_t = float(info["cost"])
                reward_t = -cost_t
                total_costs.append(cost_t)

                # Store transitions in buffers
                self.buf_high.store(
                    obs,
                    aH_raw,                
                    reward_t,
                    float(vH.item()),
                    logpH_raw,           
                    mask=high_mask_np.squeeze(0),
                )

                self.buf_low.end_period_assign_global_reward(reward_t)

                # Reset or advance
                if term or trunc:
                    self.buf_high.finish_path(last_val=0.0)
                    self.buf_low.finish_episode_and_collect()
                    episode_id += 1
                    obs, _ = self.env.reset(seed=self.seed + episode_id)
                else:
                    obs = next_obs

                # HIGH buffer fill condition
                if self.buf_high.ptr >= self.buf_high.max_size:
                    break

            # Close pending trajectories
            if self.buf_high.path_start_idx < self.buf_high.ptr:
                self.buf_high.finish_path(last_val=0.0)
            self.buf_low.finish_episode_and_collect()

            # Extract PPO batches
            dataH = self.buf_high.get()
            dataL = self.buf_low.get()

            # =====================================================
            # PPO UPDATE + LOSS METRICS
            # =====================================================
            kl_h, pi_loss_h, v_loss_h = self._ppo_update_high(dataH)
            kl_l, pi_loss_l, v_loss_l = self._ppo_update_low(dataL)

            # Training metrics
            mean_cost = float(np.mean(total_costs)) if total_costs else 0.0
            self.curve_cost.append(mean_cost)
            mean_real_reward = -mean_cost
            self.curve_real_reward.append(mean_real_reward)

            # Console logging
            if (upd + 1) % print_every == 0:
                print(
                    f"[Joint {upd+1}] mean RAW cost: {mean_cost:.3f} | "
                    f"mean REAL reward: {mean_real_reward:.3f} | "
                    f"KL_high={kl_h:.4f} | KL_low={kl_l:.4f}"
                )

            # WandB logging 
            if self.use_wandb:
                import wandb

                log_dict = {
                    "update": upd + 1,
                    "mean_raw_cost": mean_cost,
                    "mean_real_reward": mean_real_reward,
                    "KL_high": kl_h,
                    "KL_low": kl_l,
                    "loss_actor_high": pi_loss_h,
                    "loss_critic_high": v_loss_h,
                    "loss_actor_low": pi_loss_l,
                    "loss_critic_low": v_loss_l,
                }

                wandb.log(log_dict, step=upd + 1)

            # =====================================================
            # PERIODIC VALIDATION (~every 1% of updates)
            # =====================================================
            do_eval = ((upd + 1) % eval_every == 0) or (upd == total_updates - 1)
            if do_eval:
                eval_stats = self.test(
                    n_runs=5,
                    horizon=1000,
                    warmup=10,
                    greedy=True,
                    seed_base=eval_seed_base,
                    ckpt_high=None,
                    ckpt_low=None,
                    env_overrides={"horizon": 1000},
                )
                val_cost = float(eval_stats["mean_of_means"])

                # Store validation curves
                self.val_cost_curve.append(val_cost)
                self.val_steps.append(upd + 1)

                # Log validation cost to WandB
                if self.use_wandb:
                    import wandb
                    wandb.log(
                        {
                            "val_mean_cost": val_cost,
                        },
                        step=upd + 1,
                    )

                # Update best model according to validation + early stopping
                if (self.best_val_cost is None) or (val_cost < self.best_val_cost - 1e-9):
                    # Ha habido mejora
                    self.best_val_cost = val_cost
                    self.best_val_step = upd + 1
                    no_improve_evals = 0  

                    torch.save(self.high.state_dict(), os.path.join(out_dir, "high_joint_best.pt"))
                    torch.save(self.low.state_dict(),  os.path.join(out_dir, "low_joint_best.pt"))
                    print(f"[VALID] New best model: val_mean_cost={self.best_val_cost:.3f} @ update {self.best_val_step}")
                else:
                    no_improve_evals += 1
                    print(f"[VALID] No improvement in validation for {no_improve_evals} consecutive evaluations.")

                    # Step schedule: every N non-improving evaluations, drop LR one level (after update 1500)
                    if (upd + 1) >= 1500 and lr_drop_patience > 0 and (no_improve_evals % lr_drop_patience) == 0:

                        # HIGH: advance stage if possible
                        if high_lr_stage < (len(high_lr_levels) - 1):
                            high_lr_stage += 1
                            new_lr_h = float(high_lr_levels[high_lr_stage])
                            for pg in self.opt_high.param_groups:
                                pg["lr"] = new_lr_h

                        # LOW: advance stage if possible
                        if low_lr_stage < (len(low_lr_levels) - 1):
                            low_lr_stage += 1
                            new_lr_l = float(low_lr_levels[low_lr_stage])
                            for pg in self.opt_low.param_groups:
                                pg["lr"] = new_lr_l

                        lr_h_now = self.opt_high.param_groups[0]["lr"]
                        lr_l_now = self.opt_low.param_groups[0]["lr"]
                        print(f"[LR STEP] no_improve={no_improve_evals} | lr_high={lr_h_now:.2e} | lr_low={lr_l_now:.2e}")

                        if self.use_wandb:
                            import wandb
                            wandb.log({"lr_high": lr_h_now, "lr_low": lr_l_now}, step=upd + 1)

                    # Early stopping based on validation
                    if no_improve_evals > early_stop_patience:
                        print(
                            f"[EARLY STOP] No improvement in validation for {early_stop_patience} "
                            f"consecutive evaluations. Stopping training at update {upd+1}."
                        )
                        stop_training = True


            if stop_training:
                break


        # =========================================================
        # FINAL SAVES AND METRICS (best + final only)
        # =========================================================
        print("Joint training finished.")
        torch.save(self.high.state_dict(), os.path.join(out_dir, "high_joint_final.pt"))
        torch.save(self.low.state_dict(), os.path.join(out_dir, "low_joint_final.pt"))
        print("Saved models: high_joint_final.pt / low_joint_final.pt")
    
        if self.best_val_cost is not None:
            print(
                f"Best validation cost: {self.best_val_cost:.3f} "
                f"@ update {self.best_val_step} "
                f"(high_joint_best.pt / low_joint_best.pt)"
            )
    
        # Plots and CSVs
        try:
            plt.figure()
            plt.plot(self.curve_cost, label="Mean RAW cost per update")
            plt.xlabel("Update"); plt.ylabel("Mean raw cost"); plt.title("Joint – Cost")
            plt.grid(True); plt.legend(); plt.tight_layout()
            plt.savefig(os.path.join(out_dir, "curve_joint_cost.png"), dpi=150)
    
            plt.figure()
            plt.plot(self.curve_real_reward, label="Mean REAL reward per update")
            plt.xlabel("Update"); plt.ylabel("Mean real reward"); plt.title("Joint – Real Reward")
            plt.grid(True); plt.legend(); plt.tight_layout()
            plt.savefig(os.path.join(out_dir, "curve_joint_real_reward.png"), dpi=150)
    
            np.savetxt(os.path.join(out_dir, "curve_joint_cost.csv"), np.array(self.curve_cost), delimiter=",")
            np.savetxt(os.path.join(out_dir, "curve_joint_real_reward.csv"), np.array(self.curve_real_reward), delimiter=",")
    
            if len(self.val_cost_curve) > 0:
                np.savetxt(os.path.join(out_dir, "curve_val_cost.csv"), np.array(self.val_cost_curve), delimiter=",")
                np.savetxt(os.path.join(out_dir, "curve_val_steps.csv"), np.array(self.val_steps, dtype=np.int32), delimiter=",")
    
            print(
                "Saved plots/CSVs: curve_joint_cost.png, curve_joint_real_reward.png "
                "(+ validation curves if present)."
            )
        except Exception as e:
            print(f"(warning) could not generate/save plots or CSVs: {e}")


    # =========================
    # ========= EVAL ==========
    # =========================
    def _build_eval_env(self, env_overrides, seed):
        """
        Creates a fresh evaluation environment from the training environment by
        cloning its baseline configuration and applying optional overrides.
    
        Usage:
          - Enables evaluation of the trained policy without mutating `self.env`.
    
        :param env_overrides: Optional dictionary of parameters to override.        
        :type env_overrides: dict or None
        :param seed: Seed used to make evaluation reproducible (applied to the new
                     environment and its spaces).
        :type seed: int or None
    
        :return: (env_eval, obs_init), where:
                 - env_eval is the cloned `CLSPHierEnv` configured for evaluation,
                 - obs_init is the initial observation after resetting the eval environment.
        :rtype: tuple[CLSPHierEnv, numpy.ndarray]
        """
        src = self.env
        ov = env_overrides or {}

        # Copy structural parameters from the original environment
        K   = src.K
        mu  = np.array(src.mu, copy=True)
        bs  = np.array(src.bs, copy=True)
        h   = np.array(src.h,  copy=True)
        b   = np.array(src.b,  copy=True)
        k   = np.array(src.k,  copy=True)
        st  = np.array(src.st, copy=True)
        CAP = src.CAP
        k_sd  = None if getattr(src, "k_sd", None)  is None else np.array(src.k_sd,  copy=True)
        st_sd = None if getattr(src, "st_sd", None) is None else np.array(src.st_sd, copy=True)

        # Inherited parameters with optional overrides
        kwargs = dict(
            horizon=ov.get("horizon", getattr(src, "horizon", 10_000) or 10_000),
            cov=np.array(getattr(src, "cov", np.ones(K, np.float32)), copy=True),
            seed=seed,
            auto_kmax_from_paper=ov.get("auto_kmax_from_paper", getattr(src, "auto_kmax_from_paper", False)),
            kmax_prob_threshold=ov.get("kmax_prob_threshold", getattr(src, "kmax_prob_threshold", 0.01)),
            enable_ip_eligibility=ov.get("enable_ip_eligibility", getattr(src, "enable_ip_eligibility", True)),
            enforce_eoq_qmax=ov.get("enforce_eoq_qmax", getattr(src, "enforce_eoq_qmax", True)),
            eoq_slack_batches=ov.get("eoq_slack_batches", getattr(src, "eoq_slack_batches", 0)),
            reserve_future_min=ov.get("reserve_future_min", getattr(src, "reserve_future_min", True)),
            force_min_batch=ov.get("force_min_batch", getattr(src, "force_min_batch_default", True)),
            enable_Ilim=ov.get("enable_Ilim", getattr(src, "enable_Ilim", True)),
            k_sd=k_sd,
            st_sd=st_sd,
        )

        # New evaluation environment (independent from the training one)
        env_eval = CLSPHierEnv(K, mu, bs, h, b, k, st, CAP, **kwargs)

        # If a seed is provided, also seed the spaces
        if seed is not None:
            env_eval.action_space.seed(seed)
            env_eval.observation_space.seed(seed)

        obs_init, _ = env_eval.reset(seed=seed)
        return env_eval, obs_init


    
    @staticmethod
    @torch.no_grad()
    def _act_high(env, high_model, obs_np, device, greedy=True):
        """
        Selects a HIGH-level action given the current observation and a trained
        HIGH policy.
    
        A masked Bernoulli distribution over K products is constructed using:
          - logits produced by `high_model`,
          - the eligibility mask returned by `env.eligibility_mask_high()`.
    
        If `greedy=True`, a deterministic decision rule is applied:
          - Products with probability ≥ 0.5 are activated.
          - If no product satisfies the threshold:
              * the currently set-up product (`env.omega`) is selected if eligible;
              * otherwise, the eligible product with the highest probability is selected.
          - If `env.Kmax` is defined and more than Kmax products are selected,
            only the Kmax products with highest probability are kept.
    
        If `greedy=False`, actions are sampled stochastically from the masked
        Bernoulli distribution.
    
        :param env: Hierarchical CLSP environment providing eligibility masks
                    and the current system state.
        :type env: CLSPHierEnv
        :param high_model: HIGH-level actor-critic network. It must take a batch
                           of observations and return `(logits, value)`.
        :type high_model: torch.nn.Module
        :param obs_np: Current environment observation (1D array).
        :type obs_np: numpy.ndarray
        :param device: Device on which the model is executed ("cpu" or "cuda").
        :type device: str
        :param greedy: If True, uses a deterministic decision rule. If False,
                       samples from the stochastic policy.
        :type greedy: bool
    
        :return: Tuple `(a_high, logp, value, mask, probs)` where:
                 - `a_high` is the selected HIGH action as a binary vector {0,1}^K,
                 - `logp` is the log-probability of `a_high` under the masked policy,
                 - `value` is the critic estimate V(s),
                 - `mask` is the eligibility mask used (size K),
                 - `probs` are the Bernoulli probabilities per product.
        :rtype: tuple[numpy.ndarray, float, float, numpy.ndarray, numpy.ndarray]
        """
        obs_t = torch.as_tensor(obs_np[None, :], dtype=torch.float32, device=device)
        logits, v = high_model(obs_t)

        # HIGH eligibility mask
        mask_np = env.eligibility_mask_high().astype(np.float32)[None, :]
        mask_t = torch.as_tensor(mask_np, device=device, dtype=logits.dtype)

        # Masked Bernoulli distribution
        dist = MaskedBernoulli(logits, mask_t)
        probs = dist.probs[0].cpu().numpy().astype(np.float32)

        if greedy:
            # Deterministic threshold-based selection
            a = (probs >= 0.5).astype(np.int64)

            # Fallback if no product is selected
            if a.sum() == 0:
                omega_idx = int(np.argmax(env.omega))
                if mask_np[0, omega_idx] > 0:
                    a[omega_idx] = 1
                else:
                    elig = np.where(mask_np[0] > 0)[0]
                    if elig.size > 0:
                        a[elig[np.argmax(probs[elig])]] = 1
        else:
            # Stochastic sampling
            a = dist.sample()[0].cpu().numpy().astype(np.int64)

        # Enforce eligibility mask
        a = (a & mask_np.squeeze(0).astype(np.int64))

        # Enforce Kmax (deterministic in greedy mode; stochastic otherwise)
        if getattr(env, "Kmax", None) is not None:
            Kmax = int(env.Kmax)
        
            if a.sum() > Kmax:
                on = np.nonzero(a)[0]
        
                if greedy:
                    # keep top-Kmax by probability
                    keep = on[np.argsort(probs[on])[::-1][:Kmax]]
                else:
                    # stochastic keep (without replacement) weighted by probs
                    w = probs[on].astype(np.float64)
                    w = np.clip(w, 1e-12, None)
                    w = w / w.sum()
                    keep = env.rng.choice(on, size=Kmax, replace=False, p=w)
        
                a[:] = 0
                a[keep] = 1
        
                # Safety: eligibility again
                a = (a & mask_np.squeeze(0).astype(np.int64))
        

        # Log-probability of the selected action
        logp = dist.log_prob(
            torch.as_tensor(a[None, :], dtype=torch.float32, device=device)
        ).item()

        return a.astype(np.int64), float(logp), float(v.item()), mask_np.squeeze(0), probs



    @staticmethod
    @torch.no_grad()
    def _act_low_seq(env, low_model, a_high_env, a_high_scores=None, greedy=True,
                    device="cpu", force_min_batch=None):
        """
        Generates the LOW-level action sequence (batch quantities q) for the products
        selected by the HIGH level within a single period.
    
        For each visited product (ordered via env.plan_low_level), the routine:
          - Builds the LOW state using env._low_state_mask_for(...), including a period-internal
            virtual inventory I_view so that later LOW decisions see the effect of earlier ones.
          - Uses a masked categorical policy over the global action space {0..CAP} (Amax = CAP+1),
            where the sampled/selected action is q directly.
          - Updates a simulated remaining capacity CAP_rem_sim accounting for setup time and q.
    
        This routine does NOT mutate the real environment inventory; it only returns the visit
        order and the selected quantities q per visited product.
    
        Returns
        -------
        chosen : np.ndarray
            Product indices in LOW visit order.
        low_actions_q : list[int]
            Quantities q in batches (each q in {0..CAP}).
        """
        fmb = force_min_batch if force_min_batch is not None else getattr(env, "force_min_batch_default", False)
    
        # LOW visit order induced by HIGH
        scores_vec = a_high_scores if a_high_scores is not None else a_high_env.astype(np.float32)
        chosen = env.plan_quantity_assignment_order(a_high_env, scores_vec)
    
        Amax = env.CAP + 1
        low_actions_q = []
    
        CAP_rem_sim = int(env.CAP)
    
        # IMPORTANT: virtual within-period inventory so later LOW states reflect earlier production
        I_view = env.I.copy()

        prev_idx = int(env.current_setup_idx())
    
        for pos, i in enumerate(chosen):
            low_obs_np, mask_q, need_setup = env._low_state_mask_for(
                i,
                CAP_rem_sim,
                a_high_scores=scores_vec,
                pos=pos,
                chosen=chosen,
                force_min_batch=fmb,
                I_view=I_view,          
                a_high_vec=a_high_env,
                prev_idx=prev_idx,
            )
    
            mask_local = np.asarray(mask_q, dtype=np.float32)
            if mask_local.shape != (Amax,):
                raise ValueError(f"mask_q shape {mask_local.shape} != (Amax,)={(Amax,)}")
    
            # Robust fallback: ensure at least q=0 feasible
            if not np.any(mask_local > 0):
                mask_local = np.zeros((Amax,), dtype=np.float32)
                mask_local[0] = 1.0
    
            obs_t = torch.as_tensor(low_obs_np[None, :], dtype=torch.float32, device=device)
            logits, _ = low_model(obs_t)
    
            mask_t = torch.as_tensor(mask_local[None, :], device=device, dtype=logits.dtype)
            dist = MaskedCategorical(logits, mask_t)
    
            if greedy:
                q_i = int(torch.argmax(dist.logits, dim=-1).item())
            else:
                q_i = int(dist.sample().item())
    
            # Clamp hard for safety
            q_i = max(0, min(q_i, env.CAP))
    
            # Safety snap if something went wrong )
            if mask_local[q_i] <= 0:
                feas_q = np.nonzero(mask_local > 0)[0]
                q_i = int(feas_q[-1]) if feas_q.size > 0 else 0
    
            low_actions_q.append(q_i)
    
            # Update simulated capacity
            if q_i > 0 and need_setup:
                st_ij = int(env.st_sd[prev_idx, i]) if (env.st_sd is not None) else int(env.st[i])
                CAP_rem_sim -= st_ij
        
            CAP_rem_sim -= q_i
            CAP_rem_sim = max(0, CAP_rem_sim)
        
            if q_i > 0:
                I_view[i] += q_i * env.bs[i]
                prev_idx = int(i)
    
        return chosen, low_actions_q



    
    def test(self, n_runs=10, horizon=10_000, warmup=1_000, greedy=True, seed_base=12345, 
             ckpt_high=None, ckpt_low=None, env_overrides=None):
        """
        Evaluates the HIGH+LOW pair in terms of **average cost per period** over multiple runs.
    
        Behavior:
          - Uses the current weights, or optionally loads the provided checkpoints.
          - For each run, creates a fresh evaluation environment via `_build_eval_env`,
            cloning the training environment and applying `env_overrides` if provided.
          - Executes the policy (greedy or stochastic) for up to `horizon` steps, discarding
            a warm-up prefix (`warmup`) before averaging costs.
          - Returns aggregated statistics over the per-run mean costs.
    
        :param n_runs: Number of independent evaluation runs.
        :type n_runs: int
        :param horizon: Maximum episode length (in steps) for each evaluation run.
        :type horizon: int
        :param warmup: Number of initial steps to ignore when computing the mean cost
                       (to discard the transient phase).
        :type warmup: int
        :param greedy: If True, uses deterministic (greedy) decisions in both HIGH and LOW.
                       If False, uses stochastic sampling.
        :type greedy: bool
        :param seed_base: Base seed used to generate per-run seeds as `seed_base + r`.
                          If None, determinism across runs is not enforced.
        :type seed_base: int or None
        :param ckpt_high: Optional path to a HIGH policy checkpoint to load before evaluation.
        :type ckpt_high: str or None
        :param ckpt_low: Optional path to a LOW policy checkpoint to load before evaluation.
        :type ckpt_low: str or None
        :param env_overrides: Optional dictionary overriding evaluation-environment parameters
                              Overrides take precedence over defaults inherited from the
                              training environment.
        :type env_overrides: dict or None
    
        :return: Dictionary with:
                 - "n_runs": number of executed runs,
                 - "horizon": evaluation horizon used,
                 - "warmup": ignored warm-up prefix,
                 - "greedy": decision mode used,
                 - "mean_costs_per_run": list of per-run mean costs,
                 - "mean_of_means": mean of the per-run means,
                 - "std_of_means": standard deviation across per-run means.
        :rtype: dict
        """
        # Optional checkpoint loading
        if ckpt_high and os.path.isfile(ckpt_high):
            self.high.load_state_dict(torch.load(ckpt_high, map_location=self.device))
        if ckpt_low and os.path.isfile(ckpt_low):
            self.low.load_state_dict(torch.load(ckpt_low, map_location=self.device))
        self.high.eval(); self.low.eval()

        # Let env_overrides["horizon"] override the horizon argument
        env_overrides = dict(env_overrides or {})
        env_overrides.setdefault("horizon", horizon)

        mean_costs = []

        for r in range(n_runs):
            # Per-run seed (if a base is provided)
            run_seed = (seed_base + r) if (seed_base is not None) else None
            if run_seed is not None:
                random.seed(run_seed)
                np.random.seed(run_seed)
                torch.manual_seed(run_seed)
                if torch.cuda.is_available():
                    torch.cuda.manual_seed_all(run_seed)
                torch.backends.cudnn.benchmark = False
                torch.backends.cudnn.deterministic = True
                torch.use_deterministic_algorithms(True)

            # Evaluation environment and initial state
            env_eval, obs = self._build_eval_env(env_overrides, seed=run_seed)

            costs = []
            for t in range(int(env_overrides["horizon"])):
                # HIGH action (deterministic or stochastic) + LOW sequence
                a_high_env, _, _, _, probs_H = self._act_high(env_eval, self.high, obs, device=self.device, greedy=greedy)
                chosen, low_actions_q = self._act_low_seq(
                    env_eval,
                    self.low,
                    a_high_env,
                    a_high_scores=probs_H,
                    greedy=greedy,
                    device=self.device,
                    force_min_batch=env_overrides.get("force_min_batch", None),
                )

                # Step the environment with both decisions
                obs_next, _, terminated, truncated, info = env_eval.step(
                    a_high_env,
                    low_actions=low_actions_q,
                    a_high_scores=probs_H,
                )

                # Accumulate cost only after warm-up
                if t >= int(warmup):
                    costs.append(float(info["cost"]))

                if terminated or truncated:
                    break

                obs = obs_next

            # Mean cost for this run
            mc = float(np.mean(costs)) if costs else float("nan")
            mean_costs.append(mc)

        # Aggregate across runs
        mean_of_means = float(np.mean(mean_costs)) if mean_costs else float("nan")
        std_of_means = float(np.std(mean_costs, ddof=1)) if len(mean_costs) > 1 else 0.0

        return {
            "n_runs": n_runs,
            "horizon": int(env_overrides["horizon"]),
            "warmup": int(warmup),
            "greedy": bool(greedy),
            "mean_costs_per_run": mean_costs,
            "mean_of_means": mean_of_means,
            "std_of_means": std_of_means,
        }

